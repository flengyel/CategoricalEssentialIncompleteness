import CategoricalEssentialIncompleteness.V46UniformTrace
import CategoricalEssentialIncompleteness.V46UniformTraceArithmetic
import CategoricalEssentialIncompleteness.V46UniformTraceBuilders
import CategoricalEssentialIncompleteness.V46UniformTraceCoding
import CategoricalEssentialIncompleteness.V46UniformTraceComparison
import CategoricalEssentialIncompleteness.V46UniformTracePrimitiveBuilders
import CategoricalEssentialIncompleteness.V46UniformTracePrimitiveCoding
import CategoricalEssentialIncompleteness.V46UniformTraceProgram
import CategoricalEssentialIncompleteness.V46UniformTraceSpecializers
import CategoricalEssentialIncompleteness.V46WeightedCubeTopology
import Lean
open Lean Elab Command Meta
set_option pp.maxSteps 2000000
set_option maxRecDepth 4000
elab "#read_claim " d:ident : command => liftTermElabM do
  let n := d.getId
  let decl ← mkConstWithFreshMVarLevels n
  let type ← inferType decl
  let encoded ← forallTelescope type fun xs result => do
    -- Apply the theorem to fresh locals for every binder in its actual type.
    let applied := mkAppN decl xs
    let inferred ← inferType applied
    unless ← isDefEq inferred result do throwError "the application has the wrong result"
    let args ← xs.mapM fun x => do
      let localDecl ← x.fvarId!.getDecl
      return Json.mkObj [("binder",toJson localDecl.userName.toString),("type",toJson (← ppExpr localDecl.type).pretty)]
    return Json.mkObj [("parameters",Json.arr args),("conclusion",toJson (← ppExpr result).pretty)]
  let moduleName ← findModuleOf? n
  let axioms ← Lean.collectAxioms n
  logInfo ("READ_CLAIM " ++ (Json.mkObj [("name",toJson n.toString),("module",toJson (moduleName.map Name.toString)),("applied",encoded),("axioms",toJson (axioms.map Name.toString))]).compress)

#read_claim CategoricalEssentialIncompleteness.V46.UniformTrace.universal_PA
#read_claim CategoricalEssentialIncompleteness.V46.UniformTrace.arithmetized_evaluation
#read_claim CategoricalEssentialIncompleteness.V46.UniformTrace.builders_totality_PA
#read_claim CategoricalEssentialIncompleteness.V46.UniformTrace.composition_PA
#read_claim CategoricalEssentialIncompleteness.V46.UniformTrace.specialization_PA
#read_claim CategoricalEssentialIncompleteness.V46.UniformTrace.out_natPrimrec
#read_claim CategoricalEssentialIncompleteness.V46.UniformTrace.compose_production_PA
#read_claim CategoricalEssentialIncompleteness.V46.UniformTrace.compose_primrec
#read_claim CategoricalEssentialIncompleteness.V46.UniformTrace.specialize_primrec
#read_claim CategoricalEssentialIncompleteness.V46.UniformTrace.traceCheck_natPrimrec
#read_claim CategoricalEssentialIncompleteness.V46.UniformTrace.trace_primrec
#read_claim CategoricalEssentialIncompleteness.V46.UniformTrace.primitive_trace_graph_PA
#read_claim CategoricalEssentialIncompleteness.V46.UniformTrace.specializerSection_PA
#read_claim CategoricalEssentialIncompleteness.V46.UniformTrace.specializerSection_eval
#read_claim CategoricalEssentialIncompleteness.V46.UniformTrace.specializerSection_totality_PA
#read_claim CategoricalEssentialIncompleteness.V46.Miller.Cut.Distance.continuous_productDistance
#read_claim CategoricalEssentialIncompleteness.V46.Miller.Cut.Distance.coordinate_bounds
#read_claim CategoricalEssentialIncompleteness.V46.Miller.Cut.Distance.isOpen_iff_productDistance
#read_claim CategoricalEssentialIncompleteness.V46.Miller.Cut.Distance.positive_distance
#read_claim CategoricalEssentialIncompleteness.V46.Miller.Cut.Distance.weightedMetric
