import CategoricalEssentialIncompleteness.V46ForkParameterizedFormulaFolds
import CategoricalEssentialIncompleteness.V46ForkRangeStability
import CategoricalEssentialIncompleteness.V46ForkSignedAtomInclusion
import CategoricalEssentialIncompleteness.V46ForkTupleEvaluation
import CategoricalEssentialIncompleteness.V46ForkTupleEvaluationComparisons
import Lean
open Lean Elab Command Meta
set_option pp.maxSteps 2000000
set_option maxRecDepth 4000
elab "#read_claim " d:ident : command => liftTermElabM do
  let n := d.getId
  let decl ← mkConstWithFreshMVarLevels n
  let type ← inferType decl
  let encoded ← forallTelescope type fun xs result => do
    -- Apply the theorem to fresh locals for every binder in its actual type.
    let applied := mkAppN decl xs
    let inferred ← inferType applied
    unless ← isDefEq inferred result do throwError "the application has the wrong result"
    let args ← xs.mapM fun x => do
      let localDecl ← x.fvarId!.getDecl
      return Json.mkObj [("binder",toJson localDecl.userName.toString),("type",toJson (← ppExpr localDecl.type).pretty)]
    return Json.mkObj [("parameters",Json.arr args),("conclusion",toJson (← ppExpr result).pretty)]
  let moduleName ← findModuleOf? n
  let axioms ← Lean.collectAxioms n
  logInfo ("READ_CLAIM " ++ (Json.mkObj [("name",toJson n.toString),("module",toJson (moduleName.map Name.toString)),("applied",encoded),("axioms",toJson (axioms.map Name.toString))]).compress)

#read_claim CategoricalEssentialIncompleteness.V46.ForkParameterizedFormulaFolds.fold
#read_claim CategoricalEssentialIncompleteness.V46.ForkParameterizedFormulaFolds.fold_constructor
#read_claim CategoricalEssentialIncompleteness.V46.ForkParameterizedFormulaFolds.fold_over
#read_claim CategoricalEssentialIncompleteness.V46.ForkRangeStability.equivalence
#read_claim CategoricalEssentialIncompleteness.V46.ForkRangeStability.map_total
#read_claim CategoricalEssentialIncompleteness.V46.ForkRangeStability.partial_range_stable
#read_claim CategoricalEssentialIncompleteness.V46.ForkRangeStability.span_image
#read_claim CategoricalEssentialIncompleteness.V46.ForkRangeStability.span_pullback_range
#read_claim CategoricalEssentialIncompleteness.V46.ForkRangeStability.span_range
#read_claim CategoricalEssentialIncompleteness.V46.ForkDerivation.codedCopair
#read_claim CategoricalEssentialIncompleteness.V46.ForkDerivation.codedInl
#read_claim CategoricalEssentialIncompleteness.V46.ForkDerivation.codedInl_comparison
#read_claim CategoricalEssentialIncompleteness.V46.ForkDerivation.codedInl_copair
#read_claim CategoricalEssentialIncompleteness.V46.ForkDerivation.codedInr
#read_claim CategoricalEssentialIncompleteness.V46.ForkDerivation.codedInr_comparison
#read_claim CategoricalEssentialIncompleteness.V46.ForkDerivation.codedInr_copair
#read_claim CategoricalEssentialIncompleteness.V46.ForkDerivation.codedSum
#read_claim CategoricalEssentialIncompleteness.V46.ForkDerivation.codedSumColimit
#read_claim CategoricalEssentialIncompleteness.V46.ForkDerivation.signedCode
#read_claim CategoricalEssentialIncompleteness.V46.ForkDerivation.signedCode_injective
#read_claim CategoricalEssentialIncompleteness.V46.ForkDerivation.signed_atoms_mono
#read_claim CategoricalEssentialIncompleteness.V46.ForkDerivation.signed_injective
#read_claim CategoricalEssentialIncompleteness.V46.ForkDerivation.sumComparison
#read_claim CategoricalEssentialIncompleteness.V46.ForkDerivation.tuple_signed_atoms_mono
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.evaluation_range
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.evaluation_restriction
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.evaluation_span
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.evaluation_zero
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.Diagram
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.ForkSpans
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.TupleSpans
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.binaryJoins
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.component
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.componentIdem
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.componentIdem_hom
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.componentIdem_sup
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.evaluatedIdem
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.evaluation
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.evaluation_sup
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.evaluation_value
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.forkCode
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.forkCode_restriction
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.idemOrderIso
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.tupleCode
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.tupleCode_restriction
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.zeroMorphisms
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.evaluation_product
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.baseEval
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.comparison_fst
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.comparison_snd
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.componentProductIso
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.component_product_comparison
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.evaluation_pair
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.fork_first
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.fork_second
