import CategoricalEssentialIncompleteness.V46MillerCutApplications
import CategoricalEssentialIncompleteness.V46MillerFixedPoint
open CategoryTheory CategoryTheory.RestrictionCategory
open CategoricalEssentialIncompleteness.LocalConnectedness
namespace CategoricalEssentialIncompleteness.V46.Miller
attribute [local instance 2000] Uniform.nativeRestriction
set_option backward.isDefEq.respectTransparency false
set_option backward.isDefEq.respectTransparency.types false
-- Use actual existence, then the cut result at exactly that witness and each of its names.
example : ∃ a : Point, IsMiller a ∧ Inseparable (CutDigits.lowerIdem a) (CutDigits.upperIdem a) ∧
    ∀ p ∈ representations a,
      CutDigits.lowerCut a ⊆ CutDigits.separator p ∧
      Disjoint (CutDigits.separator p) (CutDigits.upperCut a) := by
  obtain ⟨a, ha⟩ := exists_isMiller
  obtain ⟨hI, hP⟩ := Cut.printed_cut_contrast a ha
  exact ⟨a, ha, hI, fun p hp => ⟨(hP p hp).1, (hP p hp).2.1⟩⟩
end CategoricalEssentialIncompleteness.V46.Miller
