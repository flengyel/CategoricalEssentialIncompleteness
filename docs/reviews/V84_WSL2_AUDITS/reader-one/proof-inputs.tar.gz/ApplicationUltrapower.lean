import CategoricalEssentialIncompleteness.V46UltrapowerComparisonChecks
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic Filter
open CategoricalEssentialIncompleteness.V46 CategoricalEssentialIncompleteness.V46.SyntacticPredicates
namespace CategoricalEssentialIncompleteness.V46.ArithmeticUltrapower
-- Realize all three cases with the same U: arbitrary predicate family, a particular
-- interpreted function value in a two-variable graph, and a sentence belonging to PA.
example {I : Type} (U : Ultrafilter I) {C D : Carrier} (f : GraphMorphism 𝗣𝗔 C D)
    (x : I → PredicateInterpretation.Obj ℕ C) (φ : ArithmeticSentence) (hφ : φ ∈ 𝗣𝗔)
    (y : I → ℕ) (hy : ∀ᶠ i in (U : Filter I), C.val.Evalb ![y i]) :
    C.val.Evalb (M := Model U) ![Germ.ofFun y] ∧
    f.graph.val.Evalb (M := Model U) ![Germ.ofFun (fun i => (x i).val),
      Germ.ofFun (fun i => (PredicateInterpretation.value 𝗣𝗔 ℕ f (x i)).val)] ∧
    (Model U)↓[ℒₒᵣ] ⊧ φ :=
  ⟨(Checks.unary_predicate U C y).mpr hy, Checks.graph_value U f x, Checks.pa_axiom U φ hφ⟩
end CategoricalEssentialIncompleteness.V46.ArithmeticUltrapower
