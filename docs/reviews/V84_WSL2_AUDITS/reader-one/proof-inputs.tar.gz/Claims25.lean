import CategoricalEssentialIncompleteness.V46RealizedObjectSets
import CategoricalEssentialIncompleteness.V46RealizedObjectSetsCategory
import CategoricalEssentialIncompleteness.V46RecursiveDomainInterpretation
import CategoricalEssentialIncompleteness.V46RecursiveModelRegular
import CategoricalEssentialIncompleteness.V46RecursiveUltrapowerComparison
import CategoricalEssentialIncompleteness.V46RegularImage
import CategoricalEssentialIncompleteness.V46RelationalSignatureAdjunction
import Lean
open Lean Elab Command Meta
set_option pp.maxSteps 2000000
set_option maxRecDepth 4000
elab "#read_claim " d:ident : command => liftTermElabM do
  let n := d.getId
  let decl ← mkConstWithFreshMVarLevels n
  let type ← inferType decl
  let encoded ← forallTelescope type fun xs result => do
    -- Apply the theorem to fresh locals for every binder in its actual type.
    let applied := mkAppN decl xs
    let inferred ← inferType applied
    unless ← isDefEq inferred result do throwError "the application has the wrong result"
    let args ← xs.mapM fun x => do
      let localDecl ← x.fvarId!.getDecl
      return Json.mkObj [("binder",toJson localDecl.userName.toString),("type",toJson (← ppExpr localDecl.type).pretty)]
    return Json.mkObj [("parameters",Json.arr args),("conclusion",toJson (← ppExpr result).pretty)]
  let moduleName ← findModuleOf? n
  let axioms ← Lean.collectAxioms n
  logInfo ("READ_CLAIM " ++ (Json.mkObj [("name",toJson n.toString),("module",toJson (moduleName.map Name.toString)),("applied",encoded),("axioms",toJson (axioms.map Name.toString))]).compress)

#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.ordinal_mem_omega
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.pair_mem_taggedUnion
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.productEquiv
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.productMember
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.product_ne_taggedUnion
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.realize
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.realize_injective
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.secondProjection
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.secondProjection_product
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.secondProjection_taggedUnion
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.setCoding
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.setCoding_realize
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.tag_one_fibre
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.tag_zero_fibre
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.taggedEquiv
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.taggedMember
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.taggedUnion
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.taggedUnion_injective
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.unique_coding
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.unique_term
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.SetPresentation
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.codedProgramEquivalence
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.decodedGraph
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.decodedGraph_realize
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.homProgramEquiv
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.identity_decodedGraph
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.identity_index_composite
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.identity_represents_coding
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.identity_represents_inverse
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.realizationEquivalence
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.realizationFunctor
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.realization_map_bijective
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.realization_map_index
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.realization_obj
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.realization_obj_bijective
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.realization_term
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.represented
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.represented_comp
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.represented_eq_iff
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.represented_identity
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.termFunctor
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.term_realization
#read_claim CategoricalEssentialIncompleteness.V46.PredicateInterpretation.recursiveDomainComparison
#read_claim CategoricalEssentialIncompleteness.V46.PredicateInterpretation.recursiveDomainFunctor_graph
#read_claim CategoricalEssentialIncompleteness.V46.PredicateInterpretation.recursive_regular
#read_claim CategoricalEssentialIncompleteness.V46.ArithmeticUltrapower.recursiveComparison
#read_claim CategoricalEssentialIncompleteness.V46.ClosedUnder
#read_claim CategoricalEssentialIncompleteness.LocalConnectedness.V46.range_regularImage
#read_claim CategoricalEssentialIncompleteness.V46.Voutsadakis.Signature
#read_claim CategoricalEssentialIncompleteness.V46.Voutsadakis.counit_app
#read_claim CategoricalEssentialIncompleteness.V46.Voutsadakis.formulas
#read_claim CategoricalEssentialIncompleteness.V46.Voutsadakis.freeSignature
#read_claim CategoricalEssentialIncompleteness.V46.Voutsadakis.generators
#read_claim CategoricalEssentialIncompleteness.V46.Voutsadakis.signatureAdjunction
#read_claim CategoricalEssentialIncompleteness.V46.Voutsadakis.substitution
