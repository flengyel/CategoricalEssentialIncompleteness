import CategoricalEssentialIncompleteness.V46ForkTupleEvaluationComparisons
import CategoricalEssentialIncompleteness.V46ForkTupleEvaluationCoproducts
import CategoricalEssentialIncompleteness.V46ForkTupleFormulaAlgebra
import CategoricalEssentialIncompleteness.V46ForkTupleFormulaAlgebraCoordinates
import Lean
open Lean Elab Command Meta
set_option pp.maxSteps 2000000
set_option maxRecDepth 4000
elab "#read_claim " d:ident : command => liftTermElabM do
  let n := d.getId
  let decl ← mkConstWithFreshMVarLevels n
  let type ← inferType decl
  let encoded ← forallTelescope type fun xs result => do
    -- Apply the theorem to fresh locals for every binder in its actual type.
    let applied := mkAppN decl xs
    let inferred ← inferType applied
    unless ← isDefEq inferred result do throwError "the application has the wrong result"
    let args ← xs.mapM fun x => do
      let localDecl ← x.fvarId!.getDecl
      return Json.mkObj [("binder",toJson localDecl.userName.toString),("type",toJson (← ppExpr localDecl.type).pretty)]
    return Json.mkObj [("parameters",Json.arr args),("conclusion",toJson (← ppExpr result).pretty)]
  let moduleName ← findModuleOf? n
  let axioms ← Lean.collectAxioms n
  logInfo ("READ_CLAIM " ++ (Json.mkObj [("name",toJson n.toString),("module",toJson (moduleName.map Name.toString)),("applied",encoded),("axioms",toJson (axioms.map Name.toString))]).compress)

#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.numericProduct
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.numericProduct_fst
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.numericProduct_snd
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.productComparison
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.tuple_first
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.tuple_second
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.evaluatedSumColimit
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.evaluation_finset
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.comparison_inl
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.comparison_inr
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.evaluation_bot
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.forkSum
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.forkSumColimit
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.forkSumIso
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.numericSum
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.numericSum_inl
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.numericSum_inr
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.sumColimit
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.sumComparison
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.tupleSum
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.tupleSumColimit
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.tupleSumIso
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleFormulaAlgebra.arityIso
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleFormulaAlgebra.arityIso_natural
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleFormulaAlgebra.atom
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleFormulaAlgebra.atomBranch
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleFormulaAlgebra.atomBranch_constructor
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleFormulaAlgebra.codedAtom
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleFormulaAlgebra.codedImp
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleFormulaAlgebra.codedNeg
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleFormulaAlgebra.constructor
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleFormulaAlgebra.eq_evaluate
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleFormulaAlgebra.evaluate
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleFormulaAlgebra.evaluate_constructor
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleFormulaAlgebra.fold_iff
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleFormulaAlgebra.formulaAlgebra
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleFormulaAlgebra.formulaAlgebra_isInitial
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleFormulaAlgebra.impBranch
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleFormulaAlgebra.impBranch_constructor
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleFormulaAlgebra.mapped_structure
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleFormulaAlgebra.negBranch
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleFormulaAlgebra.negBranch_constructor
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleFormulaAlgebra.negation
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleFormulaAlgebra.polynomial
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleFormulaAlgebra.polynomialComparison
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleFormulaAlgebra.productIso
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleFormulaAlgebra.sumIso
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleFormulaAlgebra.unique_fold
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleFormulaAlgebra.centerCoding
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleFormulaAlgebra.endpointCoding
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleFormulaAlgebra.labelCoding
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleFormulaAlgebra.labelCoding_center
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleFormulaAlgebra.labelCoding_left
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleFormulaAlgebra.labelCoding_right
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleFormulaAlgebra.tupleCodingIso
