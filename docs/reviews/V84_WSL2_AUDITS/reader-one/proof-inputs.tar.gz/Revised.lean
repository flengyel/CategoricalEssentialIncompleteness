import CategoricalEssentialIncompleteness.V46OracleSeparatorLift
import CategoricalEssentialIncompleteness.V46SignedFirstOrderIncompleteness
import CategoricalEssentialIncompleteness.V46UltrapowerComparisonChecks
import Lean
open Lean Elab Command Meta
set_option pp.maxSteps 2000000
set_option maxRecDepth 4000
elab "#read_claim " d:ident : command => liftTermElabM do
  let n := d.getId
  let decl ← mkConstWithFreshMVarLevels n
  let type ← inferType decl
  let encoded ← forallTelescope type fun xs result => do
    -- Apply the theorem to fresh locals for every binder in its actual type.
    let applied := mkAppN decl xs
    let inferred ← inferType applied
    unless ← isDefEq inferred result do throwError "the application has the wrong result"
    let args ← xs.mapM fun x => do
      let localDecl ← x.fvarId!.getDecl
      return Json.mkObj [("binder",toJson localDecl.userName.toString),("type",toJson (← ppExpr localDecl.type).pretty)]
    return Json.mkObj [("parameters",Json.arr args),("conclusion",toJson (← ppExpr result).pretty)]
  let moduleName ← findModuleOf? n
  let axioms ← Lean.collectAxioms n
  logInfo ("READ_CLAIM " ++ (Json.mkObj [("name",toJson n.toString),("module",toJson (moduleName.map Name.toString)),("applied",encoded),("axioms",toJson (axioms.map Name.toString))]).compress)

#read_claim CategoricalEssentialIncompleteness.LocalConnectedness.OracleComputation.Restricted.no_lift_of_output_summands
#read_claim CategoricalEssentialIncompleteness.LocalConnectedness.OracleComputation.ordinaryDiagonal_simulation
#read_claim CategoricalEssentialIncompleteness.LocalConnectedness.OracleComputation.K_iff_simulation_mem_A
#read_claim CategoricalEssentialIncompleteness.LocalConnectedness.OracleComputation.Restricted.missingSection_endomorphism_has_no_lift
#read_claim CategoricalEssentialIncompleteness.LocalConnectedness.OracleComputation.Restricted.total_and_noncomputable_of_output_summands
#read_claim CategoricalEssentialIncompleteness.V46.RestrictionSubobjects.domainJoins
#read_claim CategoricalEssentialIncompleteness.V46.SignedFirstOrder.essential_incomplete_iff_no_domain_separator
#read_claim CategoricalEssentialIncompleteness.V46.RestrictionSubobjects.ComplementaryDomains
#read_claim CategoricalEssentialIncompleteness.V46.RestrictionSubobjects.complementaryDomains_iff
#read_claim CategoricalEssentialIncompleteness.V46.RestrictionSubobjects.complementaryDomains_iff_complementary
#read_claim CategoricalEssentialIncompleteness.V46.SignedFirstOrder.essential_incomplete_iff_no_complementary_domains
#read_claim CategoricalEssentialIncompleteness.V46.ArithmeticUltrapower.Checks.unary_predicate
#read_claim CategoricalEssentialIncompleteness.V46.ArithmeticUltrapower.Checks.graph_value
#read_claim CategoricalEssentialIncompleteness.V46.ArithmeticUltrapower.Checks.pa_axiom
