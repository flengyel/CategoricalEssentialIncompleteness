import CategoricalEssentialIncompleteness.V46PrimitiveRecursiveTags
import CategoricalEssentialIncompleteness.V46ProgramOrder
import CategoricalEssentialIncompleteness.V46PropositionalAssociatedIncompleteness
import CategoricalEssentialIncompleteness.V46PropositionalClosureTransfer
import CategoricalEssentialIncompleteness.V46PropositionalRuleClosure
import CategoricalEssentialIncompleteness.V46PropositionalRuleComparison
import CategoricalEssentialIncompleteness.V46ProvableProgramEquality
import CategoricalEssentialIncompleteness.V46RealizedObjectSets
import Lean
open Lean Elab Command Meta
set_option pp.maxSteps 2000000
set_option maxRecDepth 4000
elab "#read_claim " d:ident : command => liftTermElabM do
  let n := d.getId
  let decl ← mkConstWithFreshMVarLevels n
  let type ← inferType decl
  let encoded ← forallTelescope type fun xs result => do
    -- Apply the theorem to fresh locals for every binder in its actual type.
    let applied := mkAppN decl xs
    let inferred ← inferType applied
    unless ← isDefEq inferred result do throwError "the application has the wrong result"
    let args ← xs.mapM fun x => do
      let localDecl ← x.fvarId!.getDecl
      return Json.mkObj [("binder",toJson localDecl.userName.toString),("type",toJson (← ppExpr localDecl.type).pretty)]
    return Json.mkObj [("parameters",Json.arr args),("conclusion",toJson (← ppExpr result).pretty)]
  let moduleName ← findModuleOf? n
  let axioms ← Lean.collectAxioms n
  logInfo ("READ_CLAIM " ++ (Json.mkObj [("name",toJson n.toString),("module",toJson (moduleName.map Name.toString)),("applied",encoded),("axioms",toJson (axioms.map Name.toString))]).compress)

#read_claim CategoricalEssentialIncompleteness.V46.PrimitiveRecursiveTags.selectedList_eval
#read_claim CategoricalEssentialIncompleteness.V46.PrimitiveRecursiveTags.selected_membership_PA
#read_claim CategoricalEssentialIncompleteness.V46.PrimitiveRecursiveTags.tag_coherent_PA
#read_claim CategoricalEssentialIncompleteness.V46.ProgramOrder.RecognizesOrder
#read_claim CategoricalEssentialIncompleteness.V46.ProgramOrder.apply_point
#read_claim CategoricalEssentialIncompleteness.V46.ProgramOrder.constant_diagonal_codes
#read_claim CategoricalEssentialIncompleteness.V46.ProgramOrder.diagonal_point
#read_claim CategoricalEssentialIncompleteness.V46.ProgramOrder.exists_code
#read_claim CategoricalEssentialIncompleteness.V46.ProgramOrder.exists_nontrivial_terminal_predicate
#read_claim CategoricalEssentialIncompleteness.V46.ProgramOrder.program
#read_claim CategoricalEssentialIncompleteness.V46.ProgramOrder.terminal_nonzero
#read_claim CategoricalEssentialIncompleteness.V46.ProgramOrder.terminal_predicate_of_coded_order
#read_claim CategoricalEssentialIncompleteness.V46.ProgramOrder.terminate_point
#read_claim CategoricalEssentialIncompleteness.V46.PropositionalAssociatedIncompleteness.associated_incompleteness
#read_claim CategoricalEssentialIncompleteness.V46.PropositionalAssociatedIncompleteness.associated_reduction
#read_claim CategoricalEssentialIncompleteness.V46.PropositionalClosureTransfer.backward_closed
#read_claim CategoricalEssentialIncompleteness.V46.PropositionalClosureTransfer.forward_closed
#read_claim CategoricalEssentialIncompleteness.V46.PropositionalRules.axioms
#read_claim CategoricalEssentialIncompleteness.V46.PropositionalRules.closed_iff
#read_claim CategoricalEssentialIncompleteness.V46.PropositionalRules.least_theorems
#read_claim CategoricalEssentialIncompleteness.V46.PropositionalRules.rules
#read_claim CategoricalEssentialIncompleteness.V46.PropositionalRuleComparison.generated_le
#read_claim CategoricalEssentialIncompleteness.V46.PropositionalRuleComparison.translation
#read_claim CategoricalEssentialIncompleteness.V46.ProvableProgramEquality.applicationGraph
#read_claim CategoricalEssentialIncompleteness.V46.ProvableProgramEquality.applicationGraph_eval
#read_claim CategoricalEssentialIncompleteness.V46.ProvableProgramEquality.applicationGraph_functional
#read_claim CategoricalEssentialIncompleteness.V46.ProvableProgramEquality.applicationGraph_pair
#read_claim CategoricalEssentialIncompleteness.V46.ProvableProgramEquality.precomplete
#read_claim CategoricalEssentialIncompleteness.V46.ProvableProgramEquality.totalizer
#read_claim CategoricalEssentialIncompleteness.V46.ProvableProgramEquality.totalizer_computable
#read_claim CategoricalEssentialIncompleteness.V46.ProvableProgramEquality.totalizer_eqIndex
#read_claim CategoricalEssentialIncompleteness.V46.ProvableProgramEquality.uniform_totalization
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.coding
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.codingOfRealization
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.codingOfRealization_unique
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.coding_inl
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.coding_inr
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.coding_ordinal
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.coding_product
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.coding_program
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.firstProjection
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.firstProjection_product
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.infinite_realize
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.inverse_coding_program
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.mem_firstProjection
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.mem_range_realize_iff
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.mem_secondProjection
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.members
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.objectEquiv
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.objectSet
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.omega_ne_product
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.omega_ne_taggedUnion
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.ordinal
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.ordinalEquiv
#read_claim CategoricalEssentialIncompleteness.V46.RealizedObjectSets.ordinal_injective
