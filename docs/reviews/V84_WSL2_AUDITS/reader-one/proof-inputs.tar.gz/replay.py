"""Replay a v84 reader-one input bundle against the built, pinned Lean checkout."""
from pathlib import Path
import argparse, gzip, hashlib, json, subprocess, tempfile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('checkout', type=Path)
    parser.add_argument('--only', nargs='+', metavar='INPUT')
    args = parser.parse_args()
    bundle = Path(__file__).resolve().parent
    checkout = args.checkout.resolve()
    receipt = json.loads((bundle / 'receipt.json').read_text())
    commit = subprocess.check_output(['git', '-C', str(checkout), 'rev-parse', 'HEAD'], text=True).strip()
    if commit != receipt['tested_commit']:
        raise SystemExit('The checkout is at a different revision')
    subprocess.run(['git', '-C', str(checkout), 'diff', '--quiet', commit, '--', 'Lean', 'manuscript/latex'], check=True)
    for row in receipt['commands']:
        name = row['input']
        if args.only and name not in args.only:
            continue
        path = bundle / name
        if hashlib.sha256(path.read_bytes()).hexdigest() != row['input_sha256']:
            raise SystemExit(f'Input hash differs for {name}')
        result = subprocess.run([*receipt['argv'], str(path)], cwd=checkout / 'Lean', stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        count = sum(line.startswith(b'READ_CLAIM ') for line in result.stdout.splitlines())
        if result.returncode or count != row['typed_applications']:
            raise SystemExit(f'{name} failed: {result.stdout[-3000:].decode(errors="replace")}')
        if hashlib.sha256(result.stdout).hexdigest() != row['output_sha256']:
            raise SystemExit(f'{name} produced different declarations or types')
        print(name, 'passed', count)


if __name__ == '__main__':
    main()
