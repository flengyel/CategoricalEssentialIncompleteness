import CategoricalEssentialIncompleteness.V46IndexedAxiomPresentations
import CategoricalEssentialIncompleteness.V46IndexedAxiomPresentationsChecks
import CategoricalEssentialIncompleteness.V46InductiveDefinitionChecks
import CategoricalEssentialIncompleteness.V46Inference
import CategoricalEssentialIncompleteness.V46InitialRuleDiagrams
import CategoricalEssentialIncompleteness.V46JaniczakFOL
import CategoricalEssentialIncompleteness.V46JaniczakNativeDecision
import CategoricalEssentialIncompleteness.V46JaniczakSignedTheory
import CategoricalEssentialIncompleteness.V46JaniczakSignedTheoryChecks
import CategoricalEssentialIncompleteness.V46Karoubi
import Lean
open Lean Elab Command Meta
set_option pp.maxSteps 2000000
set_option maxRecDepth 4000
elab "#read_claim " d:ident : command => liftTermElabM do
  let n := d.getId
  let decl ← mkConstWithFreshMVarLevels n
  let type ← inferType decl
  let encoded ← forallTelescope type fun xs result => do
    -- Apply the theorem to fresh locals for every binder in its actual type.
    let applied := mkAppN decl xs
    let inferred ← inferType applied
    unless ← isDefEq inferred result do throwError "the application has the wrong result"
    let args ← xs.mapM fun x => do
      let localDecl ← x.fvarId!.getDecl
      return Json.mkObj [("binder",toJson localDecl.userName.toString),("type",toJson (← ppExpr localDecl.type).pretty)]
    return Json.mkObj [("parameters",Json.arr args),("conclusion",toJson (← ppExpr result).pretty)]
  let moduleName ← findModuleOf? n
  let axioms ← Lean.collectAxioms n
  logInfo ("READ_CLAIM " ++ (Json.mkObj [("name",toJson n.toString),("module",toJson (moduleName.map Name.toString)),("applied",encoded),("axioms",toJson (axioms.map Name.toString))]).compress)

#read_claim CategoricalEssentialIncompleteness.V46.IndexedAxiomPresentations.equivalenceSentence
#read_claim CategoricalEssentialIncompleteness.V46.IndexedAxiomPresentations.provable_equivalence_enumerable
#read_claim CategoricalEssentialIncompleteness.V46.IndexedAxiomPresentations.standardAxioms
#read_claim CategoricalEssentialIncompleteness.V46.IndexedAxiomPresentations.Checks.indexed_axiom_presentations
#read_claim CategoricalEssentialIncompleteness.V46.InductiveDefinition.Checks.least_closed_iff_finite_proofs
#read_claim CategoricalEssentialIncompleteness.V46.RulePresentation.inference
#read_claim CategoricalEssentialIncompleteness.V46.RulePresentation.inference_preservesRegularEpis
#read_claim CategoricalEssentialIncompleteness.V46.RulePresentation.least_theorem_subobject
#read_claim CategoricalEssentialIncompleteness.V46.InitialRuleDiagrams.initial
#read_claim CategoricalEssentialIncompleteness.V46.InitialRuleDiagrams.sourceIso
#read_claim CategoricalEssentialIncompleteness.V46.InitialRuleDiagrams.algebra
#read_claim CategoricalEssentialIncompleteness.V46.InitialRuleDiagrams.constructor_natural
#read_claim CategoricalEssentialIncompleteness.V46.InitialRuleDiagrams.fold_constructor
#read_claim CategoricalEssentialIncompleteness.V46.InitialRuleDiagrams.fold_natural
#read_claim CategoricalEssentialIncompleteness.V46.InitialRuleDiagrams.relabelling_comp
#read_claim CategoricalEssentialIncompleteness.V46.InitialRuleDiagrams.relabelling_id
#read_claim CategoricalEssentialIncompleteness.V46.InitialRuleDiagrams.transition_comp
#read_claim CategoricalEssentialIncompleteness.V46.InitialRuleDiagrams.transition_id
#read_claim Janiczak.FOL.DecidableProofs
#read_claim Janiczak.FOL.L
#read_claim Janiczak.FOL.Names
#read_claim Janiczak.FOL.consequence_iff_provable
#read_claim Janiczak.FOL.consistent_iff
#read_claim Janiczak.FOL.decidable_theorems_iff
#read_claim Janiczak.FOL.equality_in_model
#read_claim Janiczak.FOL.initialNames
#read_claim Janiczak.FOL.model
#read_claim Janiczak.FOL.relation
#read_claim Janiczak.FOL.sentence
#read_claim Janiczak.FOL.sentence_models
#read_claim Janiczak.FOL.theory
#read_claim Janiczak.FOL.translate
#read_claim Janiczak.FOL.translate_eval
#read_claim Janiczak.FOL.translated_models
#read_claim Janiczak.FOL.underBinder
#read_claim Janiczak.NativeInput.completeTheory
#read_claim Janiczak.NativeInput.completeTheory_consistent
#read_claim Janiczak.NativeInput.completeTheory_extends
#read_claim Janiczak.NativeInput.completeTheory_proves
#read_claim Janiczak.NativeInput.computable_completeTheory_words
#read_claim Janiczak.NativeInput.computable_nativeDecision
#read_claim Janiczak.NativeInput.nativeCodeTest
#read_claim Janiczak.NativeInput.nativeDecision
#read_claim Janiczak.NativeInput.nativeDecision_words
#read_claim Janiczak.FOL.decidable_native_extension
#read_claim Janiczak.FOL.signed_consistent_iff
#read_claim Janiczak.FOL.signed_essentiallyUndecidable_iff
#read_claim Janiczak.FOL.signed_janiczak
#read_claim Janiczak.SignedTheoryChecks.class_index
#read_claim Janiczak.SignedTheoryChecks.native_proof_words
#read_claim Janiczak.SignedTheoryChecks.recursive_axioms
#read_claim CategoricalEssentialIncompleteness.LocalConnectedness.EffectiveFork.Recursion.karoubiEquivalence
#read_claim CategoricalEssentialIncompleteness.LocalConnectedness.EffectiveFork.Recursion.karoubiEquivalence_source_iso
#read_claim CategoricalEssentialIncompleteness.LocalConnectedness.EffectiveFork.Recursion.karoubiInclusion_source
#read_claim CategoricalEssentialIncompleteness.LocalConnectedness.EffectiveFork.idempotentComplete_v46
