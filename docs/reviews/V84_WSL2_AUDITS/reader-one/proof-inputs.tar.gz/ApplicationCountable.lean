import CategoricalEssentialIncompleteness.CountableArithmeticModels
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic FFL.Entailment
namespace CategoricalEssentialIncompleteness.LocalConnectedness.SyntacticModel
-- The model family really is inhabited for each consistent T. A sentence holding at
-- every chosen coordinate gives an actual derivation in that same T.
example (T : ArithmeticTheory) [𝗣𝗔 ⪯ T] (hT : Consistent T)
    (φ : ArithmeticSentence) (hφ : ∀ s : ORingStructure ℕ,
      letI := s; ℕ↓[ℒₒᵣ] ⊧* T → ℕ↓[ℒₒᵣ] ⊧ φ) : Nonempty (ModelIndex T) ∧ T ⊢ φ :=
  ⟨modelIndex_nonempty T hT, complete_nat_models T φ hφ⟩
end CategoricalEssentialIncompleteness.LocalConnectedness.SyntacticModel
