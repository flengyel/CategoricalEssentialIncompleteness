import CategoricalEssentialIncompleteness.V46MillerCategory
import CategoricalEssentialIncompleteness.V46MillerCategoryConnected
import CategoricalEssentialIncompleteness.V46MillerCategoryJoins
import CategoricalEssentialIncompleteness.V46MillerCategoryRelative
import CategoricalEssentialIncompleteness.V46MillerCategoryTuring
import CategoricalEssentialIncompleteness.V46MillerCoverSemantics
import CategoricalEssentialIncompleteness.V46MillerCutApplications
import CategoricalEssentialIncompleteness.V46MillerCutDigits
import CategoricalEssentialIncompleteness.V46MillerCutDigitsStrict
import CategoricalEssentialIncompleteness.V46MillerCutInseparability
import CategoricalEssentialIncompleteness.V46MillerCutReduction
import CategoricalEssentialIncompleteness.V46MillerCutSeparatingProgram
import CategoricalEssentialIncompleteness.V46MillerDerivationTotal
import CategoricalEssentialIncompleteness.V46MillerFiniteCover
import CategoricalEssentialIncompleteness.V46MillerFirstOrder
import CategoricalEssentialIncompleteness.V46MillerFixedPoint
import CategoricalEssentialIncompleteness.V46MillerFixedPointKakutani
import CategoricalEssentialIncompleteness.V46MillerIncompleteness
import CategoricalEssentialIncompleteness.V46MillerListsStable
import CategoricalEssentialIncompleteness.V46MillerNamedProofImageData
import CategoricalEssentialIncompleteness.V46MillerNamedProofImageForward
import CategoricalEssentialIncompleteness.V46MillerNamedProofImageNativeClosure
import CategoricalEssentialIncompleteness.V46MillerNamedProofImageNativeFormulaSubstitutionComparison
import Lean
open Lean Elab Command Meta
set_option pp.maxSteps 2000000
set_option maxRecDepth 4000
elab "#read_claim " d:ident : command => liftTermElabM do
  let n := d.getId
  let decl ← mkConstWithFreshMVarLevels n
  let type ← inferType decl
  let encoded ← forallTelescope type fun xs result => do
    -- Apply the theorem to fresh locals for every binder in its actual type.
    let applied := mkAppN decl xs
    let inferred ← inferType applied
    unless ← isDefEq inferred result do throwError "the application has the wrong result"
    let args ← xs.mapM fun x => do
      let localDecl ← x.fvarId!.getDecl
      return Json.mkObj [("binder",toJson localDecl.userName.toString),("type",toJson (← ppExpr localDecl.type).pretty)]
    return Json.mkObj [("parameters",Json.arr args),("conclusion",toJson (← ppExpr result).pretty)]
  let moduleName ← findModuleOf? n
  let axioms ← Lean.collectAxioms n
  logInfo ("READ_CLAIM " ++ (Json.mkObj [("name",toJson n.toString),("module",toJson (moduleName.map Name.toString)),("applied",encoded),("axioms",toJson (axioms.map Name.toString))]).compress)

#read_claim CategoricalEssentialIncompleteness.V46.Miller.Uniform.PointObject
#read_claim CategoricalEssentialIncompleteness.V46.Miller.Uniform.locallyConnected
#read_claim CategoricalEssentialIncompleteness.V46.Miller.Uniform.weakChoice
#read_claim CategoricalEssentialIncompleteness.V46.Miller.Uniform.comp_finiteJoin
#read_claim CategoricalEssentialIncompleteness.V46.Miller.Uniform.finiteJoin_comp
#read_claim CategoricalEssentialIncompleteness.V46.Miller.Uniform.finiteJoin_graph
#read_claim CategoricalEssentialIncompleteness.V46.Miller.Uniform.finiteJoin_least
#read_claim CategoricalEssentialIncompleteness.V46.Miller.Uniform.J
#read_claim CategoricalEssentialIncompleteness.V46.Miller.Uniform.J_value
#read_claim CategoricalEssentialIncompleteness.V46.Miller.Uniform.relative_morphism_iff
#read_claim CategoricalEssentialIncompleteness.V46.Miller.Uniform.parameterIndex_computable
#read_claim CategoricalEssentialIncompleteness.V46.Miller.Uniform.recursionCategory
#read_claim CategoricalEssentialIncompleteness.V46.Miller.Uniform.tau_isTuring
#read_claim CategoricalEssentialIncompleteness.V46.Miller.Uniform.tau_is_literal
#read_claim CategoricalEssentialIncompleteness.V46.Miller.Unanimity.search_correct
#read_claim CategoricalEssentialIncompleteness.V46.Miller.Cut.mapped_tau_notTuring
#read_claim CategoricalEssentialIncompleteness.V46.Miller.Cut.printed_cut_contrast
#read_claim CategoricalEssentialIncompleteness.V46.Miller.Cut.printed_cut_inseparability
#read_claim CategoricalEssentialIncompleteness.V46.Miller.CutDigits.fixed_representation_separator
#read_claim CategoricalEssentialIncompleteness.V46.Miller.CutDigits.lowerIdem
#read_claim CategoricalEssentialIncompleteness.V46.Miller.CutDigits.upperIdem
#read_claim CategoricalEssentialIncompleteness.V46.Miller.CutInseparability.source_diagonal_inseparable
#read_claim CategoricalEssentialIncompleteness.V46.Miller.Cut.printed_cut_reduction
#read_claim CategoricalEssentialIncompleteness.V46.Miller.Cut.reduction_computable
#read_claim CategoricalEssentialIncompleteness.V46.Miller.Cut.reduction_lower
#read_claim CategoricalEssentialIncompleteness.V46.Miller.Cut.reduction_upper
#read_claim CategoricalEssentialIncompleteness.V46.Miller.Cut.reduction_value
#read_claim CategoricalEssentialIncompleteness.V46.Miller.Cut.uniform_cut_reduction
#read_claim CategoricalEssentialIncompleteness.V46.Miller.Cut.separatingReal_program
#read_claim CategoricalEssentialIncompleteness.V46.Miller.Derivation.Canonical.derivationInitial
#read_claim CategoricalEssentialIncompleteness.V46.Miller.Derivation.Canonical.fold_underlying_unique
#read_claim CategoricalEssentialIncompleteness.V46.Miller.FiniteCover.covers_iff
#read_claim CategoricalEssentialIncompleteness.V46.Miller.FiniteCover.covers_primrec
#read_claim CategoricalEssentialIncompleteness.V46.Miller.FirstOrder.generatedSentence_least
#read_claim CategoricalEssentialIncompleteness.V46.Miller.FirstOrder.proofInitial
#read_claim CategoricalEssentialIncompleteness.V46.Miller.FirstOrder.sentence_idempotent_represents
#read_claim CategoricalEssentialIncompleteness.V46.Miller.exists_coordinate_fixedPoint
#read_claim CategoricalEssentialIncompleteness.V46.Miller.exists_isMiller
#read_claim CategoricalEssentialIncompleteness.V46.Miller.FixedPoint.caratheodory_1
#read_claim CategoricalEssentialIncompleteness.V46.Miller.FixedPoint.closedGraph
#read_claim CategoricalEssentialIncompleteness.V46.Miller.FixedPoint.convex_comb
#read_claim CategoricalEssentialIncompleteness.V46.Miller.FixedPoint.kakutani_fixed_point
#read_claim CategoricalEssentialIncompleteness.V46.Miller.FixedPoint.mem_of_convex_comb
#read_claim CategoricalEssentialIncompleteness.V46.Miller.FixedPoint.set_valued_map_approx_fixed_point
#read_claim CategoricalEssentialIncompleteness.V46.Miller.FixedPoint.sub_ICC_of_convex_comb
#read_claim CategoricalEssentialIncompleteness.V46.Miller.Incompleteness.essential_incompleteness
#read_claim CategoricalEssentialIncompleteness.V46.Miller.Incompleteness.native_incomplete
#read_claim CategoricalEssentialIncompleteness.V46.Miller.Lists.stable
#read_claim CategoricalEssentialIncompleteness.V46.Miller.NamedProofImage.proofInitial
#read_claim CategoricalEssentialIncompleteness.V46.Miller.NamedProofImage.finite_realizes
#read_claim CategoricalEssentialIncompleteness.V46.Miller.NamedProofImage.generalization_finite
#read_claim CategoricalEssentialIncompleteness.V46.Miller.NamedProofImage.modusPonens_finite
#read_claim CategoricalEssentialIncompleteness.V46.Miller.NamedProofImage.NativeSubstitution.decodedResult_eq_substitute
#read_claim CategoricalEssentialIncompleteness.V46.Miller.NamedProofImage.NativeSubstitution.formulaOptionValue_eq_native
#read_claim CategoricalEssentialIncompleteness.V46.Miller.NamedProofImage.NativeSubstitution.formulaState_comparison
