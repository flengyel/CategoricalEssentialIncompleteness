import CategoricalEssentialIncompleteness.V46ForkTupleTuring
import CategoricalEssentialIncompleteness.V46ForkTupleTuringChecks
import CategoricalEssentialIncompleteness.V46ForkTupleTuringComponents
import CategoricalEssentialIncompleteness.V46ForkTupleTuringFibres
import CategoricalEssentialIncompleteness.V46ForkTupleTuringParameters
import CategoricalEssentialIncompleteness.V46ForkTupleTuringPoints
import CategoricalEssentialIncompleteness.V46ForkUndecidedAtoms
import CategoricalEssentialIncompleteness.V46ForwardRuleRelabelling
import CategoricalEssentialIncompleteness.V46IndexedAxiomPresentations
import Lean
open Lean Elab Command Meta
set_option pp.maxSteps 2000000
set_option maxRecDepth 4000
elab "#read_claim " d:ident : command => liftTermElabM do
  let n := d.getId
  let decl ← mkConstWithFreshMVarLevels n
  let type ← inferType decl
  let encoded ← forallTelescope type fun xs result => do
    -- Apply the theorem to fresh locals for every binder in its actual type.
    let applied := mkAppN decl xs
    let inferred ← inferType applied
    unless ← isDefEq inferred result do throwError "the application has the wrong result"
    let args ← xs.mapM fun x => do
      let localDecl ← x.fvarId!.getDecl
      return Json.mkObj [("binder",toJson localDecl.userName.toString),("type",toJson (← ppExpr localDecl.type).pretty)]
    return Json.mkObj [("parameters",Json.arr args),("conclusion",toJson (← ppExpr result).pretty)]
  let moduleName ← findModuleOf? n
  let axioms ← Lean.collectAxioms n
  logInfo ("READ_CLAIM " ++ (Json.mkObj [("name",toJson n.toString),("module",toJson (moduleName.map Name.toString)),("applied",encoded),("axioms",toJson (axioms.map Name.toString))]).compress)

#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.tau_isTuring
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.binaryValue
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.endpoint
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.endpointIndex
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.endpointIndex_computable
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.endpointIso
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.endpointParameter
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.endpointParameter_graph
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.endpointParameter_total
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.endpointProgram
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.endpointTau
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.endpointTau_code
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.endpointTau_isTuring
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.endpointTau_value
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.labelCode_hom
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.labelCode_inv
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.tau
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.tau_code
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.universal
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.val_eqToHom
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.Checks.center_computation
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.Checks.endpoint_graphs
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.Checks.endpoint_morphisms
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.Checks.endpoint_parameter
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.Checks.fork_morphism
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.Checks.fork_parameter
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.left_isTuring
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.right_isTuring
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.component_fibre
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.forkParameter_total
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.fork_parameterizes
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.center_tuple_graph
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.left_graph
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.right_graph
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.binaryValue_graph
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.codedPairPoint
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.endpoint_graph
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.pairPoint
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.pairPoint_fst
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.pairPoint_snd
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.pairPoint_value
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.point₂
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.point₄
#read_claim CategoricalEssentialIncompleteness.V46.ForkTupleEvaluation.tupleProductCoding
#read_claim CategoricalEssentialIncompleteness.LocalConnectedness.ForkSyntax.axioms_undecided_atom
#read_claim CategoricalEssentialIncompleteness.LocalConnectedness.ForkSyntax.endpoint_undecided_atom
#read_claim CategoricalEssentialIncompleteness.LocalConnectedness.ForkSyntax.exists_undecided_atom
#read_claim CategoricalEssentialIncompleteness.V46.ForwardRuleRelabelling.comparison
#read_claim CategoricalEssentialIncompleteness.V46.ForwardRuleRelabelling.fold_constructor
#read_claim CategoricalEssentialIncompleteness.V46.ForwardRuleRelabelling.unique
#read_claim CategoricalEssentialIncompleteness.V46.ForwardRuleRelabelling.input_comp
#read_claim CategoricalEssentialIncompleteness.V46.ForwardRuleRelabelling.input_identity
#read_claim CategoricalEssentialIncompleteness.V46.IndexedAxiomPresentations.axiomPredicate
#read_claim CategoricalEssentialIncompleteness.V46.IndexedAxiomPresentations.emptyIndex_axioms
#read_claim CategoricalEssentialIncompleteness.V46.IndexedAxiomPresentations.equal_standard_axioms_unprovable
