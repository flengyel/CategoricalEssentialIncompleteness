import CategoricalEssentialIncompleteness.V46SignedFirstOrderIncompleteness
open CategoryTheory CategoryTheory.Limits CategoryTheory.RestrictionCategory
open CategoricalEssentialIncompleteness CategoricalEssentialIncompleteness.LocalConnectedness
open CategoricalEssentialIncompleteness.V46
open RestrictionSubobjects RecursionCategory
universe v u
-- A particular separator refutes essential incompleteness, using the transported join.
example {R : Type u} [Category.{v} R] [PCategoryStruct R] [PCategory R]
    [HasZeroMorphisms R] [Prodominical R] [Isotype R] (r : PRecursionCategory R)
    [Regular (Tot (SplitObject R))] [FinitaryExtensive (Tot (SplitObject R))]
    (i : MonoInverses (SplitObject R)) {V X : Tot (SplitObject R)}
    (F : NullaryPresentations V) (a b : Subobject X) (hd : a ⊓ b = ⊥)
    (hc : (F.presentation X).Consistent (SignedFirstOrder.theory F a b).val) :
    letI := domainJoins i
    ∀ c n : Idem X.obj, Complementary c n → domain i a ≤ c → domain i b ≤ n →
      ¬ (F.presentation X).EssentiallyIncomplete (SignedFirstOrder.theory F a b) := by
  let _ := domainJoins i
  intro c n h ha hb hEI
  exact (SignedFirstOrder.essential_incomplete_iff_no_domain_separator r i F a b hd hc).mp hEI
    ⟨c,n,h,ha,hb⟩

-- The subobject formulation already works in a general regular extensive total category.
example {S : Type u} [Category.{v} S] [RestrictionCategory S] [Splits S]
    [Regular (Tot S)] [FinitaryExtensive (Tot S)] {V X : Tot S}
    (F : NullaryPresentations V) (a b : Subobject X) (hd : a ⊓ b = ⊥)
    (hc : (F.presentation X).Consistent (SignedFirstOrder.theory F a b).val)
    (h : ¬ ∃ p n : Subobject X, IsCompl p n ∧ a ≤ p ∧ b ≤ n) :
    (F.presentation X).EssentiallyIncomplete (SignedFirstOrder.theory F a b) := by
  apply (SignedFirstOrder.essential_incomplete_iff_subobject_inseparable F a b hd hc).mpr
  refine ⟨hd, ?_⟩
  rintro ⟨s, ha, hb⟩
  exact h ⟨s.positive, s.negative, s.complementary, ha, hb⟩

-- Start with two concrete domains in arbitrary split S. No zero morphisms, restriction
-- zero, binary joins, recursion object or presentation of S as a splitting is supplied.
example {S : Type u} [Category.{v} S] [RestrictionCategory S] [Splits S]
    [Regular (Tot S)] [FinitaryExtensive (Tot S)] (i : MonoInverses S)
    {V X : Tot S} (F : NullaryPresentations V) (a b : Subobject X)
    (hd : a ⊓ b = ⊥) (hc : (F.presentation X).Consistent (SignedFirstOrder.theory F a b).val)
    (p n : Idem X.obj) (hm : p ⊓ n = orderIso i X ⊥)
    (hj : orderIso i X ((orderIso i X).symm p ⊔ (orderIso i X).symm n) = ⊤)
    (ha : orderIso i X a ≤ p) (hb : orderIso i X b ≤ n) :
    ¬ (F.presentation X).EssentiallyIncomplete (SignedFirstOrder.theory F a b) := by
  intro h
  exact (SignedFirstOrder.essential_incomplete_iff_no_complementary_domains i F a b hd hc).mp h
    ⟨p,n,⟨hm,hj⟩,ha,hb⟩

example {S : Type u} [Category.{v} S] [RestrictionCategory S] [Splits S]
    [Regular (Tot S)] [FinitaryExtensive (Tot S)]
    [HasZeroMorphisms S] [RestrictionZero S] [BinaryJoins S]
    (i : MonoInverses S) (X : Tot S) (p n : Idem X.obj) (hc : Complementary p n) :
    IsCompl ((orderIso i X).symm p) ((orderIso i X).symm n) :=
  (complementaryDomains_iff i X p n).mp ((complementaryDomains_iff_complementary i X p n).mpr hc)
