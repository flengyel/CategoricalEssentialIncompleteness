import CategoricalEssentialIncompleteness.V46OracleSeparatorLift
open CategoryTheory CategoryTheory.CoprodStruct CategoryTheory.HasCoproducts
open CategoricalEssentialIncompleteness.LocalConnectedness
namespace CategoricalEssentialIncompleteness.LocalConnectedness.OracleComputation

-- Two independently chosen second coordinates give the same halting test.
example (n a b : ℕ) : n ∈ K ↔
    Nat.pair (Encodable.encode (simulationCode n)) a ∈ A ∧
    Nat.pair (Encodable.encode (simulationCode n)) b ∈ A :=
  ⟨fun h => ⟨(K_iff_simulation_mem_A n a).mp h, (K_iff_simulation_mem_A n b).mp h⟩,
   fun h => (K_iff_simulation_mem_A n b).mpr h.2⟩

-- The freely varying outputs are observed only through their two summands.
example (s : ℕ →. (ℕ ⊕ ℕ))
    (h₀ : ∀ n, (∃ y : ℕ, Sum.inl y ∈ s n) ↔ n ∉ A)
    (h₁ : ∀ n, (∃ y : ℕ, Sum.inr y ∈ s n) ↔ n ∈ A) :
    (∀ n, (s n).Dom) ∧
    (¬ ∃ f : ℕ → ℕ ⊕ ℕ, Computable f ∧ s = fun n => Part.some (f n)) ∧
    (¬ ∃ ℓ : Restricted.N K ⟶ coprod (Restricted.N K) (Restricted.N K),
         (Restricted.inclusion K).map ℓ = s) := by
  obtain ⟨ht, hn⟩ := Restricted.total_and_noncomputable_of_output_summands s h₀ h₁
  exact ⟨ht, hn, Restricted.no_lift_of_output_summands s h₀ h₁⟩

example (u : Restricted.N K ⟶ Restricted.N K) :
    (Restricted.inclusion K).map u ≠ Restricted.missingSection ≫
      ((Restricted.inclusion K).mapIso (Restricted.parityIso K)).inv :=
  fun e => Restricted.missingSection_endomorphism_has_no_lift ⟨u,e⟩
end CategoricalEssentialIncompleteness.LocalConnectedness.OracleComputation
