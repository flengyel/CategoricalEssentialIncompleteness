import CategoricalEssentialIncompleteness.V46TrivialDominicalCategory

noncomputable section
open CategoryTheory CategoryTheory.Limits
open CategoricalEssentialIncompleteness CategoricalEssentialIncompleteness.V46
open CategoricalEssentialIncompleteness.LocalConnectedness
set_option autoImplicit false

namespace FirstReading
universe u v
open PCategoryStruct CoprodStruct TrivialDominicalCategory in
theorem discrete_exception :
    DiPaolaHeller.IsTuringMorphism evaluator ∧
      ¬ Inseparable (Idem.pull (diag One.obj ≫ evaluator) (summand0 One.obj One.obj))
        (Idem.pull (diag One.obj ≫ evaluator) (summand1 One.obj One.obj)) := by
  exact ⟨evaluator_turing, diagonal_pair_separated⟩


#print axioms discrete_exception
end FirstReading
