import CategoricalEssentialIncompleteness.V46SignedSubobjectIncompleteness

noncomputable section
open CategoryTheory CategoryTheory.Limits
open CategoricalEssentialIncompleteness CategoricalEssentialIncompleteness.V46
open CategoricalEssentialIncompleteness.LocalConnectedness
set_option autoImplicit false

namespace FirstReading
universe u v
-- Every closed extension in the same internal language is quantified here.
theorem separator_and_closed_extensions {D : Type u} [Category.{v} D] [Regular D]
    [FinitaryExtensive D] {X V : D} (F : NullaryPresentations V) (a b : Subobject X)
    (ab : a ⊓ b = ⊥) (con : (F.presentation X).Consistent (SignedFirstOrder.theory F a b).val) :
    SubobjectInseparable a b ↔
      ∀ U : (F.presentation X).Theories, (SignedFirstOrder.theory F a b).val ≤ U.val →
        (F.presentation X).Consistent U.val →
        U.val ⊔ (Subobject.pullback (F.presentation X).syntaxData.sentenceNegation).obj U.val ≠ ⊤ := by
  constructor
  · intro h U extn hc
    exact ((SignedFirstOrder.essential_incomplete_iff_subobject_inseparable F a b ab con).mpr h).2 U extn hc
  · intro h
    exact (SignedFirstOrder.essential_incomplete_iff_subobject_inseparable F a b ab con).mp ⟨con, h⟩


#print axioms separator_and_closed_extensions
end FirstReading
