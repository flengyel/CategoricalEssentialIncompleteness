import CategoricalEssentialIncompleteness.V46EffectiveExtensibility

noncomputable section
open CategoricalEssentialIncompleteness CategoricalEssentialIncompleteness.V46
open FFL FFL.FirstOrder FFL.Entailment
set_option autoImplicit false

namespace FirstReading
universe u v
theorem consistent_presentation_without_independent_sentence :
    ∃ T : Theory Janiczak.FOL.L, Entailment.Consistent T ∧
      ComputablePred (fun n : ℕ => ∃ φ : Sentence Janiczak.FOL.L, Encodable.encode φ = n ∧ φ ∈ T) ∧
      ∀ φ : Sentence Janiczak.FOL.L, (T ⊢ φ) ∨ (T ⊢ ∼φ) := by
  classical
  obtain ⟨T, hc, hdec, h⟩ := EffectiveExtensibility.exists_complete_presentation_without_extender
  refine ⟨T, hc, hdec, ?_⟩
  intro φ
  by_contra! hind
  apply h (fun _ => ∅) ⟨0, rfl⟩
  exact ⟨fun _ => φ, fun _ _ => by simpa using hind⟩


#print axioms consistent_presentation_without_independent_sentence
end FirstReading
