#!/usr/bin/env bash
set -u
probe_dir="$(cd "$(dirname "$0")" && pwd)"
repo_dir="$(git -C "$probe_dir" rev-parse --show-toplevel)"
cd "$repo_dir/Lean" || exit 1
exit_code=0
for n in 1 2 3 4 5
do
  file="Independent$n.lean"
  lake env lean --memory=4096 -DwarningAsError=true "$probe_dir/$file" > "$probe_dir/Independent$n.log" 2>&1
  step=$?
  echo "$file $step"
  if test "$step" -ne 0 ; then exit_code=1 ; fi
done
exit "$exit_code"
