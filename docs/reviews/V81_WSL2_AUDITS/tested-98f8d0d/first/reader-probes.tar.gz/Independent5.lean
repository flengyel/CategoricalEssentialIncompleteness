import CategoricalEssentialIncompleteness.V46ArithmeticUniformIndependent

noncomputable section
open CategoryTheory CategoryTheory.Limits
open CategoricalEssentialIncompleteness CategoricalEssentialIncompleteness.V46
open CategoricalEssentialIncompleteness.LocalConnectedness
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic FFL.Entailment
set_option autoImplicit false

namespace FirstReading
universe u v
open NamedArithmeticSignature in
theorem one_sentence_morphism :
    ∃ q : ArithmeticIndexedAxioms.parameter ⟶ ArithmeticIndexedAxioms.sentence,
      ∀ e : ℕ, Entailment.Consistent (ArithmeticNamedProofConnectives.system (ArithmeticUniformIndependent.gamma e)) →
        ∃ φ : Formula, formulaCode φ =
          ((PredicateInterpretation.canonicalDomainFunctor 𝗣𝗔 ℕ).map q
            (NamedArithmeticLiteralTotal.omegaPoint 𝗣𝗔 ℕ e)).val.val ∧ φ.freeVariables = [] ∧
          ¬ (SyntacticNamedHilbert.Derives functionSymbols relationSymbols bound (ArithmeticUniformIndependent.gamma e) φ ∨
            SyntacticNamedHilbert.Derives functionSymbols relationSymbols bound (ArithmeticUniformIndependent.gamma e) (.neg φ)) := by
  obtain ⟨q, h⟩ := ArithmeticUniformIndependent.uniform_independent_sentences
  refine ⟨q, ?_⟩
  intro e hc
  obtain ⟨φ, closed, word, pos, neg⟩ := h e hc
  exact ⟨φ, word, closed, not_or_intro pos neg⟩


#print axioms one_sentence_morphism
end FirstReading
