from pathlib import Path
import csv
import gzip
import os
import re
import subprocess
import sys

base=Path(__file__).resolve().parent
root=Path(subprocess.check_output(['git','-C',str(base),'rev-parse','--show-toplevel'],text=True).strip())
data=list(csv.DictReader((base/'numbered-declarations.tsv').open(),delimiter='\t'))
unique={}
for a in data:
    if a['qualified_name'] and a['line_or_reference_kind']!='module':
        unique.setdefault(a['qualified_name'],a['Lean_module'])
groups=[]
current={}
for name,module in unique.items():
    if current and (len(current)>=60 or (len(set(current.values()))>=22 and module not in current.values())):
        groups.append(current)
        current={}
    current[name]=module
if current:groups.append(current)
scratch=base/'numbered-probes';scratch.mkdir(exist_ok=True)
for i,g in enumerate(groups,1):
    (scratch/f'{i:02d}.lean').write_text('\n'.join('import '+m for m in sorted(set(g.values())))+
        '\n\nset_option pp.universes false\n\n'+'\n'.join('#check @'+n for n in g)+'\n')
print(f'{len(unique)} qualified declarations, {len(groups)} batches.',flush=True)
if sys.argv[1:] not in (['run'], ['retry']):sys.exit()
retry = sys.argv[1:] == ['retry']
statuses=[]
for i,g in enumerate(groups,1):
    file=scratch/f'{i:02d}.lean';log=file.with_suffix('.log')
    prev=log.read_text() if log.exists() else ''
    verified=prev.count('\n@CategoricalEssentialIncompleteness.') + int(prev.startswith('@CategoricalEssentialIncompleteness.')) == len(g) and 'error:' not in prev and 'error(' not in prev
    if not retry or not verified:
        with log.open('w') as stream:
            run=subprocess.run(['lake','env','lean','--memory=4096','-j1','-DwarningAsError=true',str(file)],cwd=root/'Lean',stdout=stream,stderr=subprocess.STDOUT)
        code=run.returncode
    else:
        code=0
    statuses.append({'batch':i,'declarations':len(g),'exit':code})
    print(i,len(g),code,flush=True)
if all(q['exit']==0 for q in statuses):
    with (base/'numbered-types.txt.gz').open('wb') as dest:
        with gzip.GzipFile(fileobj=dest,mode='wb',mtime=0) as z:
            for i,g in enumerate(groups,1):z.write((scratch/f'{i:02d}.log').read_bytes())
sys.exit(int(any(s['exit']!=0 for s in statuses)))
