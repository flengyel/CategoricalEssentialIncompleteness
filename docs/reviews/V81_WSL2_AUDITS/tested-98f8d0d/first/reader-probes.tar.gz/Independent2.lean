import CategoricalEssentialIncompleteness.V46MillerFixedPoint

noncomputable section
open CategoricalEssentialIncompleteness CategoricalEssentialIncompleteness.V46
set_option autoImplicit false

namespace FirstReading
universe u v
open Miller in
theorem indexed_miller_witness :
    ∃ a : ℕ → Set.Icc (0 : ℝ) 1,
      ∀ (d : ℕ) (r : Set.Icc (0 : ℝ) 1),
      (∀ p : ℕ → Fin 2, rho p = a → ∀ k : ℕ, ∃ n : ℕ,
        n ∈ OracleProgram.numberedEval d p k ∧
        |(Rationals.q n : ℝ) - (r : ℝ)| < ((2 : ℝ) ^ k)⁻¹) → r = a d := by
  obtain ⟨a, h⟩ := exists_isMiller
  exact ⟨a, fun d r happrox => (h d r happrox).symm⟩


#print axioms indexed_miller_witness
end FirstReading
