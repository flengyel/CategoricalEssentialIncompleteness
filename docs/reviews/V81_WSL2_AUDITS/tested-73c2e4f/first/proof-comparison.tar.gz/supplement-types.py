"""Check the supplementary source-name dictionary against final Git blobs and query Lean anew."""
from pathlib import Path
import gzip, json, subprocess, hashlib, re
b=Path(__file__).resolve().parent;c=b.parent/'cei-v81-corrected'
def sha(data):return hashlib.sha256(data).hexdigest()
indexed=json.loads((b/'numbered-types.json').read_text())
old=json.loads(gzip.decompress((c/indexed['source_of_name_expansion']).read_bytes()))
extra={n:row for n,row in old['declarations'].items() if n not in indexed['declarations']}
modules={}
for row in extra.values():
 path=row['source']
 if path not in modules:
  raw=subprocess.check_output(['git','show',indexed['tested']+':'+path],cwd=c)
  assert raw==(c/path).read_bytes()
  if sha(raw)!=row['source_sha256']:
   previous=subprocess.check_output(['git','show','6775f0b3a5fb668f9390b21440f3f6c57bc65930:'+path],cwd=c)
   assert sha(previous)==row['source_sha256']
   assert re.sub(rb'/\-\-.*?\-/',b'',previous,flags=re.S)==re.sub(rb'/\-\-.*?\-/',b'',raw,flags=re.S)
   print('Changed docstring only:',path)
  modules[path]=sha(raw)
seq=sorted(extra, key=lambda n:(extra[n]['module'],n))
for i in range(3):
 part=seq[i::3]; mods=sorted({extra[n]['module'] for n in part})
 src='\n'.join('import '+m for m in mods)+'\n\nset_option format.width 150\n\n'+''.join('#check @'+n+'\n#print axioms '+n+'\n' for n in part)
 (b/('Additional'+str(i+1)+'.lean')).write_text(src)
(b/'additional-types.json').write_text(json.dumps(dict(tested=indexed['tested'],declarations={n:{key:extra[n][key] for key in ['module','source','line']} for n in seq},source_files=modules),indent=1)+'\n')
print(len(seq),len(modules))
