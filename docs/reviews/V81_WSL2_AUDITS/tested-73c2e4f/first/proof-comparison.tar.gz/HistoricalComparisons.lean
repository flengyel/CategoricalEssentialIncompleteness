import PCats.Dominical
import CategoricalEssentialIncompleteness.V46DominicalLiteratureChecks
import CategoricalEssentialIncompleteness.V46MillerFixedPointChecks
import CategoricalEssentialIncompleteness.V46ComputableTuringCategory
import CategoricalEssentialIncompleteness.V46ComputablePowerRestriction

open CategoricalEssentialIncompleteness.V46

#check @CategoryTheory.DiPaolaHeller.Dominical.toPCategory
#print axioms CategoryTheory.DiPaolaHeller.Dominical.toPCategory
#check @CategoryTheory.DiPaolaHeller.Dominical.isTotal_iff_restrictionTotal
#print axioms CategoryTheory.DiPaolaHeller.Dominical.isTotal_iff_restrictionTotal
#check @DominicalLiteratureChecks.nonzero_turing_object
#print axioms DominicalLiteratureChecks.nonzero_turing_object
#check @DominicalLiteratureChecks.fixed_point_for_partial_endomorphisms
#print axioms DominicalLiteratureChecks.fixed_point_for_partial_endomorphisms
#check @DominicalLiteratureChecks.inseparable_class_unions
#print axioms DominicalLiteratureChecks.inseparable_class_unions
#check @ApplicativeSystem.structure_of_pca
#print axioms ApplicativeSystem.structure_of_pca
#check @ApplicativeSystem.representation_restrictions
#print axioms ApplicativeSystem.representation_restrictions

theorem IndependentV81Reader.miller_at_all_names :
    ∃ a : ℕ → Set.Icc (0 : ℝ) 1, ∀ d : ℕ, ∀ r : Set.Icc (0 : ℝ) 1,
      (∀ p : ℕ → Fin 2, Miller.rho p = a → ∀ k : ℕ, ∃ i : ℕ,
        i ∈ Miller.OracleProgram.numberedEval d p k ∧
        |(Miller.Rationals.q i : ℝ) - (r : ℝ)| < ((2 : ℝ)^k)⁻¹) → a d = r :=
  Miller.exists_isMiller

#print axioms IndependentV81Reader.miller_at_all_names
