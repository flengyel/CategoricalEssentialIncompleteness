"""Resolve the final numbered table against the first reading, then generate fresh Lean queries."""
import collections
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess

b=Path(__file__).resolve().parent
c=b.parent/"cei-v81-corrected"
sha="73c2e4fa2bc633a3af012b1c4f85a7882018f962"
def git(*a):
    return subprocess.check_output(["git",*a],cwd=c)
def digest(data):
    return hashlib.sha256(data).hexdigest()
def writej(p,v):
    (b/p).write_text(json.dumps(v,ensure_ascii=False,indent=1)+"\n")
assert git("rev-parse","HEAD").decode().strip()==sha
order=(b/"order.txt").read_text().splitlines()
inputs=[]
for path in order:
    p="manuscript/latex/"+path
    content=git("show",f"{sha}:{p}")
    assert content==(b/"tex"/path).read_bytes()==(c/p).read_bytes()
    inputs.append({"source":p,"blob":git("rev-parse",f"{sha}:{p}").decode().strip(),"sha256":digest(content)})
writej("source-identity.json",dict(tested=sha,tree=git("rev-parse",sha+"^{tree}").decode().strip(),reading="ae816e93c11712a2b1fe16f99c763a8c934f80dc",active_TeX=inputs))
labels={l["label"]:l for l in (json.loads(s) for s in (b/"labels.jsonl").read_text().splitlines()) if l["label"].split(":")[0] in {"thm","lem","cor","prop","def"} and l["role"] in {"theorem","lemma","corollary","proposition","definition"}}
alias=labels.pop("thm:arithmetic-comparison-inseparability")
assert alias["block"]==labels["cor:arithmetic"]["block"] and len(labels)==80
p="FORMALIZATION_STATUS_V81.md"
table=git("show",f"{sha}:{p}").decode().splitlines()
source_dictionary="docs/reviews/V81_WSL2_AUDITS/tested-6775f0b/first/reconciliation/numbered-reconciliation.json.gz"
dictionary_bytes=git("show",f"{sha}:{source_dictionary}")
prev=json.loads(gzip.decompress(dictionary_bytes))
names=prev["declarations"]
rows=[]
groups=collections.defaultdict(set)
declarations={}
group_of={}
for ix,line in enumerate(table,1):
    mat=re.match(r"^\| (Theorem|Lemma|Corollary|Proposition|Definition) (\d+\.\d+|[A-Z]\.\d+); `([^`]+)`(?: \(alias [^)]*\))?;",line)
    if not mat:
        continue
    kind,num,label=mat.groups()
    r=next(v for v in prev["rows"] if v["label"]==label)
    assert r["kind"]==kind and r["number"]==num
    cell=line.split(" | ")[2].strip()
    assert cell==r["reference_cell"], (label,cell,r["reference_cell"])
    assert (kind.lower(),label)==(labels[label]["role"],labels[label]["label"])
    citedfile="manuscript/latex/"+labels[label]["source"]
    assert citedfile in line
    direct=sorted(set(v["name"] for v in r["direct"]))
    expanded=sorted(set(r["expanded_support_beyond_direct"]))
    group=num.split(".")[0]
    for n in direct+expanded:
        groups[group].add(n)
        d=names[n]
        declarations[n]={"module":d["module"],"source":d["source"],"line":d["line"]}
    rows.append(dict(number=num,kind=kind,label=label,source=citedfile,tex_line=labels[label]["line"],reading_cards=labels[label]["reconstruction"],ledger_line=ix,ledger_line_sha256=digest(line.encode()),cell=cell,direct=direct,module_expansions=expanded))
assert set(labels)=={r["label"] for r in rows}
files={}
for d in declarations.values():
    p=d["source"]
    if p in files:
        continue
    blob=git("rev-parse",f"{sha}:{p}").decode().strip()
    content=git("cat-file","blob",blob)
    assert content==(c/p).read_bytes()
    files[p]=dict(git_blob=blob,sha256=digest(content))
for n,d in declarations.items():
    assert files[d["source"]]["sha256"]==names[n]["source_sha256"]
direct=set(n for r in rows for n in r["direct"])
writej("numbered-types.json",dict(tested=sha,ledger="FORMALIZATION_STATUS_V81.md",source_of_name_expansion=source_dictionary,name_expansion_sha256=digest(dictionary_bytes),rows=rows,declarations=declarations,source_files=files,direct_unique=len(direct),direct_and_module_unique=len(declarations)))
for g,nameset in groups.items():
    for name in sorted(nameset):
        group_of.setdefault(name,g)
for batch,ts in {"I":["3","4","5","A"],"II":["6","7","D"],"III":["8"],"IV":["9","C"],"V":["10","B"]}.items():
    nms=sorted(n for n,g in group_of.items() if g in ts)
    mods=sorted({declarations[n]["module"] for n in nms})
    lean="\n".join("import "+m for m in mods)+"\n\nset_option format.width 150\n\n"
    lean+="".join("#check @"+n+"\n#print axioms "+n+"\n" for n in nms)
    (b/("Numbered"+batch+".lean")).write_text(lean)
    print(batch,len(nms),len(mods))
print(len(rows),len(direct),len(declarations),len(files))
