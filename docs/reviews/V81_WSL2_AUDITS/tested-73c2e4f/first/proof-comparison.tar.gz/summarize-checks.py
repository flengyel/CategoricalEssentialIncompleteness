import collections
import hashlib
import json
from pathlib import Path
import re
b=Path(__file__).resolve().parent
def loadj(path):return json.loads(path.read_text())
def dump(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=1)+'\n')
types=loadj(b/'numbered-types.json')
permitted={'propext','Classical.choice','Quot.sound'}
defs=types['declarations']
claims={}
for batch in ['I','II','III','IV','V']:
    std='Numbered'+batch
    s=(b/(std+'.lean')).read_text(); log=(b/(std+'.log')).read_text(); meta=loadj(b/(std+'.json'))
    assert meta['exit']==0 and hashlib.sha256(log.encode()).hexdigest()==meta['log_sha256'] and hashlib.sha256(s.encode()).hexdigest()==meta['source_sha256']
    expected=re.findall(r'^#print axioms (\S+)$',s,re.M)
    data=re.findall(r"^'([^']+)' (?:depends on axioms: \[([^\]]*)\]|does not depend on any axioms)",log,re.M)
    assert expected==[n for n,a in data]
    for name,ax in data:
        axioms=sorted(t.strip() for t in ax.replace('\n','').split(',') if t.strip())
        assert set(axioms)<=permitted and name not in claims
        claims[name]=dict(axioms=axioms,typed_in=std+'.log')
assert set(claims)==set(defs)
axcounts=collections.Counter(tuple(row['axioms']) for row in claims.values())
summary=dict(tested=types['tested'],queries=len(claims),numbered_statements=len(types['rows']),axiom_allowlist=sorted(permitted),axiom_combinations=[dict(axioms=list(k),count=v) for k,v in sorted(axcounts.items())],declarations=claims)
dump(b/'numbered-axioms.json',summary)
print(summary['axiom_combinations'])

more=loadj(b/'additional-types.json')['declarations']
observed={}
for batch in ['1','2','3']:
    std='Additional'+batch
    src=(b/(std+'.lean')).read_text(); log=(b/(std+'.log')).read_text(); meta=loadj(b/(std+'.json'))
    assert meta['exit']==0 and hashlib.sha256(log.encode()).hexdigest()==meta['log_sha256'] and hashlib.sha256(src.encode()).hexdigest()==meta['source_sha256']
    target=re.findall(r'^#print axioms (\S+)$',src,re.M)
    actual=re.findall(r"^'([^']+)' (?:depends on axioms: \[([^\]]*)\]|does not depend on any axioms)",log,re.M)
    assert target==[n for n,a in actual]
    for n,a in actual:
        axs=sorted(t.strip() for t in a.replace('\n','').split(',') if t.strip())
        assert set(axs)<=permitted and n not in observed
        observed[n]=dict(axioms=axs,typed_in=std+'.log')
assert set(observed)==set(more) and not (set(claims)&set(observed))
allclasses=sorted(set(tuple(d['axioms']) for d in list(claims.values())+list(observed.values())))
dump(b/'additional-axioms.json',dict(tested=types['tested'],declarations=observed,axiom_combinations=[{'axioms':list(xs),'count':sum(tuple(r['axioms'])==xs for r in observed.values())} for xs in allclasses]))
print(len(observed),'rechecked supplementary declarations')
