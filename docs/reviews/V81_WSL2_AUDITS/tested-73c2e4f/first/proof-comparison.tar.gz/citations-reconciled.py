from pathlib import Path
import collections,json
b=Path(__file__).resolve().parent;c=b.parent/'cei-v81-corrected'
cards={r['id']:r for r in [json.loads(x) for x in (b/'cards-reconciled.jsonl').read_text().splitlines()]}
rows=[json.loads(x) for x in (b/'in-text-citations.jsonl').read_text().splitlines()]
ledger='FORMALIZATION_STATUS_V81.md'; history='docs/reviews/V81_WSL2_ASSERTIONS/historical-comparisons.md';prim='docs/reviews/V80_ASSERTIONS/'
ranges={}
def register(ids,status,scope,filename,lineno):
 for i in ids:
  assert i not in ranges
  ranges[i]=(status,scope,filename+'#L'+str(lineno))
register([1,21],'attribution','Di Paola–Heller’s historical discussion of categorical formalization, modal provability and numerals.',prim+'primary01.md',17)
register([2,3,4],'attribution','Source of syntactic categories and Montagna’s question of comparison with numerical computation.',prim+'primary01.md',18)
register([5,56,57],'proved','Miller sequence at the actual numbering and every binary name. The existential supplies the subsequent conditional theorem.',ledger,42)
register([6],'open theorem','Bauer–Hanson 6.4: construct the internal Dedekind reals of the parameterized realizability topos and the epimorphism from its NNO.',history,35)
register([7,8],'proved','Dominical structure supplies P-category laws. The two definitions of totality agree.', 'Lean/PCats/Dominical.lean',164)
register([9],'definition','Heller’s use of P-categories to name and define prodominical categories.',prim+'primary9.md',26)
register([10,25],'definition','Choice of the four restriction identities from Cockett–Lack.',prim+'primary01.md',10)
register([11],'open theorem','Heller 9.2: construct Tur(B) and its evaluator under local connectedness and the B-sharp generation hypothesis.',history,42)
register([12,13],'two open theorems','Lengyel 21 and corrected 26: construct the absolute and relative completions and universal computations.',history,43)
register([14],'attribution','Di Paola–Montagna’s question on extending the existence theorem.',prim+'primary01.md',8)
register([15],'counterexample','As stated in §1 the implication also applies when the identity is zero; a complementary pair separates the diagonal in the one-arrow example.',history,17)
register([16],'proved','Fixed point, inseparable nonempty unions of classes, and the example of PA-provable partial-program equality.',history,19)
register([17],'proved','Effectively inseparable pair in the unprimed PA category with the productive total morphism at generalized program indices.',ledger,80)
register([18,76,77],'counterexample to earlier article','The v81 oracle category and faithful product-preserving zero-reflecting range functor refute the older implication lacking a conditional lift. The proof is in Appendix C.',ledger,55)
register([19,24],'proved','Turing-point predicates yield the stated inseparability and the proper nonzero restriction idempotent on the restriction terminal object under their respective hypotheses.',ledger,29)
register([20],'proved','Janiczak signed equivalence-relation theory at finite class sizes, all consistent extensions, and nonrecursive theorem-code set.',ledger,30)
register([22],'two open theorems','Van Dijk–Gietelink Oldenziel 5.19 and 5.20: universal AU-object completeness-to-triviality and the equalizer inequality for a consistent initial AU.',history,36)
register([23],'proved','Both Cockett–Hofstra 4.9 directions, including the ordinary idempotents that split in the ambient category and preservation of the restriction.',history,25)
register([26,27],'definition','Domain and least stabilizing range idempotent as used in the manuscript.',prim+'primary9.md',28)
register([28,29],'construction','Restriction idempotent splittings and the ordinary Karoubi completion, including totality in the new restriction.',ledger,31)
register([30],'construction','Partial maps as iso classes of monic spans, composed by pullback, with the indicated restriction on each arrow.',prim+'primary01.md',10)
register([31],'proved','Binary restriction products and the P-category laws determine the same structure.',prim+'01-introduction-and-comparison.md',72)
register([32,33],'definition','The paper requires a range functor to preserve restriction coproducts and zeros in addition to the range and restriction operations.',prim+'primary01.md',11)
register([34],'definition','The evaluator is indexed by a total morphism for each parameter object.',prim+'primary9.md',30)
register([35],'proved','Turing object for all typed evaluators iff the designated evaluator is Turing and each object is a retract with total section.',ledger,31)
register([36],'proved','Pull back a hypothetical decider along the computable reducing map, for each consistent extension.',history,9)
register([37],'proved','Under EPF, reverse the two semidecisions in each consistent extension and apply the diagonal at its index.',history,10)
register([38],'proved','Free formula/signature adjunction with coherent component maps, including the binder.',history,11)
register([39],'proved','Give every splitting object a Turing parameter by restricting it along the source idempotent.',prim+'04-theories-and-slices.md',51)
register([40,41,45,46,47,48],'construction','The unprimed universal provable relation and the external scheme of pointwise numeral equalities use the same object and program presentations.',prim+'primary6.md',7)
register([42,43,44,50],'proved','Uniform PA-proof of universal program graph simulation, specialization, composition and partial identity search for an arithmetic carrier.',prim+'primary6.md',8)
register([49],'proved','Every consistent c.e. extension of PA gives a failure of congruence of pointwise provable equality for the printed composition.',prim+'06-syntax-and-models.md',14)
register([51],'construction','Arithmetic predicate carriers and provably total functional graphs present the total restriction splitting.',prim+'primary6.md',10)
register([52],'proved','Łoś applied to PA axioms, carrier predicates and computation graphs at arbitrary proper ultrafilter.',prim+'primary6.md',11)
register([53],'proved with wrong printed locator','Strong numeralwise definability of all recursive sets in a consistent theory implies inseparability of theorem and refutation supports. Item (3) starts on printed p. 595.',history,13)
register([54],'ambiguous property; PA instance proved','Existence of a recursive independent-sentence selector for a fixed effective presentation, quantified over all consistent additional c.e. axioms.',history,12)
register([55],'proved','Precomplete PA program equality gives inseparability of nonempty disjoint saturated unions; application tied to the actual value-first graph.',ledger,40)
register([58],'definition','Cosheaf with covariant structure maps and the empty-cover condition.',prim+'primary9.md',9)
register([59],'definition and construction','Separated least closure under three frame operations, here realized by explicit number codings.',prim+'primary9.md',31)
register([60,61],'definition','Parameterized list recursion and formulation by initiality in each parameter slice.',prim+'primaryA.md',7)
register([62,63],'attribution','Use of initial many-sorted algebras to specify syntax; the local syntax functor is explicitly defined.',prim+'primaryA.md',8)
register([64,65,66,67],'attribution','Prior alpha-identification and binding/substitution presentations; quoted comparison with retaining the original term alongside the substitution result.',prim+'primaryA.md',9)
register([68],'proved','Finitary rule closure iff existence of a proof sequence iff existence of a finite proof tree.',history,50)
register([69],'proved','Factorization systems lift to algebras under preservation of the left class; the local argument uses the regular image.',history,51)
register([70,71,72],'definition','Specified first-order axiom schemes. Equality/substitution are subject to the manuscript’s admissibility conditions and term parameters.',prim+'primaryA.md',10)
register([73,74],'proved','Stable factorization of total maps in a split range category and regular-epi/mono characterization with right class all monos.',history,52)
register([75],'proved','Regularity yields split ranges for mono partial maps and a categorical isomorphism of their total maps with the base.',prim+'04-theories-and-slices.md',84)
register([78],'proved','Unprimed syntactic category not locally connected for every consistent c.e. T extending PA, without a soundness assumption.',ledger,56)
assert set(ranges)==set(range(1,len(rows)+1))
for i,r in enumerate(rows,1):
 status,description,anchor=ranges[i]
 path,line=anchor.split('#L');assert len((c/path).read_text().splitlines())>=int(line)
 r['disposition']=status;r['mathematical_role']=description;r['primary_comparison_or_current_application']=anchor
 r['paper_to_proof_cards']={k:cards[k]['line_dossiers'] for k in r['reconstruction']}
(b/'citations-compared.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n' for r in rows))
print(len(rows),collections.Counter(x['disposition'] for x in rows))
