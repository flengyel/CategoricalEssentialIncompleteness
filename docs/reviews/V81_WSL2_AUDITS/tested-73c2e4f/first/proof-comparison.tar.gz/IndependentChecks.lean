import CategoricalEssentialIncompleteness.V46NumericalSyntaxMembership
import CategoricalEssentialIncompleteness.V46NumericalNamedLiteralPresentation

open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open CategoricalEssentialIncompleteness.LocalConnectedness
open CategoricalEssentialIncompleteness.V46
open CategoricalEssentialIncompleteness.V46.SyntacticPredicates

namespace IndependentV81Reader

theorem membership_in_the_printed_algebra
    (d : ℕ) (σ π : ℕ → EnumerableCarriers.Total)
    (hσ : ∀ k ≤ d, ComputablePred (· ∈ (σ k).obj.support))
    (hπ : ∀ k ≤ d, ComputablePred (· ∈ (π k).obj.support)) :
    let A := NumericalNamed.literalWordAlgebra NumericalNamed.variableObject
      (fun k => NumericalTuples.unary (σ k)) (fun k => NumericalTuples.unary (π k)) d
    (∃ t : ℕ → Bool, Computable t ∧
      ∀ w : ℕ, t w = true ↔ w ∈ A.a.1.support) ∧
    (∃ f : ℕ → Bool, Computable f ∧
      ∀ w : ℕ, f w = true ↔ w ∈ A.a.2.support) := by
  have both := NumericalSyntaxMembership.numerical_word_membership σ π d hσ hπ
  obtain ⟨t, ht, htm⟩ := ComputablePred.computable_iff.mp (both false)
  obtain ⟨f, hf, hfm⟩ := ComputablePred.computable_iff.mp (both true)
  exact ⟨⟨t, ht, fun w => (iff_of_eq (congrFun htm w)).symm⟩,
         ⟨f, hf, fun w => (iff_of_eq (congrFun hfm w)).symm⟩⟩

#print axioms membership_in_the_printed_algebra
#check @NumericalNamed.literalWordParameterInitial

end IndependentV81Reader
