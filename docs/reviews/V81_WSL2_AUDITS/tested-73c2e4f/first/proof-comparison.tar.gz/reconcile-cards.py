"""Attach the post-seal line dossiers to the independent in-order manuscript reconstruction."""
from pathlib import Path
import collections
import csv
import json
import re
b=Path(__file__).resolve().parent
c=b.parent/'cei-v81-corrected'
basepath='docs/reviews/V80_ASSERTIONS/'
order=(b/'order.txt').read_text().splitlines()
ledger='FORMALIZATION_STATUS_V81.md'
history='docs/reviews/V81_WSL2_ASSERTIONS/historical-comparisons.md'
inventory='docs/reviews/V81_WSL2_ASSERTIONS/README.md'
comparison='docs/reviews/V81_PROOF_COMPARISONS/'
rlines=collections.defaultdict(list)
def register(f,i,j,intervals):
    for a,z in intervals:
        if j==21 and f.endswith('/appendices-c-e.md'):
            intervals81=[]
            if a<=105: intervals81.append([a,min(z,105)])
            if a<=114 and 106<=z: intervals81.append([106,119])
            if z>=115: intervals81.append([max(115,a)+5,z+5])
        else: intervals81=[[a,z]]
        for a1,z1 in intervals81:
            rlines[j].append((a1,z1,f,i))
def spans(a):
    parts=re.findall(r'(?<![\w.])(\d+)\s*–\s*(\d+)',re.sub(r'^[SPMDEC]\s*','',a.strip()))
    return [(int(x),int(y)) for x,y in parts]
byfile={
'01-introduction-and-comparison.md':[(11,2),(26,3),(56,4),(83,5),(105,-1)],
'04-theories-and-slices.md':[(7,6),(24,7),(44,8),(64,19),(87,-1)],
'08-arithmetic.md':[(5,12),(20,13),(34,14),(43,15),(60,16),(68,12)],
'09-miller-and-cosheaves.md':[(5,17),(26,18),(46,20)],
'appendices-c-e.md':[(5,21),(29,23)],
'06-syntax-and-models.md':[(5,9),(17,10),(33,11),(49,22),(63,-1)]}
for doc,cuts in byfile.items():
    path=basepath+doc; j=-1
    for i,s in enumerate((c/path).read_text().splitlines(),1):
        j=next((j1 for start,j1 in reversed(cuts) if i>=start),-1)
        if j>=0 and s.startswith('|'):
            rng=spans(s.split('|')[1])
            if rng: register(path,i,j,rng)
for j,texline,docline in [(12,325,7),(18,703,8),(19,333,9)]:
    register(basepath+'unnumbered-coverage.md',docline,j,[(texline,327 if j==12 else texline)])
reserve=collections.defaultdict(list)
def add(j,a,z,path,line):
    reserve[j].append((a,z,path,line))
def led(j,a,z,linenums):
    for line in linenums: add(j,a,z,ledger,line)
def hist(j,a,z,linenums):
    for line in linenums: add(j,a,z,history,line)
def cmp(j,a,z,doc):
    add(j,a,z,comparison+doc+'.md',1)
for j,a,z,lines in [
(3,124,142,[42,88]),(3,150,157,[49]),(3,161,171,[88]),(3,173,187,[29,66,77,78,79,80]),(3,189,196,[30]),(3,198,206,[88]),(3,208,217,[29,81,82]),
(4,90,97,[31]),(4,192,210,[31]),(5,3,17,[32]),(6,102,147,[33]),(6,237,254,[63,64,133]),(7,359,397,[65,93]),(7,398,475,[93]),(7,477,539,[33]),(8,176,226,[34,135]),(8,350,373,[135]),
(9,148,187,[35,137]),(10,280,322,[36]),(10,335,485,[145]),(10,522,654,[151]),(12,288,327,[39,40,139,141]),(12,329,443,[153]),(13,4,60,[37]),(14,4,21,[38,67]),(14,22,102,[41]),(15,281,302,[147]),(15,463,599,[141]),(16,5,80,[139,141]),
(17,3,46,[42]),(17,177,207,[43]),(17,558,652,[44,45]),(17,654,722,[44]),(18,3,79,[46]),(18,182,277,[47]),(18,281,331,[48]),(18,561,622,[49]),
(19,5,117,[50,51]),(19,370,450,[52,83,84]),(19,542,594,[85,86]),(19,596,623,[53]),(20,343,489,[47]),(20,573,616,[54]),(21,4,222,[55,149]),(22,61,145,[56,57,143]),(22,148,200,[57]),(23,192,239,[44])]:
    led(j,a,z,lines)
for j,a,z,ln in [(3,124,142,[35]),(3,161,171,[40,42,43,44]),(3,173,187,[17,19,21]),(3,198,206,[36]),(3,208,217,[25,27,29]),(6,237,245,[9,10]),(7,359,397,[11]),(12,239,244,[13]),(14,4,9,[12]),(19,370,450,[50,51]),(19,542,594,[52,53])]: hist(j,a,z,ln)
add(3,161,162,'Lean/PCats/Dominical.lean',164)
add(15,292,296,inventory,60)
add(15,292,296,'Lean/CategoricalEssentialIncompleteness/V46NumericalSyntaxMembership.lean',1)
add(15,292,296,'Lean/CategoricalEssentialIncompleteness/V46NumericalSyntaxMembershipChecks.lean',31)
add(21,13,14,inventory,53);add(21,106,119,inventory,55)
for j,a,z,doc in [(4,5,210,'preliminaries'),(5,3,178,'summands'),(6,5,269,'theories-and-syntax'),(7,4,539,'theories-and-syntax'),(8,4,373,'slices-and-rule-functors'),(9,3,263,'realized-sets'),(10,280,322,'finite-selector-and-models'),(11,177,545,'finite-selector-and-models'),(12,288,327,'bernardi'),(12,288,327,'named-observations'),(15,281,599,'arithmetic-coding'),(16,5,80,'named-observations'),(17,3,46,'miller-fixed-point'),(17,177,207,'weighted-metric'),(17,558,722,'miller-and-fork-applications'),(18,3,860,'fork'),(20,5,616,'fork'),(21,4,222,'external-counterexample-and-proof-links'),(23,3,239,'external-counterexample-and-proof-links')]:cmp(j,a,z,doc)
nums=json.loads((b/'numbered-types.json').read_text())['rows']
cards=list(csv.DictReader((b/'first-reading.tsv').open(),delimiter='\t'))
def references(source,j,a,z):
    return sorted({f'{f}#L{line}' for lo,hi,f,line in source[j] if lo<=z and hi>=a})
cardout=[]
for idx,row in enumerate(cards,1):
    j=int(row['input']); a,z=map(int,row['lines'].split('-')); rid=f'R1-{idx:03d}'
    sources=references(rlines,j,a,z); updates=references(reserve,j,a,z)
    foundnums=[r['number'] for r in nums if rid in r['reading_cards']]
    item={'id':rid,'input':order[j],'lines':[a,z],'independent_statement':row['independent reconstruction'],'numbered_statements_starting_here':foundnums,'line_dossiers':sources,'later_applications_and_corrections':updates}
    if j in (0,1,24): item['role']='documentary'
    else:
        assert sources,(idx,j,a,z)
        item['role']='argument, hypotheses or definition'
    cardout.append(item)
(b/'cards-reconciled.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n' for x in cardout))
print(len(cardout),'cards',sum(len(x['line_dossiers']) for x in cardout),'dossier references',sum(len(x['later_applications_and_corrections']) for x in cardout),'active and historical refinements')
print('own card counts',collections.Counter(x['input'] for x in cardout))
