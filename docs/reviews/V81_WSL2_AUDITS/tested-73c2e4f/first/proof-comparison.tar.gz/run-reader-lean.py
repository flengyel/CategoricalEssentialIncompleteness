from pathlib import Path
import sys,subprocess,fcntl,os,time,hashlib,json
b=Path(__file__).parent.resolve();root=b.parents[1];lean=b.parent/"cei-v81-corrected"/"Lean"
source=b/sys.argv[1]; t=time.time(); argv=["lake","env","lean",("--memory=4096" if source.stem.startswith(("Numbered","Additional")) or source.stem=="HistoricalComparisons" else "--memory=3200"),"-DwarningAsError=true",str(source)]
with (b.parent/"v81-corrected-verification"/"readers.lock").open("a+") as lk:
 fcntl.flock(lk,fcntl.LOCK_EX)
 print("Acquired reader lock; task",source.name,flush=True)
 with (b/(source.stem+".log")).open("w") as out:
  p=subprocess.run(argv,cwd=lean,env={**os.environ,"LEAN_NUM_THREADS":"1"},stdout=out,stderr=subprocess.STDOUT)
log=(b/(source.stem+".log")).read_bytes()
j={"argv":argv,"cwd":str(lean),"source_commit":subprocess.check_output(["git","rev-parse","HEAD"],cwd=lean,text=True).strip(),"exit":p.returncode,"seconds":round(time.time()-t,2),"source_sha256":hashlib.sha256(source.read_bytes()).hexdigest(),"log_sha256":hashlib.sha256(log).hexdigest()}
(b/(source.stem+".json")).write_text(json.dumps(j,indent=2)+"\n")
print(j,flush=True)
sys.exit(p.returncode)
