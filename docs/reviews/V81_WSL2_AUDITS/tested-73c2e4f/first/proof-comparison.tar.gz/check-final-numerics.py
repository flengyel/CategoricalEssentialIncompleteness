from pathlib import Path
from datetime import datetime,timezone
import fcntl,hashlib,json,os,subprocess,time
b=Path(__file__).resolve().parent
clean=b.parent/'cei-v81-corrected'
sha='73c2e4fa2bc633a3af012b1c4f85a7882018f962'
for base in ['V46NumericalSyntaxMembership','V46NumericalSyntaxMembershipChecks']:
    p='CategoricalEssentialIncompleteness/'+base+'.lean'
    data=(clean/'Lean'/p).read_bytes()
    assert data==subprocess.check_output(['git','show',sha+':Lean/'+p],cwd=clean)
    argv=['lake','env','lean','--memory=4096','-DwarningAsError=true',p]
    started=datetime.now(timezone.utc)
    with (b.parent/'v81-corrected-verification'/'readers.lock').open('a+') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        t=time.monotonic()
        proc=subprocess.run(argv,cwd=clean/'Lean',env={**os.environ,'LEAN_NUM_THREADS':'1'},capture_output=True)
    log=proc.stdout+proc.stderr
    (b/(base+'.log')).write_bytes(log)
    record=dict(source_commit=sha,source='Lean/'+p,git_blob=subprocess.check_output(['git','rev-parse',sha+':Lean/'+p],cwd=clean,text=True).strip(),source_sha256=hashlib.sha256(data).hexdigest(),cwd=str(clean/'Lean'),argv=argv,started=started.isoformat(),seconds=round(time.monotonic()-t,3),exit=proc.returncode,log_sha256=hashlib.sha256(log).hexdigest())
    (b/(base+'.json')).write_text(json.dumps(record,indent=2)+'\n')
    assert proc.returncode==0, record
    print(base,record['seconds'],record['exit'],flush=True)
