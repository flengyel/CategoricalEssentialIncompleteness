from pathlib import Path
import hashlib,json,re,csv
b=Path(__file__).parent
files=(b/'order.txt').read_text().splitlines()
cards=list(csv.DictReader((b/'first-reading.tsv').open(), delimiter='\t'))
for i, v in enumerate(cards,1):
 v['id']='R1-'+str(i).zfill(3)
 v['lo'],v['hi']=map(int,v['lines'].split('-'))
def keys(f,n,m):
 return [c['id'] for c in cards if c['input']==str(f) and c['lo']<=m and c['hi']>=n]
def digest(s):return hashlib.sha256(s.encode()).hexdigest()
blocks=[]; clauses=[]; refs=[]; labels=[]
envs={'theorem','lemma','proposition','corollary','definition','proof'}
def sections(p):
 lines=(b/'tex'/p).read_text().splitlines()
 buf=[]
 env='exposition'
 def flush():
  nonlocal buf
  if not buf:return
  n=buf[0][0];m=buf[-1][0];source='\n'.join(l for _,l in buf)
  role=env
  if p in ('main.tex','preamble.tex'):role='front matter'
  if p=='bibliography.tex':role='bibliographic entry'
  if re.match(r'\\(subsection|section|Needspace|input|end\{proof)',source):role='structure'
  k=files.index(p)
  aid=keys(k,n,m)
  bid='B'+str(len(blocks)+1).zfill(4)
  blocks.append(dict(id=bid,file=p,start=n,end=m,role=role,reconstruction=aid,sha256=digest(source),tex=source))
  if role not in ('structure','front matter','bibliographic entry'):
   joined=''
   line=[]
   for number,l in buf:
    if joined:joined+=' ';line.append(number)
    l=l.strip();joined+=l;line.extend([number]*len(l))
   pattern=r'(?<![ce]\.)[.!?](?:\s*\\(?:end\{(?:align\*?|equation\*?|gather\*?)\}|\]))?(?=\s+(?:[A-Z$\\(]|[a-z]\b)|$)'
   s=0
   for a in list(re.finditer(pattern,joined))+[None]:
    z=a.end() if a else len(joined)
    if z<=s:continue
    while s<z and joined[s].isspace():s+=1
    clause=joined[s:z].strip()
    if clause:
     cstart=line[s];cend=line[z-1]
     clauses.append(dict(id='S'+str(len(clauses)+1).zfill(5),block=bid,file=p,start=cstart,end=cend,role=role,reconstruction=keys(k,cstart,cend),tex=clause))
    s=z
  for q in re.finditer(r'\\cite(?:\[([^\]]*)\])?\{([^}]+)\}',source):
   for name in q[2].split(','):
    refs.append(dict(source=p,line=n+source[:q.start()].count('\n'),item=name,locator=q[1],block=bid,reconstruction=aid))
  for q in re.finditer(r'\\label\{([^}]+)\}',source):labels.append(dict(source=p,line=n+source[:q.start()].count('\n'),label=q[1],role=role,block=bid,reconstruction=aid))
  buf=[]
 for i,l in enumerate(lines,1):
  if not l.strip():flush();continue
  m=re.match(r'\\(begin|end)\{([^}]+)\}',l.strip()); inp=re.fullmatch(r'\\input\{([^}]+)\}',l.strip())
  if (m and m[2] in envs) or inp or re.match(r'\\(?:subsection|section)\{',l.strip()):flush()
  if inp:
   if p=='main.tex':
    if inp[1]=='preamble.tex':sections(inp[1])
    elif inp[1]=='abstract.tex':sections(inp[1])
    elif inp[1].startswith(('sections/','appendices/')) or inp[1]=='bibliography.tex':sections(inp[1])
   else:sections(inp[1])
   continue
  if m and m[1]=='begin' and m[2] in envs:env=m[2]
  buf.append((i,l))
  if m and m[1]=='end' and m[2] in envs:flush();env='exposition'
 flush()
sections('main.tex')
def js(n,items):
 (b/n).write_text(''.join(json.dumps(i,ensure_ascii=False,separators=(',',':'))+'\n' for i in items))
js('front-to-back-blocks.jsonl',blocks);js('front-to-back-clauses.jsonl',clauses);js('in-text-citations.jsonl',refs);js('labels.jsonl',labels)
filesums=''.join(f'{hashlib.sha256((b/"tex"/f).read_bytes()).hexdigest()}  tex/{f}\n' for f in files)
(b/'tex.sha256').write_text(filesums)
for k in ['theorem','lemma','proposition','corollary','definition']:
 counts=sum(1 for p in files for l in (b/'tex'/p).read_text().splitlines() if re.match(r'\\begin\{'+k+r'\}',l))
 print(k,counts)
miss=[a for a in clauses if not a['reconstruction'] and not re.fullmatch(r'\\(?:begin|end)\{[^}]+\}',a['tex'])]
print('Uncovered lexical segments',[(x['file'],x['start'],x['tex'][:30]) for x in miss])
print('counts',len(cards),len(files),len(blocks),len(clauses),len(refs),len(set(a['item'] for a in refs)),len(labels))
