import sys
from pathlib import Path
d=Path(__file__).parent
files=(d/'order.txt').read_text().splitlines()
for i in sys.argv[1:]:
 f=files[int(i)]
 print('=== '+str(i)+' '+f)
 lines=(d/'tex'/f).read_text().splitlines()
 p=[]; lo=1
 for n,l in enumerate(lines+[''],1):
  if not l.strip() or l.startswith('\\begin{proof}') or l.startswith('\\end{proof}') or l.startswith('\\begin{theorem}') or l.startswith('\\begin{lemma}') or l.startswith('\\begin{definition}') or l.startswith('\\begin{corollary}') or l.startswith('\\begin{proposition}'):
   if p: print(str(lo)+'-'+str(n-1)+' '+' '.join(p)); p=[]
   if not l.strip():continue
  if not p:lo=n
  p.append(l.strip())
