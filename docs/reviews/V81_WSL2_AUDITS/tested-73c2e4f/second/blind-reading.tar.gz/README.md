# Source-only reading of v81

The four files in `seal.sha256` were recorded before viewing any Lean declaration, correspondence, manuscript return, or prior review. `reconstruction.md` gives the independent mathematical reading. `printed-assertions.tsv` preserves the expanded printed order, line locations and text of every fragment. The 3,624 fragments include paragraphs, displayed inferences, hypotheses, typesetting and bibliography. `tex-order.tsv` gives the names, line counts and byte digests of the 25 active inputs. The original seal records the scratch path present at the time.

From this directory, regenerate the TSV and check the four sealed digests with

```sh
python3 check-blind.py /path/to/repository
```

The verifier reads the 25 Git blobs at both the reading commit and the proof commit. It recreates the TeX input tree in a temporary directory, runs the sealed expansion script, checks coverage of every nonempty line, and compares the result with the sealed source inventory.
