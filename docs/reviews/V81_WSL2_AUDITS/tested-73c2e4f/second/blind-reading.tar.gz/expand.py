"""Record the complete printed TeX stream before reading any Lean material."""
import csv
import hashlib
import re
from pathlib import Path

work = Path(__file__).resolve().parent
sources = work / "blind-tex"
inputs = re.compile(r'^\s*\\input\{([^}]+)\}\s*$')
environment = re.compile(r'\\(begin|end)\{(definition|theorem|lemma|proposition|corollary|proof)\}')
sentence = re.compile(r'(?<=[.!?])\s+(?=[A-Z$\\])|\s+(?=\\(?:begin|end)\{(?:theorem|proposition|lemma|corollary|definition|proof)\})')
rows = []
context = []

def flush(name, lines):
    if not lines:
        return
    spans = []
    chars = []
    for line_no,line in lines:
        for c in line.strip()+' ':
            chars.append(c)
            spans.append(line_no)
    content = ''.join(chars).rstrip()
    boundaries = [0]
    for match in sentence.finditer(content):
        boundaries.append(match.end())
    boundaries.append(len(content))
    for l,r in zip(boundaries,boundaries[1:]):
        value = content[l:r].strip()
        if not value:
            continue
        matches = list(environment.finditer(value))
        opening = next((m.group(2) for m in matches if m.group(1)=='begin'), None)
        if opening:
            context.append(opening)
        kind = context[-1] if context else 'exposition'
        if name in ('main.tex','preamble.tex'):
            kind = 'typesetting'
        elif name=='bibliography.tex':
            kind = 'bibliography'
        elif value.startswith(('\\section','\\subsection','\\paragraph')):
            kind = 'heading'
        elif value.startswith('\\input'):
            kind = 'input'
        elif value.startswith('\\end{'):
            kind = 'environment end'
        elif value.startswith(('Assume ','Suppose ','Let ','Fix ')) and kind=='exposition':
            kind='hypothesis or chosen data'
        elif '\\cite' in value and kind=='exposition':
            kind='attribution or cited assertion'
        rows.append((len(rows)+1,name,spans[l],spans[r-1],kind,value))
        for match in matches:
            if match.group(1)=='end' and context and context[-1]==match.group(2):
                context.pop()

def expand(name):
    lines=(sources/name).read_text().splitlines()
    block=[]
    for pos,line in enumerate(lines,1):
        m=inputs.match(line)
        if m or not line.strip():
            flush(name,block);block=[]
            if m:
                flush(name,[(pos,line)])
                expand(m.group(1))
        else:
            block.append((pos,line))
    flush(name,block)

expand('main.tex')
with (work/'printed-assertions.tsv').open('w',newline='') as f:
    w=csv.writer(f,delimiter='\t',quoting=csv.QUOTE_MINIMAL)
    w.writerow(['reading order','TeX input','first line','last line','role in source','printed passage or inference'])
    w.writerows(rows)
seen={r[1] for r in rows}
coverage={n:set() for n in seen}
for _,n,a,b,_,_ in rows:
    coverage[n].update(range(a,b+1))
for n in seen:
    needed={i for i,s in enumerate((sources/n).read_text().splitlines(),1) if s.strip()}
    assert needed<=coverage[n], (n,sorted(needed-coverage[n]))
assert len(seen)==25
print(len(rows), 'units from', len(seen), 'files; every nonempty line covered')
