"""Verify the original reading-order seal and reproduce its TeX expansion from Git."""

import argparse
import hashlib
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


BLIND_SOURCE = "ae816e93c11712a2b1fe16f99c763a8c934f80dc"
TESTED_SOURCE = "73c2e4fa2bc633a3af012b1c4f85a7882018f962"
HERE = Path(__file__).resolve().parent


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("checkout", type=Path)
    args = parser.parse_args()
    seals = {}
    for line in (HERE / "seal.sha256").read_text().splitlines():
        expected, original_path = line.split()
        filename = Path(original_path).name
        actual = digest((HERE / filename).read_bytes())
        if expected != actual:
            raise ValueError("Sealed file differs: " + filename)
        seals[filename] = expected

    with tempfile.TemporaryDirectory(prefix="cei-v81-tex-") as temporary:
        root = Path(temporary)
        shutil.copy(HERE / "expand.py", root)
        orders = (HERE / "tex-order.tsv").read_text().splitlines()
        for row in orders:
            name, lines, expected = row.split("\t")
            target = root / "blind-tex" / name
            target.parent.mkdir(parents=True, exist_ok=True)
            for rev in (BLIND_SOURCE, TESTED_SOURCE):
                obj = rev + ":manuscript/latex/" + name
                blob = subprocess.check_output(["git", "-C", str(args.checkout), "show", obj])
                if digest(blob) != expected or len(blob.splitlines()) != int(lines):
                    raise ValueError("TeX input differs: " + obj)
            target.write_bytes(blob)
        subprocess.run([sys.executable, str(root / "expand.py")], check=True)
        if digest((root / "printed-assertions.tsv").read_bytes()) != seals["printed-assertions.tsv"]:
            raise ValueError("Reading-order expansion differs")
    print(f"Verified {len(seals)} original seals and {len(orders)} identical manuscript inputs.")


if __name__ == "__main__":
    main()
