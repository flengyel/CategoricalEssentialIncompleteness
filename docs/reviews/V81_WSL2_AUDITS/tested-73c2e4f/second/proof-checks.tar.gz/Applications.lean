import CategoricalEssentialIncompleteness.V46NumericalSyntaxMembership
import CategoricalEssentialIncompleteness.V46MachineOracleTuring
import CategoricalEssentialIncompleteness.V46TrivialDominicalCategory
import CategoricalEssentialIncompleteness.V46EffectiveExtensibility
import CategoricalEssentialIncompleteness.V46MillerFixedPoint

set_option autoImplicit false
noncomputable section

open CategoryTheory CategoryTheory.PCategoryStruct CategoryTheory.CoprodStruct
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open CategoricalEssentialIncompleteness
open CategoricalEssentialIncompleteness.LocalConnectedness
open CategoricalEssentialIncompleteness.V46

namespace V81SecondReading

private abbrev sourcePolynomial (d : ℕ) (s : ℕ → EnumerableCarriers.Total) :=
  SyntaxPolynomial.termExpression (NumericalCoordinates.codedPredicate NumericalNamed.variableObject)
    (fun k => NumericalCoordinates.codedPredicate (NumericalTuples.unary (s k))) d

private abbrev targetPolynomial (d : ℕ) (r : ℕ → EnumerableCarriers.Total) :=
  SyntaxPolynomial.formulaExpression (NumericalCoordinates.codedPredicate NumericalNamed.variableObject)
    (fun k => NumericalCoordinates.codedPredicate (NumericalTuples.unary (r k))) d

private abbrev words (b : Bool) (d : ℕ) (s r : ℕ → EnumerableCarriers.Total) :=
  SyntacticSyntax.Postfix.plainCarrier b (sourcePolynomial d s) (targetPolynomial d r)

/-- A single computable program reports both carrier-membership bits for every input
word in the actual unary coordinate objects. Its assumptions end at the arity bound. -/
theorem simultaneous_support_decision (d : ℕ) (s r : ℕ → EnumerableCarriers.Total)
    (hs : ∀ k ≤ d, ComputablePred (· ∈ (s k).obj.support))
    (hr : ∀ k ≤ d, ComputablePred (· ∈ (r k).obj.support)) :
    ∃ read : ℕ → Bool × Bool, Computable read ∧ ∀ w : ℕ,
      ((read w).1 = true ↔ w ∈ (NumericalCoordinates.predicateObject (words false d s r)).support) ∧
      ((read w).2 = true ↔ w ∈ (NumericalCoordinates.predicateObject (words true d s r)).support) := by
  obtain ⟨t, ht, tSpec⟩ := ComputablePred.computable_iff.mp
    (NumericalSyntaxMembership.numerical_word_membership s r d hs hr false)
  obtain ⟨f, hf, fSpec⟩ := ComputablePred.computable_iff.mp
    (NumericalSyntaxMembership.numerical_word_membership s r d hs hr true)
  refine ⟨fun w => (t w, f w), ht.pair hf, ?_⟩
  intro w
  exact ⟨(iff_of_eq (congrFun tSpec w)).symm, (iff_of_eq (congrFun fSpec w)).symm⟩

open OracleComputation OracleComputation.Restricted

/-- The same first-order compiler serves every oracle and every source map has a
single domain index independent of the parameter. -/
theorem uniform_machine_domains :
    ∃ specialize : ℕ → ℕ → ℕ, Computable₂ specialize ∧
      (∀ (B : Set ℕ) (c z x : ℕ), machineDomain B (specialize c z) x ↔
          machineDomain B c (Nat.pair z x)) ∧
      ∀ (Y : Restricted K) (v : product Y (N K) ⟶ N K),
        ∃ (d : ℕ) (values : carrier K Y → ℕ), Computable values ∧
          (∀ z x, machineDomain K d (Nat.pair (Encodable.encode z) x) ↔ (v.val (z,x)).Dom) ∧
          ∀ z x y, y ∈ v.val (z,x) ↔
            y ∈ (machineTau K).val (Nat.pair (values z) (specialize d (Encodable.encode z)),x) := by
  refine ⟨sectionIndex, sectionIndex_computable, machine_section, ?_⟩
  intro Y v
  obtain ⟨values, d, hv, hd, h⟩ := parameter_indices K Y v
  exact ⟨d, values, hv, hd, fun z x y => (h z x y).symm⟩

/-- The two branch targets are unconstrained within their summands, and the pointwise
compiler is witnessed simultaneously with categorical nonlifting. -/
theorem actual_diagonal_failure :
    RecursionCategory.IsTuringMorphism (machineTau K) ∧
    Complementary separator separatorComplement ∧
    machinePair0 K ≤ separator ∧ machinePair1 K ≤ separatorComplement ∧
    ∀ (s : PartialFun.of ℕ ⟶ coprod (PartialFun.of ℕ) (PartialFun.of ℕ)),
      Idem.pull s (summand0 (PartialFun.of ℕ) (PartialFun.of ℕ)) =
          (rangeFunctor K).mapIdem separatorComplement →
      Idem.pull s (summand1 (PartialFun.of ℕ) (PartialFun.of ℕ)) =
          (rangeFunctor K).mapIdem separator →
      ∀ l : N K ⟶ coprod (N K) (N K),
        (inclusion K).map l ≠ s ≫ ((rangeFunctor K).comparison (N K) (N K)).hom := by
  refine ⟨machineTau_isTuring K, separator_complementary,
    machine_separator_bounds.1, machine_separator_bounds.2, ?_⟩
  intro s h₀ h₁ l hl
  exact machine_no_lift s h₀ h₁ ⟨l, hl⟩

open TrivialDominicalCategory

/-- The unqualified attribution in Section 1 has a counterexample with the given
fixed-source Turing type and explicit complementary, disjoint diagonal bounds. -/
theorem nonzero_is_necessary :
    ∃ u : nearProd One.obj One.obj ⟶ coprod One.obj One.obj,
      DiPaolaHeller.IsTuringMorphism u ∧ (𝟙 One.obj = (0 : One.obj ⟶ One.obj)) ∧
      let left := Idem.pull (diag One.obj ≫ u) (summand0 One.obj One.obj)
      let right := Idem.pull (diag One.obj ≫ u) (summand1 One.obj One.obj)
      left ⊓ right = ⊥ ∧ ∃ c c' : Idem One.obj, Complementary c c' ∧ left ≤ c ∧ right ≤ c' :=
  ⟨evaluator, evaluator_turing, identity_eq_zero, diagonal_pair_has_separator⟩

/-- A witness of the Miller premise supplies the right value simultaneously to two
names and two precisions at any fixed program index. -/
theorem miller_sequence_exists :
    ∃ a : ℕ → Set.Icc (0 : ℝ) 1, ∀ r : Set.Icc (0 : ℝ) 1, ∀ d : ℕ,
      (∀ p : ℕ → Fin 2, Miller.rho p = a → ∀ k, ∃ j : ℕ,
        j ∈ Miller.OracleProgram.numberedEval d p k ∧
          |(Miller.Rationals.q j : ℝ) - (r : ℝ)| < ((2 : ℝ)^k)⁻¹) → a d = r := by
  obtain ⟨a, ha⟩ := Miller.exists_isMiller
  exact ⟨a, fun r d h => ha d r h⟩

#print axioms simultaneous_support_decision
#print axioms uniform_machine_domains
#print axioms actual_diagonal_failure
#print axioms nonzero_is_necessary
#print axioms miller_sequence_exists
#print axioms EffectiveExtensibility.exists_complete_presentation_without_extender
#print axioms branches_have_no_common_upper_bound

end V81SecondReading
