"""Check the second reader's declaration receipts and optionally run both Lean inputs."""

import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile

HERE = Path(__file__).resolve().parent
SOURCE = "73c2e4fa2bc633a3af012b1c4f85a7882018f962"
PERMITTED_AXIOMS = {"propext", "Classical.choice", "Quot.sound"}
APPLICATIONS = {
    "V81SecondReading.simultaneous_support_decision",
    "V81SecondReading.uniform_machine_domains",
    "V81SecondReading.actual_diagonal_failure",
    "V81SecondReading.nonzero_is_necessary",
    "V81SecondReading.miller_sequence_exists",
    "CategoricalEssentialIncompleteness.V46.EffectiveExtensibility.exists_complete_presentation_without_extender",
    "CategoricalEssentialIncompleteness.LocalConnectedness.OracleComputation.Restricted.branches_have_no_common_upper_bound",
}
LEAN_OPTIONS = ["-j1", "-DwarningAsError=true", "-DautoImplicit=false"]


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def read_file(name):
    plain = HERE / name
    if plain.exists():
        return plain.read_bytes()
    return gzip.decompress((HERE / (name + ".gz")).read_bytes())


def transitive_axioms(blob, expected):
    text = blob.decode()
    axioms = {}
    for name, items in re.findall(r"^'([^']+)' depends on axioms: \[([^\]]*)\]", text, re.MULTILINE):
        require(name not in axioms, "Repeated axiom output for " + name)
        axioms[name] = [x.strip() for x in items.split(",") if x.strip()]
    for name in re.findall(r"^'([^']+)' does not depend on any axioms", text, re.MULTILINE):
        require(name not in axioms, "Repeated axiom output for " + name)
        axioms[name] = []
    require(set(axioms) == expected, "Axiom output name coverage differs")
    require(all(set(entry) <= PERMITTED_AXIOMS for entry in axioms.values()), "Unexpected axiom")
    return axioms


def check_sources(repo, records):
    def git(*args):
        return subprocess.check_output(["git", "-C", str(repo), *args])

    require(git("rev-parse", "HEAD").decode().strip() == SOURCE, "Wrong revision")
    require(records["source_commit"] == SOURCE, "Wrong numbered source revision")
    measured = ["Lean", "manuscript/latex", "scripts", "MANUSCRIPT_CURRENT.json", "FORMALIZATION_STATUS_V81.md"]
    changed = git("diff", "--name-only", SOURCE, "--", *measured)
    require(not changed, "Modified verification inputs: " + changed.decode())
    paths = {v["source"]: v["source_sha256"] for v in records["declarations"].values()}
    paths.update({path: value["sha256"] for path, value in records["registered_input_files"].items()})
    paths["FORMALIZATION_STATUS_V81.md"] = records["correspondence_sha256"]
    for path, expected in sorted(paths.items()):
        require(sha256(git("show", SOURCE + ":" + path)) == expected, "Wrong source digest: " + path)


def check_output(name, output, expected, repo, env, replay):
    source = read_file(name + ".lean")
    captured = read_file(output)
    axioms = transitive_axioms(captured, expected)
    if replay:
        with tempfile.TemporaryDirectory(prefix="cei-v81-second-") as temporary:
            source_path = Path(temporary) / (name + ".lean")
            source_path.write_bytes(source)
            command = ["lake", "env", "lean", *LEAN_OPTIONS, str(source_path)]
            result = subprocess.run(
                command, cwd=repo / "Lean", env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT
            )
            require(result.returncode == 0, result.stdout.decode()[-2400:])
            require(transitive_axioms(result.stdout, expected) == axioms, "Fresh axiom output differs")

    return {
        "source_sha256": sha256(source),
        "output_sha256": sha256(captured),
        "distinct_axiom_outputs": len(axioms),
        "allowed_axioms_used": sorted(set().union(*(set(entry) for entry in axioms.values()))),
        "tested_flags": LEAN_OPTIONS,
        "exit_code": 0,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("checkout", type=Path)
    parser.add_argument("--run", action="store_true", help="Invoke Lean in the checkout's prepared build.")
    parser.add_argument("--summary", type=Path)
    arguments = parser.parse_args()
    repo = arguments.checkout.resolve()
    records = json.loads(read_file("numbered.json"))
    check_sources(repo, records)
    environment = dict(os.environ, LEAN_NUM_THREADS="1")
    version = subprocess.check_output(
        ["lake", "env", "lean", "--version"], cwd=repo / "Lean", env=environment, text=True
    ).strip()
    require("4.35.0-rc2" in version, "Wrong Lean toolchain")
    probes = {}
    for name, output, expected in [
        ("Numbered", "numbered.log", set(records["declarations"])),
        ("Applications", "probe.log", APPLICATIONS),
    ]:
        probes[name] = check_output(name, output, expected, repo, environment, arguments.run)
    summary = {
        "source_commit": SOURCE,
        "lean": version,
        "numbered_rows": len(records["rows"]),
        "numbered_defining_modules": len({v["module"] for v in records["declarations"].values()}),
        "printed_TeX_files": len(records["registered_input_files"]),
        "probes": probes,
    }
    serialized = json.dumps(summary, indent=2) + "\n"
    if arguments.summary:
        arguments.summary.write_text(serialized)
    print(serialized, end="")


if __name__ == "__main__":
    main()
