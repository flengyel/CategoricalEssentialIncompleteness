"""Validate the official full v81 wrapper receipt and its source bytes once published."""

import argparse
import gzip
import hashlib
import json
from pathlib import Path
import subprocess


REVISION = "73c2e4fa2bc633a3af012b1c4f85a7882018f962"
ALLOWED = {"Classical.choice", "Quot.sound", "propext"}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(blob):
    return hashlib.sha256(blob).hexdigest()


def verify_committed_paths(checkout, paths):
    git = subprocess.Popen(
        ["git", "-C", str(checkout), "cat-file", "--batch"],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
    )
    try:
        for name, expected in sorted(paths.items()):
            require("\n" not in name, "Invalid source path")
            git.stdin.write(f"{REVISION}:{name}\n".encode())
            git.stdin.flush()
            header = git.stdout.readline().split()
            require(len(header) == 3 and header[1] == b"blob", "Missing blob " + name)
            blob = git.stdout.read(int(header[2]))
            require(git.stdout.read(1) == b"\n", "Malformed Git batch result")
            require(digest(blob) == expected, "Committed source digest differs for " + name)
    finally:
        git.stdin.close()
        git.stdout.close()
        git.wait()
    require(git.returncode == 0, "Git source audit failed")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("checkout", type=Path)
    parser.add_argument("receipt", type=Path)
    args = parser.parse_args()
    data = args.receipt.read_bytes()
    receipt = json.loads(gzip.decompress(data) if data[:2] == b"\x1f\x8b" else data)
    require(receipt["source_commit"] == REVISION, "Wrong tested revision")
    wrapper = receipt["wrapper"]
    require(wrapper.get("source", REVISION) == REVISION, "Wrong wrapper revision")
    require(wrapper["argv"][-1] == "scripts/verify-wsl.sh" and wrapper["exit_code"] == 0, "Incomplete full wrapper")
    verification = receipt["verification"]
    require(verification["scope"] == "full" and verification["success"], "Full verifier incomplete")
    require(not verification["source_mismatches"], "Full verifier input mismatches")
    commands = verification["commands"]
    require(commands and all(c["exit_code"] == 0 for c in commands), "Verifier command failed")
    logs = {c["log"] for c in commands}
    required_logs = {"axiom-audit.log", "current-axiom-audit.log"}
    require(required_logs <= {Path(log).name for log in logs}, "Missing current or retained axiom audit")
    if "command_log_sha256" in receipt:
        require(set(receipt["command_log_sha256"]) == logs, "Incomplete command log coverage")
    require(set(verification["allowed_axioms"]) == ALLOWED, "Axiom policy differs")
    for group in ("axioms", "current_axioms"):
        entries = verification[group]
        require(entries and all(set(items) <= ALLOWED for items in entries.values()), "Unexpected axiom in " + group)
    dependencies = verification["dependency_worktrees"]
    require(dependencies["start"] == dependencies["end"] and dependencies["start"], "Dependencies changed")
    require(all(d["worktree_clean"] and d["actual"] == d["expected"] for d in dependencies["start"]), "Dependency pin differs")
    manuscript = verification["current_manuscript"]
    require(manuscript["version"] == 81 and manuscript["source_archive_matches"] and manuscript["pdf_copy_matches"], "Manuscript bundle differs")
    paths = verification["integration_sha256"]
    require(paths and all(paths.get(k) == v for k, v in manuscript["sha256"].items()), "Manuscript snapshot differs")
    require(digest(json.dumps(paths, sort_keys=True).encode()) == verification["source_snapshot_sha256"], "Source digest differs")
    if "official_json_sha256" in receipt:
        require(digest((json.dumps(verification, indent=2) + "\n").encode()) == receipt["official_json_sha256"], "Official JSON digest differs")
    verify_committed_paths(args.checkout, paths)
    print(json.dumps({
        "source_commit": REVISION,
        "wrapper_exit": wrapper["exit_code"],
        "receipt_sha256": digest(data),
        "verified_commands": len(commands),
        "verified_input_blobs": len(paths),
        "verified_dependencies": len(dependencies["start"]),
        "current_axiom_entries": len(verification["current_axioms"]),
        "retained_axiom_entries": len(verification["axioms"]),
    }, indent=2))


if __name__ == "__main__":
    main()
