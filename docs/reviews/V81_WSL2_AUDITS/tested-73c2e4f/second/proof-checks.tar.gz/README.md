# Independent proof evidence for v81 at 73c2e4f

Extract this archive in an empty directory. The verified Lean environment uses the pinned project toolchain and built dependencies. From the extraction directory, pass the repository checkout as an argument.

```sh
python3 check-probes.py /path/to/tested-checkout --run
```

The script checks the Git revision, the source SHA-256 values for the definitions and TeX inputs, both sets of query names, and every individual axiom list. With `--run` it also runs both Lean inputs in the supplied checkout and compares every newly reported axiom list with the captured output. Omit that flag to verify the distributed outputs using the source and toolchain. The exit codes in `kernel.json` belong to the independent runs made for this audit. The official wrapper receipt is published separately. With that file, run

```sh
python3 confirm-full.py /path/to/tested-checkout /path/to/V81_WSL2_LEAN_VERIFICATION_73c2e4f.json.gz
```

| File | Contents |
|---|---|
| `numbered.json.gz` | All 80 numbered statements, source locations, TeX text, occurrences of declaration names, qualified names, and their defining source hashes. The 77 numbered results comprise 18 theorems, 19 lemmas, 27 propositions and 13 corollaries. The other three numbered statements are definitions. |
| `Numbered.lean` and `numbered.log` | Strict type and permitted-axiom queries for the 852 distinct declarations. The output preserves multiline types and lists. |
| `Applications.lean` and `probe.log` | Five independent typed applications and the transitive axiom queries for them, the complete-presentation counterexample and the absence of a common upper bound in Appendix C. |
| `kernel.json` | Tested commit, Lean version, flags, counts, exit codes, and SHA-256 values for the Lean inputs and outputs. |
| `passage-map.json.gz` | A sequential map from each of the 3,624 sealed TeX fragments to its printed line range, source hash, closest proof or correspondence row, and findings. Typed observations specific to the tested source appear in the overrides. The current line numbers for older locator records are matched by exact source text. A locator identifies a proof to examine. The text in the independent reading gives the reconstructed types. |
| `construction-search.json.gz` | Candidate-construction vocabulary search of the project and pinned dependencies for the six historical theorem types. The report identifies the missing mathematical inferences and their downstream use. |
