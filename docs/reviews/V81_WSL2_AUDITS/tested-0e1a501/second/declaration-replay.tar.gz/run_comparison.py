from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

here = Path(__file__).resolve().parent
pin = here.parent / "cei-v81-final"
lean = pin / "Lean"
packages = sorted((lean/".lake/packages").glob("*/.lake/build/lib/lean"))
env = dict(os.environ,LEAN_PATH=os.pathsep.join(map(str,[lean/".lake/build/lib/lean",*packages])))
toolchain = (lean/"lean-toolchain").read_text().strip()
cmd = ["elan","run",toolchain,"lean","-j1","-M5200",str(here/"PinComparisons.lean")]
start = time.monotonic()
p = subprocess.run(cmd,cwd=here,env=env,capture_output=True,text=True,timeout=220)
logs = p.stdout+p.stderr
(here/"pin-comparison.log").write_text(logs)
record = {"source":subprocess.check_output(["git","-C",str(pin),"rev-parse","HEAD"],text=True).strip(),
          "test":"PinComparisons.lean","sha256": hashlib.sha256((here/"PinComparisons.lean").read_bytes()).hexdigest(),
          "toolchain":toolchain,"arguments":["-j1","-M5200"],"exitCode":p.returncode,
          "elapsedSeconds":round(time.monotonic()-start,2),"logSHA256":hashlib.sha256(logs.encode()).hexdigest()}
(here/"pin-comparison-receipt.json").write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps(record))
print(logs)
raise SystemExit(p.returncode)
