"""Apply a source-specific disposition to each actual TeX cite occurrence."""
from pathlib import Path
from collections import Counter
import json
import re

here=Path(__file__).resolve().parent
paper=here/"paper/manuscript/latex"
order=[(item.split("  ",1)[1]).strip() for item in (here/"manuscript-inputs.sha256").read_text().splitlines()]
defaults={
"Aczel":("application","The finite-proof interpretation of finitary closure is realized by RulePresentation.least_theorem_subobject and SyntacticGeneratedTheory.generated_theory. Appendix A.4 uses their categorical instance."),
"BauerHanson":("application","For the sequence at the actual binary representation map, use V46.Miller.exists_isMiller, Unanimity.unanimityIndex_eq_tau and Cut.printed_cut_contrast. The oracle index is shared by all names."),
"Bernardi":("application","V46.Precomplete.inseparable_unions and inseparable_classes prove the numerical implications. V46.ProvableProgramEquality.precomplete constructs a totalizer for the actual PA-provable EqIndex relation."),
"CGHRangeI":("definition/application","The restricted map data and range equations are implemented by RangeFunctor, V46.PartialMaps and V46.PartialMaps.totalEquivalence. V46.range_regularImage and V46.PartialMaps.range_totalValue give the use in Appendix A.5."),
"CGHRangeII":("method comparison","Appendix A.5 directly proves its regular-image case under the partial-inverse hypothesis using LocalConnectedness.V46.range_regularImage. The cited paper describes the surrounding theory of split ranges and regular images."),
"CockettComputability":("application","V46.DiscreteTuringInseparability.inseparable_idempotents obtains the pair from a discrete Turing object and compatible joins. V46.ProgramOrder.exists_nontrivial_terminal_predicate and terminal_predicate_of_coded_order give the nonzero proper terminal domain under the program-order predicate."),
"CockettHofstra":("application","V46.turingObject_iff constructs the typed evaluator from the universal evaluator and retracts, and conversely. V46.SplitTuring.evaluator_isTuring specializes on a split parameter, as used in Lemma 5.1."),
"CockettLack":("definition/application","The repository's CategoryTheory.RestrictionCategory gives the four restriction identities. V46.KaroubiRestriction and V46.PartialMaps implement split restrictions and monic spans; V46.PartialMaps.totalEquivalence and the strict inverse in V46PartialMapTotals.lean realize the asserted total category."),
"CockettLackIII":("application","V46RestrictionProductData.lean, V46RestrictionProductCategory.lean and V46RestrictionProductComparison.lean construct both directions of the characterization, identify the induced original restriction, and identify product choices by their unique comparison."),
"CockettLists":("definition","The listed parameterized recursion property is imposed on StableListAlgebra, then constructed as withParametersInitial for the concrete syntax and list categories."),
"Composition":("application","FailureOfComposition.Palomar.no_quotient_composition_productive, via the retained Palomar solution, rules out representative-independent primed composition for each consistent c.e. extension. Section 6 uses the unprimed quotient."),
"Corrections":("history","The introduction describes the subject of the earlier existence papers. No existence theorem about arbitrary faithful iteration functors is an input to Section 3."),
"CurryCosheaves":("definition/application","ForkTopology.ActualCosheaf uses the full compatible-family gluing law. ForkTopology.actualCosheafEquivalence proves the reduction to the pushout in this three-point space."),
"DPH":("context","The first and modal paragraphs report research questions and the topics of the discussion. No modal fixed-point theorem or GL calculus is used in this derivation."),
"DPM":("definition/application","The effective set realization and uniform graph equality are implemented by V46RealizedObjectSetsCategory.lean and V46StrictPresentationFunctors.lean. The primed composition obstruction uses FailureOfComposition.Palomar.no_quotient_composition_productive. V46.ConnectedNumeralDomains.unprimed_not_locallyConnected gives Appendix D at all consistent c.e. T."),
"FPT":("method comparison","The paper contrasts earlier accounts of binding and alpha-conversion with its explicit names. CategoricalSyntax.substitutionAlgebra and its fold construct the operations for the syntax actually used."),
"GTWW":("method comparison","The cited use of many-sorted initial algebras describes prior syntax methodology. V46.CategoricalSyntax and the concrete SyntacticSyntax.withParametersInitial provide the chosen algebra."),
"GabbayPitts":("method comparison","Prior binding syntax and retention of the original expression are methodological references. The paper's own product-with-the-input construction is V46.CategoricalSyntax.substitutionAlgebra and substitutionFold_original."),
"GoguenBurstall":("method comparison","This is historical attribution of initial-algebra syntax for a range of signatures. The current many-sorted syntax is checked directly."),
"HH":("definition/application","The named-variable and equality schemes are components of CategoricalSyntax.logicalAxioms and logicalRules; NamedPlainSemantics.valid_logicalAxioms proves their soundness on the indicated substitution domains."),
"HP":("definition/application","The three displayed propositional schemes are coproduct branches of CategoricalSyntax.logicalAxioms; the resulting least image is CategoricalSyntax.generated_firstOrder_theory."),
"Heller":("definition/history","The terminology for range, prodominical isotypes and nonempty words is historical. PCats.Recursion defines the exact recursion structure. The printed concrete fork has EffectiveFork.Recursion.recursionCategory and its word frame."),
"Katsumata":("method comparison","The reference describes a first-order example of syntax up to renaming. The present syntax explicitly retains bound-variable names."),
"Keisler":("application","V46.ArithmeticUltrapower.eval_representative proves the satisfaction equivalence by induction including the existential choice of reps, sentence_iff specializes to the constant arithmetic structure, and modelsPA applies it to each PA axiom."),
"KirstPeters":("historical theorem H7","The cited result has synthetic enumerable partial functions, a synthetic diagonal and semidecidable provability for the extending system. Current V46.ArithmeticUniformIndependent and ArithmeticSentenceInseparability supply classical PA instances. The full original synthetic quantification is external."),
"Lengyel2004":("history","The text locates the subject of the faithful-iteration existence theorems. They supply no premise of the present construction."),
"Lengyel2006":("definition/application","In Appendix C restriction and range preservation, split Pfn, local connectedness, weak choice, the literal machine evaluator and separated diagonal are checked. V46MachineOracleTuring.lean, OracleMissingLift.lean and PartialFunctions.lean give a concrete counterexample to §4.1."),
"MPV":("application","Janiczak.FOL.signed_janiczak and signed_essentiallyUndecidable_iff use actual native FOL sentence/proof words; signed_recursively_axiomatizable gives a primitive-recursive equivalent axiomatization. The canonical spectrum proves existence of a class of size n+1 precisely for each prescribed n."),
"MaiettiLists":("definition","StableListAlgebra expresses the displayed requirement after pullback to each slice. SyntacticLists.withParametersInitial and its concrete analogues supply witnesses in the examples."),
"Miller2004":("application","V46.Miller.exists_isMiller gives an unconditional sequence at the fixed oracle numbering and approximation accuracy. Cut.printed_cut_contrast and fixed_representation_separator prove the two quantifier orders on cut separators."),
"Montagna":("definition/history/application","The fixed programming language and formula conventions, variation by presentation, and the connect-the-categories question are separately identified. V46RealizedObjectSetsCategory.lean, UniformTrace.arithmetized_evaluation and the standard proof-word isomorphism supply the uses at the chosen coding."),
"PourEl":("definition with ambiguity","Effective extensibility is a property of a presentation. V46.ArithmeticUniformIndependent.uniform_independent_sentences constructs one morphism for the specified PA presentation and all standard consistent fibers. The ambiguity at §8.3 lines 4–8 is recorded in the report."),
"RobinsonRosolini":("definition/application","V46.SyntacticSearch.functional_search and SyntacticPredicates.predicateEquivalence realize the functional Sigma-one presentation modulo universal T-provable graph equality."),
"Rosolini":("history","Introduction §1.4 situates dominical, P- and restriction categories. The actual P-category/restriction product equivalence is separately proved."),
"RosoliniThesis":("history","Introduction §1.4 situates the development of P-categories. No individual thesis construction enters the paper's proofs."),
"VisserEHU":("application checked separately","PinComparisons.lean, undecidable_extensions_of_reduction, checks the unrestricted computable reduction for all encoded first-order sentence types and every consistent extension. It uses the Mathlib many-one pullback, Foundation's theory weakening, negation modus ponens, and the project's Numerical.RecursivelyInseparable definition."),
"Voutsadakis":("historical theorem H8","The cited F : HSet ⇄ Sign : U by substitution of formulas for relational symbols is external. The local SignedFirstOrder.adjunction has signed pairs on one side and closed internal first-order theories on the other."),
"Wissmann":("application","RulePresentation.inference_preservesRegularEpis and RulePresentation.least_theorem_subobject explicitly construct the image subalgebra and its unique factor where the paper invokes the lifting result."),
"vanDijkGO":("historical theorem H5","The printed reference concerns an internal arithmetic-universe object in the initial AU. Its completeness/triviality and consistency subobject theorems have no corresponding AU construction in this source. The paper's associated partial-map slice is a separate checked type."),
}
overrides={
("01-introduction.tex",127,"BauerHanson"):("historical theorem H1","Thm 6.4 yields an epi N→R_Ded inside the parameterized realizability topos T_μ. V46.Miller.exists_isMiller concerns a point of the external Hilbert cube, and the project constructs E_a and its total subcategory. The realizability topos, its internal Dedekind-real object, and that epi are external."),
("01-introduction.tex",175,"DPH"):("historical theorem H2","Di Paola–Heller 8.15 assumes a c⁺-dominical category and τ:X×X⇀X+X. It proves its two diagonal summand domains inseparable. V46Comparison proves the lifted conditional version at its own evaluator type; the c⁺-dominical section-to-conditional bridge is not supplied in the fixed-source DiPaolaHeller packaging."),
("01-introduction.tex",178,"Bernardi"):("historical theorem H3","Categorical Eršov fixed points and the categorical inseparability assertion for precomplete relations are external at the general dominical types. V46.Precomplete.inseparable_unions and V46.ProvableProgramEquality.precomplete establish the concrete numerical statements in §8."),
("01-introduction.tex",180,"Montagna"):("historical theorem H4","Remark 3.1 includes one total binary productive morphism for all indices of disjoint enlargements of a fixed pair in the unprimed system. Project 3.1 provides a unary avoiding witness after a specific lifted conditional; Corollary D.2 gives ordinary inseparability of the actual diagonals. Neither supplies the categorical indexed productive morphism."),
("01-introduction.tex",210,"CockettHofstra"):("historical theorem H6","The cited structure comparison uses Comp(A) for a PCA and recovers a Turing category by selected idempotent splittings. V46.turingObject_iff, V46.SplitTuring and V46.KaroubiRestriction cover the evaluator and retractions independently. They give no Comp(A) structure equivalence."),
("08-essential-incompleteness-of-arithmetic.tex",241,"DPH"):("application and incorrect page","ArithmeticSyntax.supports_recursivelyInseparable_of_definability assumes consistency and strong numeralwise definability of each recursive set. It proves recursive inseparability of the theorem and refutation supports. The primary item (3) is on printed page 595; the manuscript cites page 594."),
}
records=[]
for name in order:
    name=name.removeprefix("manuscript/latex/")
    content=(paper/name).read_text()
    for match in re.finditer(r"\\cite(?:\[([^\]]*)\])?\{([^}]+)\}",content):
        line=content.count("\n",0,match.start())+1
        for k in match[2].split(","):
            kind,status=overrides.get((Path(name).name,line,k),defaults[k])
            records.append({"file":name,"line":line,"key":k,"locator":match[1],"role":kind,"formalComparison":status})
(here/"literature-applications.json").write_text(json.dumps(records,ensure_ascii=False,indent=1)+"\n")
print(len(records),"citation-key occurrences,",len(set(r["key"] for r in records)),"keys.",Counter(r["role"].split()[0] for r in records))
