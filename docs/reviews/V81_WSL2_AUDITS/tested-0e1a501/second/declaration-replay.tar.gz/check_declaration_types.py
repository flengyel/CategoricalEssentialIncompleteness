from collections import defaultdict
from hashlib import sha256
from pathlib import Path
import gzip
import json
import os
import subprocess
import time

HERE=Path(__file__).resolve().parent
PIN=HERE.parent/"cei-v81-final"
LEAN=PIN/"Lean"
PACKAGES=sorted((LEAN/".lake/packages").glob("*/.lake/build/lib/lean"))
ENV=dict(os.environ,LEAN_PATH=os.pathsep.join(map(str,[LEAN/".lake/build/lib/lean",*PACKAGES])))
tc=(LEAN/"lean-toolchain").read_text().strip()
work=HERE/"type-checks"
work.mkdir(exist_ok=True)
groups=defaultdict(dict)
rows=json.loads((HERE/"numbered-source-comparison.json").read_text())
for row in rows:
    sec=row["result"].split()[-1].split(".")[0]
    for d in row["declarations"]:
        groups[sec][d["name"]]=d["path"].removeprefix("Lean/").removesuffix(".lean").replace("/",".")
receipts=[]
for sec,items in groups.items():
    mods=sorted(set(items.values()))
    script=work/("Section"+sec+".lean")
    script.write_text("module\n"+"\n".join("import all "+m for m in mods)+"\n"+"\n".join("#check @"+n for n in items)+"\n")
    start=time.monotonic()
    cmd=["elan","run",tc,"lean","-j1","-M5500",str(script)]
    p=subprocess.run(cmd,cwd=HERE,env=ENV,capture_output=True,text=True,timeout=130)
    out=p.stdout+p.stderr
    data={"section":sec,"moduleCount":len(mods),"queriedNames":list(items),
          "exit":p.returncode,"elapsed":round(time.monotonic()-start,2),
          "errors":[line for line in out.splitlines() if ("error" in line and (".lean:" in line or "error:" in line)) or "exception" in line],
          "logSHA256":sha256(out.encode()).hexdigest()}
    receipts.append(data)
    with (work/("Section"+sec+".log.gz")).open("wb") as handle:
        handle.write(gzip.compress(out.encode(),mtime=0))
    print(sec,len(items),p.returncode,data["errors"][:8],flush=True)
(HERE/"declaration-type-receipt.json").write_text(json.dumps({"source":"0e1a501b3207ea64a3eb23740405f04b9aaa424f",
        "toolchain":tc,"arguments":["-j1","-M5500"],"groups":receipts},indent=2)+"\n")
