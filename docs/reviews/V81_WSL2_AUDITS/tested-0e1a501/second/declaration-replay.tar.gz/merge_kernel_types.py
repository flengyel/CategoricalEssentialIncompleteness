"""Attach the unabridged kernel-printed types to the source-location register."""
from pathlib import Path
import json
import gzip
import re
from hashlib import sha256

here=Path(__file__).resolve().parent
rows=json.loads((here/"numbered-source-comparison.json").read_text())
receipt=json.loads((here/"declaration-type-receipt.json").read_text())
types={}
for g in receipt["groups"]:
    assert g["exit"]==0 and not g["errors"]
    raw=gzip.decompress((here/"type-checks"/("Section"+g["section"]+".log.gz")).read_bytes())
    assert sha256(raw).hexdigest()==g["logSHA256"]
    sections=[]
    start=re.compile(r"^@?([\w.₀-₉']+)(?:\s+:|\s+\()")
    for line in raw.decode().splitlines():
        m=start.match(line)
        if m and m[1] in g["queriedNames"]:
            sections.append((m[1],[line]))
        elif sections:sections[-1][1].append(line)
    assert [n for n,_ in sections]==g["queriedNames"],(g["section"],set(g["queriedNames"])-{n for n,_ in sections})
    types.update((n,"\n".join(ls)) for n,ls in sections)
for row in rows:
    for d in row["declarations"]:
        d.pop("sourceSignature",None)
        d["kernelType"]=types[d["name"]]
    file_tokens=[]
    for t in row["unresolvedTokens"]:
        candidates=list((here.parent/"cei-v81-final/Lean/CategoricalEssentialIncompleteness").glob(t+".lean"))
        if not candidates:candidates=list((here.parent/"cei-v81-final/Lean/CategoricalEssentialIncompleteness").glob("V46"+t+".lean"))
        assert len(candidates)==1,(t,candidates)
        file_tokens.append({"moduleToken":t,"file":"Lean/CategoricalEssentialIncompleteness/"+candidates[0].name})
    row["moduleReferences"]=file_tokens
    del row["unresolvedTokens"]
(here/"numbered-kernel-types.json.gz").write_bytes(gzip.compress((json.dumps(rows,ensure_ascii=False,indent=1)+"\n").encode(),mtime=0))
print(len(rows),"numbered results and definitions,",len(types),"distinct kernel types")
