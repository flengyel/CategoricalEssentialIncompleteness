from collections import defaultdict
from pathlib import Path
import json
import re

here=Path(__file__).resolve().parent
pin=here.parent/"cei-v81-final"
read=lambda name:json.loads((here/name).read_text())
rows={r["result"].split()[-1]:r for r in read("numbered-source-comparison.json")}
all_links=read("correspondence-source-links.json")
all_anchors=read("appendix-e-tested-links.json")
group_text=(here/"manuscript-reconstruction.md").read_text().splitlines()
# The left index refers to the sealed, manuscript-only reading. Plain integers select
# source-bearing rows of the active passage table. Decimal indices select the
# independently resolved numbered-result types in numbered-source-comparison.json.
groups="""
11 4.4 4.6 4.7 4.8
12 5.1 5.2 5.3 7.9 8.5 8.6 8.8 8.10 9.4 9.7 9.8 10.6 10.9
13 4.1 4.3 4.7 4.8 5.1 5.2 5.3 33
14 3.1 4.2 7.6 7.9 8.3 8.4 8.6 8.8 9.1 9.4 9.7 9.8 10.4 10.6 10.8 10.9 42 49 109
15 29 30 40 42 55 8.4 9.4 C.1
16 PartialFunctions RangeFunctor V46RestrictionProductData
17 31 52 V46KaroubiRestriction V46PartialMaps V46PartialMapTotals
18 V46RestrictionProductCategory V46RestrictionProductData RangeFunctor 32
19 DoublingRangeFunctor V46TuringObjectRecognition 31 7.2 D.1
23 3.1 32
24 3.1 3.2
25 3.3 3.4
26 A.5 A.6 A.7 4.1 4.3
27 4.1 4.2
28 4.1 33
29 4.2 4.3
30 4.3 101 8.4
31 4.4
32 4.5
33 4.6
34 4.7
35 4.7 33 61 A.3
36 4.8 33
37 V46MonicPartialMapEquivalence V46PartialMapEquivalence 52
38 5.1
39 5.2 34 103
40 5.3 4.4
41 103
45 6.1 35 105
46 6.1
47 6.1 35 105 NoQuotientComposition
48 6.1 6.2 7.1
49 6.2 6.3
50 6.3
51 5.1 6.3 6.4 36
52 6.5 6.6 113 115
53 6.7 117 A.3
54 6.8 6.9 83
55 6.9 A.5 A.6
56 7.1
57 7.2 7.3 7.4
58 7.5 7.6
59 7.7 7.8 7.9
63 6.9 7.6 8.1
64 8.1
65 8.2
66 8.3 8.4 3.1 4.1 4.2 7.6 7.9
67 8.5 37 6.9
68 8.5 36 109
69 8.6 38 41
70 8.7 8.8
71 8.7
72 8.8
73 8.8 109
74 8.4 8.7 8.8 109 3.3
75 8.4 39 40 107
76 8.9 119
77 8.10 5.1 5.2 5.3
81 42 9.1
82 9.1
83 9.1 9.2
84 9.3 43
85 9.4
86 9.5
87 9.5 9.6 44
88 9.6 9.7 44 45
89 9.7 9.8 44 5.3
93 B.1 B.2 46
94 B.5 B.6 B.7 B.8 47
95 10.1 B.7 47
96 10.1 10.2 10.5 48
97 10.2 10.3 48
98 10.3 10.4 48
99 10.5 10.6 49
100 10.7 54
101 10.8 10.6
102 10.9 5.1 5.2 5.3
106 50 51 A.1
107 A.1 A.2
108 A.3 61 117
109 A.4 A.5
110 A.6
111 A.7 52
112 A.5 53
113 B.1 46
114 B.2
115 B.3 B.4
116 B.5 B.6
117 B.7 47
118 B.8 B.9
119 B.10 54
120 C.1 55
121 C.1 55
122 C.1 55
123 C.1 55 D.1
124 D.1 56 57
125 D.2 111
126 D.1 D.2 39 57
127 4.7
128 4.8
129 8.9
130 3.1 C.1 55
131 5.3
132 8.6 41
133 9.6 9.7 44 45
"""
sources={p.name:p for p in (pin/"manuscript/latex").rglob("*.tex")}
def extract_key(s):
    return re.match(r"^- (\S+) (\d+)–(\d+|end)",s).groups()

results=defaultdict(list)
byline={}
for line in groups.strip().splitlines():
    i,*items=line.split(); i=int(i)
    key,lo,hi=extract_key(group_text[i-1])
    if key.endswith(".tex"): file=key
    low=int(lo); high=int(hi) if hi!="end" else len(sources[file].read_text().splitlines())
    extra=[]; links=[]; numbers=[]
    for x in items:
        if x in rows:numbers.append(x)
        elif x.isdigit(): links.append(int(x))
        else:
            paths=list((pin/"Lean").glob("*/"+x+".lean"))
            if not paths and x=="NoQuotientComposition":
                paths=[pin/"Lean/FailureOfComposition/Palomar/Solution.lean"]
            assert paths and all(p.exists() for p in paths),(x,paths)
            extra.extend(str(p.relative_to(pin)) for p in paths)
    byline[i]={"reconstructionLine":i,"file":str(sources[file].relative_to(pin/"manuscript/latex")),
               "first":low,"last":high,"numberedTypes":numbers,"correspondenceAnchorRows":links,"additionalLeanModules":extra}
    results[file].append(byline[i])
passages=[json.loads(x) for x in (here/"manuscript-passages.jsonl").read_text().splitlines()]
index=[]
for u in passages:
    f=Path(u["file"]).name
    gs=[g for g in results.get(f,[]) if g["first"]<=u["last"] and u["first"]<=g["last"]]
    sg=[g["reconstructionLine"] for g in gs]
    labels=[m for m in re.findall(r"\\(?:eqref|ref)\{([^}]+)\}",u["source"])]
    cross=[v["result"].split()[-1] for v in rows.values() if v["label"] in labels+u["labels"]]
    loc={"unit":u["unit"],"file":u["file"],"first":u["first"],"last":u["last"],"role":u["role"],
         "reconstructionLines":sg,"printedCrossReferences":cross}
    if f.startswith("e-reading-lean-proofs"):
        loc["taggedProofLinks"]=[a["tex"] for a in all_anchors if u["first"]<=a["tex"]<=u["last"]]
    if u["citations"]:loc["literatureKeys"]=u["citations"]
    if not sg and not cross:
        assert (f in ("main.tex","preamble.tex","bibliography.tex") or "\\Needspace" in u["source"] or u["source"].startswith("\\newcommand")
                or not re.search(r"[A-Za-z]{3,}",re.sub(r"\\(?:section|subsection|label|input|begin|end)\{[^{}]*\}","",u["source"]).strip())), (f,u["first"],u["source"])
    index.append(loc)
(here/"passage-groups.json").write_text(json.dumps(list(byline.values()),ensure_ascii=False,indent=1)+"\n")
(here/"passage-proof-index.jsonl").write_text("".join(json.dumps(u,ensure_ascii=False)+"\n" for u in index))
print(len(index),"units",len(byline),"mathematical groups")
