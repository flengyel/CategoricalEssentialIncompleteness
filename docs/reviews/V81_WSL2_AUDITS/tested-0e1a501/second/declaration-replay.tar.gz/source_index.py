"""Locate correspondence declarations in actual Lean source and validate printed hyperlinks."""
from collections import defaultdict
from hashlib import sha256
from pathlib import Path
import json
import re
import subprocess

HERE = Path(__file__).resolve().parent
PIN = HERE.parent / "cei-v81-final"
TEXT = (PIN / "FORMALIZATION_STATUS_V81.md").read_text().splitlines()
DECL = re.compile(r"^\s*(?:@\[[^]]+\]\s*)?(?:(?:private|protected|noncomputable|public|unsafe|nonrec|partial|meta|opaque)\s+)*(?:theorem|lemma|def|abbrev|structure|class|inductive|axiom|opaque|instance)\s+([\w'.»«₀-₉]+)")
LABEL = re.compile(r"^\| ((?:Theorem|Proposition|Definition|Lemma|Corollary) ([\dABCD]+\.\d+)); `([^ `]+)`")
LEAN_LINK = re.compile(r"\[([^]]+)\]\((Lean/[^)#]+\.lean)(?:#L(\d+)(?:-L?(\d+))?)?\)")
ALT = {"LC.":"CategoricalEssentialIncompleteness.LocalConnectedness.",
       "V46.":"CategoricalEssentialIncompleteness.V46."}
def git(*args):
    return subprocess.check_output(["git","-C",str(PIN),*args])
def get_declarations(lines):
    scopes = []
    output=[]
    for i,line in enumerate(lines):
        t=line.strip()
        if t.startswith("namespace "):
            scopes.append(("namespace",t.split()[1]))
        elif re.match(r"^(?:(?:noncomputable|public|private|protected) )*section(?:\s|$)", t):
            scopes.append(("section",t.partition("section")[2].strip().split(" ")[0]))
        elif re.fullmatch(r"end(?:\s+[\w.']+)?",t):
            target = t.partition(" ")[2]
            if target and any(n==target for _,n in scopes):
                while scopes and scopes[-1][1] != target: scopes.pop()
            if scopes: scopes.pop()
        m=DECL.match(line)
        if m and not line.startswith("  "):
            nm=m[1]
            prefix=".".join(n for k,n in scopes if k=="namespace")
            fqn=nm.removeprefix("_root_.") if nm.startswith("_root_.") else ".".join(filter(None,[prefix,nm]))
            statement=[t]
            for nxt in lines[i+1:i+95]:
                if ":=" in statement[-1] or " where" in statement[-1] or re.search(r"(^|\s)where$",statement[-1]):
                    break
                if not nxt.strip() or nxt.startswith(("/-", "end ", "namespace ", "variable ","theorem ","def ")): break
                statement.append(nxt.rstrip())
            output.append((fqn,i+1,"\n".join(statement).split(" := ",1)[0]))
    return output

def ref(path, start, stop=None):
    return {"path":path,"line":start,**({"through":stop} if stop is not None else {})}

decls = defaultdict(list)
files = {}
for file in sorted((PIN / "Lean").glob("**/*.lean")):
    path=file.relative_to(PIN).as_posix()
    if "/." in path or "/Tests/" in path: continue
    ls=file.read_text(errors="replace").splitlines()
    ds=get_declarations(ls)
    files[path]=(ls,ds)
    for full,line,sig in ds:
        obj={**ref(path,line),"name":full,"sourceSignature":sig}
        decls[full.split(".")[-1]].append(obj)

def located(sym, namespace):
    for short,full in ALT.items():
        if sym.startswith(short): sym=full+sym[len(short):]; break
    cand=decls[sym.split(".")[-1]]
    found=[v for v in cand if v["name"]==sym] or [v for v in cand if v["name"].endswith("."+sym)]
    if not found:
        return []
    def score(x):
        ns=x["name"].split(".")[:-1]
        common=0
        for a,b in zip(ns,namespace):
            if a!=b: break
            common+=1
        return (common,not x["path"].endswith("Checks.lean"),-len(ns))
    best=sorted(found,key=score,reverse=True)
    return [v for v in best if score(v)==score(best[0])]

rows=[]
corr_links=[]
for i,line in enumerate(TEXT,1):
    for text,path,start,stop in LEAN_LINK.findall(line):
        if not start: continue
        ls,ds=files[path]
        beg=int(start)
        selected=[d for d in ds if d[1]<=beg]
        nextd=[d for d in ds if d[1]>beg]
        near=(selected[-1] if selected else None) if not nextd or nextd[0][1]-beg>3 else nextd[0]
        corr_links.append({"correspondenceLine":i,"linkText":text,**ref(path,beg,int(stop) if stop else None),
                           "declaration":near[0] if near else None,"declarationLine":near[1] if near else None})
    m=LABEL.match(line)
    if not m: continue
    cols=line.split("|")
    raw=cols[3]
    ctx=[]; refs=[]; ambiguous=[]; unresolved=[]
    for sym in re.findall(r"`([^ `]+)`",raw):
        cs=located(sym,ctx)
        if not cs:
            unresolved.append(sym);continue
        if len(cs)>1: ambiguous.append({"token":sym,"candidates":[v["name"] for v in cs]})
        best=cs[0]
        refs.append({"token":sym,**best})
        ctx=best["name"].split(".")[:-1]
    rows.append({"result":m[1],"label":m[3],"correspondenceLine":i,"declarations":refs,
                 "sourceAlternatives":ambiguous,"unresolvedTokens":unresolved})

anchors=json.loads((HERE/"appendix-e-anchors.json").read_text())
for a in anchors:
    if not a["file"].startswith("Lean/"):continue
    path=a["file"]
    tagged=git("show","cei-v72-palomar-v3:"+path)
    pinned=git("show","HEAD:"+path)
    assert pinned==(PIN/path).read_bytes()
    ls=tagged.decode().splitlines(); ds=get_declarations(ls)
    inside=[(n,i) for n,i,_ in ds if a["lo"]<=i<=a["hi"]]
    before=[(n,i) for n,i,_ in ds if i<a["lo"]]
    a.update(taggedFileSHA256=sha256(tagged).hexdigest(),pinnedFileSHA256=sha256(pinned).hexdigest(),
             sourceRangeExists=a["hi"]<=len(ls),declarations=inside,preceding=before[-1] if before else None,
             unchangedLines=ls[a["lo"]-1:a["hi"]]==pinned.decode().splitlines()[a["lo"]-1:a["hi"]])
for dest,obj in [("numbered-source-comparison.json",rows),("correspondence-source-links.json",corr_links),("appendix-e-tested-links.json",anchors)]:
    (HERE/dest).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+"\n")
print(len(rows),"numbered rows,",sum(len(r["declarations"]) for r in rows),"cited tokens with actual source,",len(corr_links),"active correspondence anchors;",len(anchors),"printed Appendix E links")
print("Unresolved:",[(r["result"],r["unresolvedTokens"]) for r in rows if r["unresolvedTokens"]])
print("Ambiguous:",[(r["result"],[(o["token"],len(o["candidates"])) for o in r["sourceAlternatives"]]) for r in rows if r["sourceAlternatives"]])
