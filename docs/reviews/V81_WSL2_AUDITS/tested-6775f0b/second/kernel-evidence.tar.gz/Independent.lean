import CategoricalEssentialIncompleteness.V46ComputableTuringCategoryChecks
import CategoricalEssentialIncompleteness.V46EffectiveExtensibilityChecks
import CategoricalEssentialIncompleteness.V46TrivialDominicalCategoryChecks
import CategoricalEssentialIncompleteness.V46MillerFixedPoint

set_option autoImplicit false

open CategoryTheory PCategoryStruct RecursionCategory RestrictionCategory
open CategoricalEssentialIncompleteness.V46
open CategoricalEssentialIncompleteness.V46.ApplicativeSystem

namespace ReaderTwo

universe u v

section CockettHofstra
variable {C : Type u} [Category.{v} C] [PCategoryStruct C] [PCategory C]
variable {A Z : C} (a : nearProd A A ⟶ A) (t : (X : C) → (X ⟶ Z))
variable (z : IsRestrictionTerminal t)

theorem given_application (H : ∀ (n m : ℕ) (f : power Z A n ⟶ power Z A m),
    Polynomial a t n m f → Computable a t n m f) :
    let D := products a t z
    letI : PCategoryStruct (Powers a t) := D.pcategoryStruct
    letI : PCategory (Powers a t) := D.pcategoryLaws
    ∀ (X : Powers a t) (h : nearProd X (formal a t 1) ⟶ formal a t 1),
    ∃ p : X ⟶ formal a t 1, isTotal p ∧
      nearProd_map p (𝟙 (formal a t 1)) ≫ application a t z = h :=
  (ComputableTuringCategoryChecks.pca_turing a t z H).1

theorem arbitrary_powers (H : ∀ (n m : ℕ) (f : power Z A n ⟶ power Z A m),
    Polynomial a t n m f → Computable a t n m f) :
    let D := products a t z
    letI : PCategoryStruct (Powers a t) := D.pcategoryStruct
    letI : PCategory (Powers a t) := D.pcategoryLaws
    ∀ X Y : Powers a t, ∃ evaluator : nearProd (formal a t 1) X ⟶ Y,
      IsTuringMorphism evaluator :=
  (ComputableTuringCategoryChecks.pca_turing a t z H).2

include z in
theorem all_homs_and_representation
    (H : (X Y : C) → ∃ e : nearProd A X ⟶ Y, IsTuringMorphism e)
    (h : IsTuringMorphism a) :
    (∀ (n m : ℕ) (f : power Z A n ⟶ power Z A m), Computable a t n m f) ∧
    ∃ e : C ≌ (IdempotentSplitting.splitsIn (inclusion a t)).FullSubcategory,
      (∀ {X Y : C} (f : X ⟶ Y), e.functor.map (PCategoryStruct.rst f) = rst (e.functor.map f)) ∧
      (∀ {X Y} (f : X ⟶ Y), e.inverse.map (rst f) = PCategoryStruct.rst (e.inverse.map f)) := by
  obtain ⟨_, homs, _, repr⟩ := ComputableTuringCategoryChecks.turing_representation a t z H h
  exact ⟨homs, repr⟩

include z in
theorem terminal_to_terminal (f : Z ⟶ Z) :
    Computable a t 0 0 f ↔ ∃ p : Z ⟶ A,
      isTotal p ∧ f = PCategoryStruct.rst (p ≫ diag A ≫ a) :=
  ComputableTuringCategoryChecks.scalar_domain a t z f

end CockettHofstra

open FFL FFL.FirstOrder in
theorem complete_consistent_exception :
    ∃ T : Theory Janiczak.FOL.L, Entailment.Consistent T ∧
      ∀ p : Sentence Janiczak.FOL.L, ¬ ((¬ T ⊢ p) ∧ (¬ T ⊢ ∼p)) := by
  obtain ⟨T, cons, _, complete⟩ := EffectiveExtensibility.Checks.consistent_without_independent_sentence
  exact ⟨T, cons, fun p hp => complete ⟨p, hp⟩⟩

open CategoricalEssentialIncompleteness.LocalConnectedness CategoryTheory.CoprodStruct
open TrivialDominicalCategory in
theorem zero_category :
    DiPaolaHeller.IsTuringMorphism evaluator ∧
    ¬ Inseparable (Idem.pull (diag One.obj ≫ evaluator) (summand0 One.obj One.obj))
      (Idem.pull (diag One.obj ≫ evaluator) (summand1 One.obj One.obj)) := by
  obtain ⟨app, _, sep⟩ := Checks.turing_with_separable_domains
  exact ⟨app, sep⟩

theorem external_miller_witness : ∃ α : Miller.Point, Miller.IsMiller α :=
  Miller.exists_isMiller

#print axioms given_application
#print axioms arbitrary_powers
#print axioms all_homs_and_representation
#print axioms terminal_to_terminal
#print axioms complete_consistent_exception
#print axioms zero_category
#print axioms external_miller_witness

end ReaderTwo
