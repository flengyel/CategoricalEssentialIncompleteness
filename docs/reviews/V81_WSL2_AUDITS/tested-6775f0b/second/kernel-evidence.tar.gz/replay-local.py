from pathlib import Path
import subprocess,os,json,sys,datetime,hashlib,time,argparse
HERE=Path(__file__).resolve().parent
pa=argparse.ArgumentParser()
pa.add_argument('--checkout',type=Path,default=HERE.parent/'cei-v81-structure')
pa.add_argument('--mode',choices=['structure','numbered','historical','apply'],required=True)
pa.add_argument('--toolchains',type=Path,default=Path.home()/'.elan/toolchains')
args=pa.parse_args();root=args.checkout.resolve();L=root/'Lean'; own=HERE/'local-olean'
outdir=HERE/'command-evidence';outdir.mkdir(exist_ok=True)
logs=outdir/('commands-'+args.mode+'.jsonl')
tool=(L/'lean-toolchain').read_text().strip().replace('/','--').replace(':','---')
bin=args.toolchains/tool/'bin'/'lean'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
paths=[own,L/'.lake/build/lib/lean']+[p/'.lake/build/lib/lean' for p in sorted((L/'.lake/packages').iterdir())]
env=os.environ|{'LEAN_PATH':os.pathsep.join(map(str,paths)),'LEAN_NUM_THREADS':'1'}
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert commit=='6775f0b3a5fb668f9390b21440f3f6c57bc65930'
logs.write_text('')
def run(argv,label,source):
    path=outdir/(label+'.log')
    start=time.monotonic();now=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with path.open('w') as fp:
        res=subprocess.run(argv,cwd=L,env=env,stdout=fp,stderr=subprocess.STDOUT)
    with logs.open('a') as fp:fp.write(json.dumps(dict(label=label,source=str(source),source_sha256=sha(source),start=now,checkout_commit=commit,argv=[str(a) for a in argv],cwd=str(L),LEAN_PATH=env['LEAN_PATH'],elapsed_seconds=round(time.monotonic()-start,3),exit_code=res.returncode,log=path.name,log_sha256=sha(path)))+'\n')
    print(label,res.returncode,flush=True)
    if res.returncode:print(path.read_text()[-5600:]);sys.exit(res.returncode)
opts=[bin,'-j1','-DwarningAsError=true','-DautoImplicit=false']
if args.mode=='structure':
    names=subprocess.check_output(['git','diff','--name-only','HEAD^','HEAD','--','Lean/CategoricalEssentialIncompleteness/V46*.lean'],cwd=root,text=True).splitlines()
    files={Path(f).stem:root/f for f in names}
    existing=L/'.lake/build/lib/lean/CategoricalEssentialIncompleteness'
    overlay=own/'CategoricalEssentialIncompleteness'
    overlay.mkdir(parents=True,exist_ok=True)
    for f in existing.iterdir():
        if f.name.split('.')[0] in files:continue
        if not (overlay/f.name).exists() and not (overlay/f.name).is_symlink():(overlay/f.name).symlink_to(f)
    seen=set()
    def build(name):
        if name in seen:return
        seen.add(name);f=files[name]
        for line in f.read_text().splitlines():
            if 'import ' not in line:continue
            dep=line.split('import ',1)[1].rsplit('.',1)[-1].strip()
            if dep in files:build(dep)
        of=own/'CategoricalEssentialIncompleteness'/(name+'.olean');of.parent.mkdir(parents=True,exist_ok=True)
        run(opts+['--root='+str(L),'-o',of,f],name,f)
    for k in sorted(files):build(k)
else:
    f=HERE/({'numbered':'Numbered.lean','historical':'History.lean','apply':'Independent.lean'}[args.mode])
    run(opts+[f],args.mode,f)
