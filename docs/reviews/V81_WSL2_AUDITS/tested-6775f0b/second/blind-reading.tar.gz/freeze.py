from collections import Counter
import csv,hashlib,json,re,subprocess,datetime
from pathlib import Path
import read_manuscript as rd
D=rd.HERE
s=rd.sections
rows=rd.DATA
notes=(D/'reconstruction.txt').read_text().splitlines()
assert len(notes)==len(rd.initial)==80
nums=[]
for i,([file,line,typ,lab],note) in enumerate(zip(rd.initial,notes),1):
    textp=(rd.M/file).read_text()
    ls=textp.splitlines()
    body='\n'.join(ls[line-1:])
    stmt=re.search(r'\\begin\{'+typ+r'\}(.*?)\\end\{'+typ+r'\}',body,re.S)[1]
    labels=re.findall(r'\\label\{((?:lem|thm|prop|cor|def):[^}]+)\}',stmt)
    assert labels
    current=[u for u in rows if u['file']=='manuscript/latex/'+file and u['start']==line][0]
    units=[u for u in rows if u['file']==current['file'] and u['start']>=line]
    k=0
    while k<len(units) and units[k]['role']==typ:k+=1
    while k<len(units) and (units[k]['role']=='proof' or units[k]['tex'].lstrip().startswith('\\begin{proof}')):k+=1
    stop=units[k-1]
    n_section=Counter(x['section'] for x in nums)[current['section']]+1
    j=s.index(current['section'])+1
    section_number=str(j) if j<11 else chr(ord('A')+j-11)
    num=section_number+'.'+str(n_section)
    nums.append(dict(ordinal=i,printed=num,section=current['section'],kind=typ,label=labels[0],aliases=labels[1:],source=current['file'],start=line,end=stop['end'],unit_first=current['id'],unit_last=stop['id'],reconstruction=note.split(' ',1)[1],statement_tex=stmt.strip()))
(D/'numbered-reconstruction.json').write_text(json.dumps(nums,indent=2,ensure_ascii=False)+'\n')
def dump(path,data):
    with (D/path).open('w') as fp:
        for d in data:fp.write(json.dumps(d,ensure_ascii=False)+'\n')
regex=r'(?<!\bp)(?<!\bc)(?<!e\.g)(?<!i\.e)(?<!\bpp)(?<=[.!?])(?=\s+(?:[A-Z]|\\(?:begin|end|\[|\()|\$|[A-Za-z]))'
atoms=[]
for u in rows:
    t=u['tex']; cursor=0
    ident=next((z for z in nums if u['file']==z['source'] and z['start']<=u['start']<=z['end']),None)
    cmds=bool(re.fullmatch(r'\s*(?:\\(?:label\{.*?\}|end\{.*?\}|Needspace\{.*?\}|appendix|begingroup|endgroup|clearpage|maketitle|tableofcontents|small)\s*)+',t,flags=re.S))
    role=u['role']
    if u['file'].endswith('/main.tex') or cmds or role=='heading':role='editorial locator'
    elif u['file'].endswith('/bibliography.tex'):role='bibliography'
    elif role in ['lemma','proposition','theorem','corollary']:role='numbered statement'
    elif role=='proof':role='proof step'
    else:role='definition' if role=='definition' else 'exposition'
    for j,m in enumerate(re.split(regex,t),1):
        i=t.find(m,cursor);cursor=i+len(m)
        if not m.strip():continue
        a=dict(id=u['id']+'.'+str(j),unit=u['id'],file=u['file'],start=u['start']+t.count('\n',0,i+len(m)-len(m.lstrip())),end=u['start']+t.count('\n',0,cursor),role=role,printed=ident['printed'] if ident else '',tex=m.strip())
        atoms.append(a)
dump('reading-assertions.jsonl',atoms)
(D/'numbered-source.tsv').write_text('ordinal\tprinted\tsource\tline\tkind\tlabel\n'+''.join(f"{n['ordinal']}\t{n['printed']}\t{n['source']}\t{n['start']}\t{n['kind']}\t{n['label']}\n" for n in nums))
print('assertion segments',len(atoms),'source units',len(rows),'distinct source documents',len(rd.filehash))
print({x['section']:x['printed'] for x in nums})
print('git commit',subprocess.check_output(['git','rev-parse','HEAD'],cwd=rd.ROOT,text=True).strip())
