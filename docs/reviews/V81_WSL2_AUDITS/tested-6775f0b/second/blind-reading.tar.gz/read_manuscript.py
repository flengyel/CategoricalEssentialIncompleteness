from pathlib import Path
from hashlib import sha256
import re, json, sys, subprocess, csv
from collections import Counter
from datetime import datetime, timezone
ROOT=Path('/home/flengyel/src/CategoricalEssentialIncompleteness/.codex-work/cei-v81-structure')
M=ROOT/'manuscript/latex'
HERE=Path(__file__).resolve().parent
DATA=[]
initial=[]
sections=[]
filehash={}
envnames='lemma|theorem|proposition|corollary|definition'
def scan(file):
    p=M/file
    txt=p.read_text()
    filehash[str(file)]=sha256(p.read_bytes()).hexdigest()
    lines=txt.splitlines()
    subsection=''
    phase='exposition'
    label=''
    buf=[]
    def emit():
        if not buf: return
        start=buf[0][0]; end=buf[-1][0]; rendered='\n'.join(v for _,v in buf)
        DATA.append(dict(id='R%04d'%(len(DATA)+1),file='manuscript/latex/'+str(file),start=start,end=end,section=sections[-1] if sections else 'Abstract',subsection=subsection,label=label,role=phase,tex=rendered))
        buf.clear()
    for n,l in enumerate(lines,1):
        inc=re.match(r'\\input\{([^}]+)\}',l)
        if inc:
            emit()
            if inc[1] not in ('preamble.tex','sections.tex'):
                scan(inc[1])
            continue
        sec=re.match(r'\\(section|subsection)\{',l)
        if sec:
            emit()
            title=re.sub(r'\\label\{.*','',l[l.index('{')+1:]).rstrip('}').strip()
            if sec[1]=='section':sections.append(title);subsection=''
            else:subsection=title
            phase='heading';label='';buf=[(n,l)];emit();phase='exposition';continue
        en=re.search(r'\\begin\{('+envnames+r')\}(?:\[[^\]]*\])?\s*(?:\\label\{([^}]+)\})?',l)
        if en:
            emit();phase=en[1];label=en[2] or '';initial.append([str(file),n,phase,label]);buf.append((n,l));continue
        if re.search(r'\\begin\{proof\}',l):
            emit();phase='proof';buf.append((n,l));continue
        if re.search(r'\\end\{('+envnames+r'|proof)\}',l):
            buf.append((n,l));emit();phase='exposition'
            if '\\end{proof}' in l:label=''
            continue
        if l.strip():buf.append((n,l))
        else:emit()
    emit()
scan('main.tex')
(HERE/'reading-units.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in DATA))
(HERE/'source-sha256.json').write_text(json.dumps(filehash,indent=2)+'\n')
with (HERE/'numbered-source.tsv').open('w') as fp:
    w=csv.writer(fp,delimiter='\t',lineterminator='\n');w.writerow(['source','line','kind','label']);w.writerows(initial)
def pretty(t):
    alt={'\\rightharpoonup':'⇀','\\hookrightarrow':'↪','\\longrightarrow':'⟶','\\rightarrow':'→','\\mapsto':'↦','\\operatorname':'','\\mathrm':'','\\mathbf':'','\\mathscr':'','\\mathcal':'','\\mathsf':'','\\texttt':'','\\emph':'','\\cite':'c.','\\ref':'#','\\label':'@','\\qquad':' ','\\quad':' ','\\theta':'θ','\\lambda':'λ','\\nu':'ν','\\Gamma':'Γ','\\gamma':'γ','\\tau':'τ','\\varphi':'φ','\\Phi':'Φ','\\psi':'ψ','\\alpha':'α','\\beta':'β','\\sigma':'σ','\\rho':'ρ','\\pi':'π','\\chi':'χ','\\eta':'η','\\Delta':'Δ','\\delta':'δ','\\iota':'ι','\\kappa':'κ','\\phi':'φ','\\mu':'μ','\\omega':'ω','\\varepsilon':'ε','\\epsilon':'ε','\\bot':'⊥','\\top':'⊤','\\wedge':'∧','\\vee':'∨','\\times':'×','\\colon':':','\\to':'→','\\in':'∈','\\forall':'∀','\\exists':'∃','\\leq':'≤','\\le':'≤','\\ne':'≠','\\circ':'∘','\\equiv':'≡','\\cong':'≅','\\subseteq':'⊆','\\subset':'⊂','\\im':'im','\\ker':'ker','\\rangle':'⟩','\\langle':'⟨','\\left':'','\\right':'','\\begin{proof}':'','\\end{proof}':'','\\neg':'¬','\\ldots':'…','\\cdots':'⋯'}
    for k in sorted(alt,key=len,reverse=True):
        if k[-1].isalpha():t=re.sub(re.escape(k)+r'(?![a-zA-Z])',lambda m:alt[k],t)
        else:t=t.replace(k,alt[k])
    t=re.sub(r'\\(begin|end)\{(theorem|proposition|lemma|corollary|definition)\}','',t)
    t=t.replace('\\[',' ').replace('\\]',' ').replace('\\,',' ').replace('\\!','').replace('~',' ').replace('$','')
    t=' '.join(t.split())
    return t
if len(sys.argv)>1:
    files=sys.argv[1:]
    for u in DATA:
        if any(u['file'].endswith(a+'.tex') for a in files):
            print(f"{u['id']} {u['start']}-{u['end']} {u['role']} {pretty(u['tex'])}")
else:
    print(len(DATA),'reading units,',len(initial),'numbered environments;',Counter(e[2] for e in initial))
    print('\n'.join(f'{i+1}. {e[0]}:{e[1]} {e[2]} {e[3]}' for i,e in enumerate(initial)))
