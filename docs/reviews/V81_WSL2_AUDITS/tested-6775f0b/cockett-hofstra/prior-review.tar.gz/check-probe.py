import hashlib
import json
import os
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path


scratch = Path(__file__).resolve().parent
repo = scratch.parents[1]
lean_root = repo / ".codex-work/cei-v81-literature/Lean"
pca = repo / ".codex-work/v81-pca"
path = subprocess.check_output(
    ["lake", "env", "printenv", "LEAN_PATH"], cwd=lean_root, text=True
).strip()
binary = subprocess.check_output(["elan", "which", "lean"], cwd=lean_root, text=True).strip()
env = dict(os.environ, LEAN_PATH=str(pca / "build") + ":" + path, LEAN_NUM_THREADS="1")
file = scratch / "PCAObservations.lean"
module_dir = pca / "src/CategoricalEssentialIncompleteness"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inputs():
    queue = [file]
    seen = {}
    imports = r"^public import CategoricalEssentialIncompleteness\.(\w+)$"
    while queue:
        unit = queue.pop()
        for name in re.findall(imports, unit.read_text(), re.MULTILINE):
            source = module_dir / (name + ".lean")
            if name in seen or not source.is_file():
                continue
            receipt = json.loads((pca / (name + ".json")).read_bytes())
            seen[name] = {
                "source_sha256": digest(source),
                "olean_sha256": digest(pca / "build/CategoricalEssentialIncompleteness" / (name + ".olean")),
                "producer_exit": receipt["exit_code"],
                "producer_source_sha256": receipt["source_sha256"],
            }
            queue.append(source)
    return dict(sorted(seen.items()))


args = [
    binary,
    "--threads=1",
    "--memory=1700",
    "-DwarningAsError=true",
    "-R",
    str(scratch),
    str(file),
]
before = inputs()
run = subprocess.run(args, cwd=lean_root, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
(scratch / "PCAObservations.log").write_bytes(run.stdout)
evidence = {
    "tested_at_utc": datetime.now(timezone.utc).isoformat(),
    "tested_base_commit": subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=lean_root, text=True
    ).strip(),
    "source_sha256": hashlib.sha256(file.read_bytes()).hexdigest(),
    "log_sha256": hashlib.sha256(run.stdout).hexdigest(),
    "argv": args,
    "dependencies": before,
    "inputs_stable": before == inputs(),
    "producer_sources_match": all(
        row["source_sha256"] == row["producer_source_sha256"] and row["producer_exit"] == 0
        for row in before.values()
    ),
    "returncode": run.returncode,
}
(scratch / "PCAObservations.json").write_text(json.dumps(evidence, indent=2) + "\n")
print(run.stdout.decode(), end="")
raise SystemExit(run.returncode)
