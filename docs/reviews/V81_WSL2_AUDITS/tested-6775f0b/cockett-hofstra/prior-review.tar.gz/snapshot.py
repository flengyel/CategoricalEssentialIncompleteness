import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path


scratch = Path(__file__).resolve().parent
root = scratch.parents[1]
base = root / ".codex-work/v81-pca"
directory = base / "src/CategoricalEssentialIncompleteness"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


modules = {}
for source in sorted(directory.glob("*.lean")):
    name = source.stem
    recorded = base / (name + ".json")
    row = {"source_sha256": digest(source)}
    if recorded.exists():
        receipt = json.loads(recorded.read_bytes())
        row.update(
            producer_returncode=receipt["exit_code"],
            producer_source_matches=receipt["source_sha256"] == row["source_sha256"],
            producer_receipt_sha256=digest(recorded),
            producer_log_sha256=digest(base / (name + ".log")),
        )
    olean = base / "build/CategoricalEssentialIncompleteness" / (name + ".olean")
    if olean.is_file():
        row["olean_sha256"] = digest(olean)
    modules[name] = row

result = {
    "observed_at_utc": datetime.now(timezone.utc).isoformat(),
    "base_commit": subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=root / ".codex-work/cei-v81-literature", text=True
    ).strip(),
    "modules": modules,
}
(scratch / "scope-at-review.json").write_text(json.dumps(result, indent=2) + "\n")
