from pathlib import Path
import hashlib, json, re, sys
from datetime import datetime,timezone
base=(Path(__file__).resolve().parent.parent/'cei-v81-structure'/'manuscript/latex')
out=Path(__file__).resolve().parent
pieces=[]; rows=[]; sources={}; paragraphs=[]; sec=0; counter=0; app=False
carry=None
def visit(name):
    global sec,counter,app,carry
    p=base/name; raw=p.read_bytes(); sources[name]=hashlib.sha256(raw).hexdigest()
    part=[]; first=None
    def flush():
        nonlocal part,first
        if part: paragraphs.append(dict(slot=len(paragraphs)+1,file=name,first=first,last=first+len(part)-1,section=(chr(64+sec) if app else str(sec)) if sec else 'abstract',tex='\n'.join(part))); part=[]; first=None
    for n,line in enumerate(raw.decode().splitlines(),1):
        m=re.match(r'\\input\{([^}]+)\}',line)
        if m:
            flush();visit(m[1]);continue
        if line.startswith('\\appendix'): app=True; sec=0;counter=0
        if line.startswith('\\section{'): sec+=1;counter=0
        for typ in ['theorem','definition','proposition','corollary','lemma']:
            if line.startswith('\\begin{'+typ+'}'):
                counter+=1
                label=(chr(64+sec) if app else str(sec))+'.'+str(counter)
                carry={'number':label,'env':typ,'file':name,'first':n,'st':[]};rows.append(carry)
        if carry:
            carry['st'].append(line)
            if '\\end{'+carry['env']+'}' in line:
                carry['last']=n;carry['statement']='\n'.join(carry.pop('st'));carry['id']=re.search(r'\\label\{([^}]+)\}',carry['statement'])[1];carry=None
        if not line.strip():flush()
        else:
            if first is None:first=n
            part.append(line)
        pieces.append((name,n,line))
    flush()
visit('main.tex')
for name,value in [('transcription',rows),('passages',paragraphs),('sources',sources)]:
    (out/(name+'.json')).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
compact=[(r'\\operatorname\{([^{}]+)\}',r'\1'),(r'\\(?:mathsf|mathrm|mathbf|mathcal|mathscr|mathfrak|text|texttt|emph)\{([^{}]+)\}',r'\1'),(r'\\(?:label|eqref|ref)\{([^{}]+)\}',r'[\1]'),(r'\\begin\{(equation\*?|gather\*?|align\*?|aligned|gathered|cases|tikzcd|split)\}|\\end\{(equation\*?|gather\*?|align\*?|aligned|gathered|cases|tikzcd|split)\}',''),(r'\\(?:left|right|big|Big|bigl|bigr|biggl|biggr|quad|qquad|mathbin|mathrel)\b',''),(r'\\(?:,|;|!|:|\[|\])',' '),(r'\$|~|\&',' ')]
repl={'rightharpoonup':'⇀','hookrightarrow':'↪','rightarrow':'→','leftarrow':'←','longrightarrow':'→','longmapsto':'↦','mapsto':'↦','xrightarrow':'→','to':'→','Rightarrow':'⇒','Longleftrightarrow':'⇔','Longrightarrow':'⇒','iff':'⇔','leq':'≤','le':'≤','geq':'≥','ge':'≥','neq':'≠','ne':'≠','circ':'∘','times':'×','Delta':'Δ','Phi':'Φ','varphi':'φ','phi':'φ','psi':'ψ','chi':'χ','tau':'τ','sigma':'σ','theta':'θ','nu':'ν','lambda':'λ','pi':'π','delta':'δ','epsilon':'ε','varepsilon':'ε','kappa':'κ','iota':'ι','alpha':'α','beta':'β','eta':'η','widetilde':'~','widehat':'^','bar':'bar','overline':'bar','sim':'~','cong':'≅','simeq':'≃','vee':'∨','wedge':'∧','top':'⊤','bot':'⊥','subseteq':'⊆','subset':'⊂','forall':'∀','exists':'∃','langle':'⟨','rangle':'⟩','in':'∈','notin':'∉','neg':'¬','N':'ℕ','infty':'∞','ell':'ℓ','Crec':'Crec','Adm':'Adm','Tm':'Tm','Fm':'Fm','FV':'FV','ran':'ran','ok':'ok','fail':'fail','PA':'PA','Pfn':'Pfn','Two':'2','Split':'Split','Par':'Par','Tot':'Tot','Mono':'Mono','im':'im','Da':'Da','mathbb':'','qquad':' ','quad':' '}
def compact_line(s):
    for a,b in compact:s=re.sub(a,b,s)
    s=re.sub(r'\\([a-zA-Z]+)',lambda a:repl.get(a[1],a[1]),s)
    s=s.replace('\\\\',' ').replace('{','(').replace('}',')')
    return ' '.join(s.split())
if len(sys.argv)>1:
    sel=sys.argv[1].split(','); lo,hi=map(int,sys.argv[2:4]) if len(sys.argv)>2 else (0,10000)
    for p in paragraphs:
        if any(p['file'].split('/')[-1].startswith(s) for s in sel) and lo<=p['first']<hi: print(str(p['first'])+'. '+compact_line(p['tex']))
