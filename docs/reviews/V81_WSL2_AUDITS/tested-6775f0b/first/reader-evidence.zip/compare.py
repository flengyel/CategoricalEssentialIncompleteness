import json,re,hashlib,subprocess,gzip,os,sys
from pathlib import Path
from collections import Counter,defaultdict
out=Path(__file__).resolve().parent; base=out.parent/'cei-v81-structure'; lean=base/'Lean'
blind=json.loads((out/'transcription.json').read_text()); ass=json.loads((out/'passages.json').read_text())
src=base/'docs/reviews/V81_PROOF_COMPARISONS/numbered-receipt.md'
table=base/'FORMALIZATION_STATUS_V81.md'
cross=src.read_text().splitlines(); status=table.read_text().splitlines()
rows=[]; decls={}; check=['set_option format.width 150','set_option pp.fullNames true']; imports=set()
for r in blind:
    n=r['number']; label=r['id']
    ti=next(i for i,s in enumerate(status,1) if re.match(r'^\| (Theorem|Lemma|Proposition|Corollary|Definition) '+re.escape(n)+r';',s))
    si,sl=next((i,s) for i,s in enumerate(cross,1) if s.startswith('| [') and f' {n}](' in s and f'`{label}`' in s)
    matches=re.findall(r'\b([CRSM]) \[`([^`]+)`\]\(\.\./\.\./\.\./(Lean/[^\)#]+\.lean)(?:#L(\d+))?\)',sl)
    names=[];coll=[]
    for kind,raw,path,lin in matches:
        if kind=='M':coll.append({'label':raw,'path':path});continue
        name = re.sub(r'^V46\.',r'CategoricalEssentialIncompleteness.V46.', re.sub(r'^LC\.',r'CategoricalEssentialIncompleteness.LocalConnectedness.',raw))
        loc=nlin=int(lin); source=(base/path).read_text().splitlines(); short=name.split('.')[-1]; line=source[loc-1].strip(); near=next((j for j in sorted(range(max(1,loc-30),min(len(source),loc+30)+1),key=lambda j:abs(j-loc)) if re.search(r'(?:theorem|lemma|abbrev|structure|class|inductive|def|alias|instance|opaque|abbrev)\s+(?:[A-Za-z0-9_]+\.)*'+re.escape(short)+r'(?=[^\w]|$)',source[j-1])),None)
        idx=dict(name=name,source=path,line=loc,verified_source_decl_line=near)
        if name in decls and decls[name]!=idx: print('different line',name,file=sys.stderr)
        decls[name]=idx
        names.append(name)
        imports.add(path.removeprefix('Lean/').removesuffix('.lean').replace('/','.'))
    if not names: raise ValueError(n)
    cells=status[ti-1].split('|')
    rows.append({'number':n,'kind':r['env'],'printed_label':label,'tex':r['file'],'lines':[r['first'],r['last']],'correspondence_line':ti,'crosswalk_line':si,'declaration_names':names,'collection_links':coll,'source_description':cells[2].strip(),'hypotheses_and_dependencies':cells[4].strip(),'current_statement_column':cells[3].strip()})
(out/'numbered.json').write_text(json.dumps({'tested_commit':'6775f0b3a5fb668f9390b21440f3f6c57bc65930','rows':rows,'declarations':decls},indent=2,ensure_ascii=False)+'\n')
for name in decls:
    check.extend([f'#check @{name}',f'#print axioms {name}'])
(out/'Numbered.lean').write_text('\n'.join('import '+i for i in sorted(imports))+'\n'+'\n'.join(check)+'\n')
print('numbered rows',len(rows),'distinct',len(decls),'mentions',sum(len(r['declaration_names']) for r in rows),'imports',len(imports),'no syntax line',sum(v['verified_source_decl_line'] is None for v in decls.values()),'prefixes',Counter(s.split('.')[0] for s in decls))
print('missing object files',[m for m in imports if not (lean/'.lake/build/lib/lean'/Path(*m.split('.'))).with_suffix('.olean').is_file()])
