import CategoricalEssentialIncompleteness.V46ComputableTuringCategoryChecks

set_option autoImplicit false
noncomputable section
open CategoryTheory Idempotents PCategoryStruct RecursionCategory RestrictionCategory
open CategoricalEssentialIncompleteness.V46 CategoricalEssentialIncompleteness.V46.ApplicativeSystem
namespace ReaderOne
universe v u
variable {C : Type u} [Category.{v} C] [PCategoryStruct C] [PCategory C]
variable {A Z : C} (app : nearProd A A ⟶ A) (t : ∀ X : C, X ⟶ Z)

theorem powers_have_typed_evaluators (terminal : IsRestrictionTerminal t)
    (pca : CombinatoriallyComplete app t) :
    let prod := products app t terminal
    letI : PCategoryStruct (Powers app t) := prod.pcategoryStruct
    letI : PCategory (Powers app t) := prod.pcategoryLaws
    ∀ X Y : Powers app t, ∃ ev : nearProd (formal app t 1) X ⟶ Y, IsTuringMorphism ev := by
  have h := (ComputableTuringCategoryChecks.combinatory_completeness app t terminal).mp pca
  exact (ComputableTuringCategoryChecks.pca_turing app t terminal h).2

theorem original_application_has_computable_total_parameters (terminal : IsRestrictionTerminal t)
    (pca : CombinatoriallyComplete app t) :
    let prod := products app t terminal
    letI : PCategoryStruct (Powers app t) := prod.pcategoryStruct
    letI : PCategory (Powers app t) := prod.pcategoryLaws
    ∀ (X : Powers app t) (f : nearProd X (formal app t 1) ⟶ formal app t 1),
      ∃ g : X ⟶ formal app t 1, isTotal g ∧
        nearProd_map g (𝟙 (formal app t 1)) ≫ application app t terminal = f := by
  have h := (ComputableTuringCategoryChecks.combinatory_completeness app t terminal).mp pca
  exact (ComputableTuringCategoryChecks.pca_turing app t terminal h).1

theorem powers_and_split_equivalence (terminal : IsRestrictionTerminal t)
    (hasEvaluators : ∀ X Y : C, ∃ ev : nearProd A X ⟶ Y, IsTuringMorphism ev)
    (universal : IsTuringMorphism app) :
    (∀ n m (f : power Z A n ⟶ power Z A m), Computable app t n m f) ∧
    (∀ X : Powers app t, IdempotentSplitting.splitsIn (inclusion app t) ((toKaroubi _).obj X)) ∧
    ∃ equiv : C ≌ (IdempotentSplitting.splitsIn (inclusion app t)).FullSubcategory,
      (∀ {P Q} (f : P ⟶ Q), equiv.inverse.map (rst f) = PCategoryStruct.rst (equiv.inverse.map f)) ∧
      (∀ {X Y : C} (f : X ⟶ Y), equiv.functor.map (PCategoryStruct.rst f) = rst (equiv.functor.map f)) := by
  obtain ⟨_, allPowers, ids, equiv, fwd, bwd⟩ :=
    ComputableTuringCategoryChecks.turing_representation app t terminal hasEvaluators universal
  exact ⟨allPowers, ids, equiv, bwd, fwd⟩

theorem exact_scalar (terminal : IsRestrictionTerminal t) (f : Z ⟶ Z) :
    (∃ p : Z ⟶ A, isTotal p ∧ f = PCategoryStruct.rst (p ≫ diag A ≫ app)) ↔
      Computable app t 0 0 f :=
  (ComputableTuringCategoryChecks.scalar_domain app t terminal f).symm

#print axioms powers_have_typed_evaluators
#print axioms original_application_has_computable_total_parameters
#print axioms powers_and_split_equivalence
#print axioms exact_scalar
end ReaderOne
