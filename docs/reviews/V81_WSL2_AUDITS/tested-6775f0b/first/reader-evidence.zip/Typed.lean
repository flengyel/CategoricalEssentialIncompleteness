import CategoricalEssentialIncompleteness.V46TrivialDominicalCategoryChecks
import CategoricalEssentialIncompleteness.V46EffectiveExtensibilityChecks
import CategoricalEssentialIncompleteness.V46ManuscriptPassageApplicationsChecks
import CategoricalEssentialIncompleteness.V46ArithmeticUniformIndependent
import CategoricalEssentialIncompleteness.V46MillerUnanimity
import CategoricalEssentialIncompleteness.V46OracleAndApplicationChecks

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option backward.isDefEq.respectTransparency.types false
noncomputable section
open CategoryTheory CategoryTheory.Limits CategoryTheory.RestrictionCategory
open CategoricalEssentialIncompleteness CategoricalEssentialIncompleteness.LocalConnectedness
open CategoricalEssentialIncompleteness.V46
namespace ReaderOne

open CategoryTheory.PCategoryStruct CategoryTheory.CoprodStruct
open TrivialDominicalCategory in
theorem trivial_object_counterexample :
    DiPaolaHeller.IsTuringMorphism evaluator ∧
      ¬ Inseparable (Idem.pull (diag One.obj ≫ evaluator) (summand0 One.obj One.obj))
        (Idem.pull (diag One.obj ≫ evaluator) (summand1 One.obj One.obj)) :=
  ⟨Checks.turing_with_separable_domains.1, Checks.turing_with_separable_domains.2.2⟩

open FFL FFL.FirstOrder in
theorem complete_consistent_decidable_presentation :
    ∃ T : Theory Janiczak.FOL.L, Entailment.Consistent T ∧
      ComputablePred (fun n : ℕ ↦ ∃ p : Sentence Janiczak.FOL.L, Encodable.encode p = n ∧ p ∈ T) ∧
      ∀ p : Sentence Janiczak.FOL.L, T ⊢ p ∨ T ⊢ ∼p := by
  classical
  obtain ⟨T, hc, hd, h⟩ := EffectiveExtensibility.Checks.consistent_without_independent_sentence
  refine ⟨T, hc, hd, fun p => ?_⟩
  by_cases hp : T ⊢ p
  · exact Or.inl hp
  · exact Or.inr (Classical.byContradiction fun hn => h ⟨p, hp, hn⟩)

section Interpretation
open PartialMaps
variable {D : Type*} [Category* D] [Regular D]
variable {C : Type*} [Category* C] [RestrictionCategory C] [Ranges C]
variable [CoprodStruct C] [CategoryTheory.HasCoproducts C] [HasZeroMorphisms C]
variable [CoprodStruct (Par D)] [CategoryTheory.HasCoproducts (Par D)] [HasZeroMorphisms (Par D)]

theorem regular_image_factor (G : RangeFunctor C (Par D)) {P T S : C}
    (c : P ⟶ S) (hc : isTotal c) (m : T ⟶ S) (hm : isTotal m)
    (r : S ⟶ T) (t : Idem S) (ht : t = Ranges.range c)
    (hmr : m ≫ r = 𝟙 T) (hrm : r ≫ m = t.hom)
    {V : D} (v : V ⟶ (G.toFunctor.obj S).obj) [Mono v] :
    (∃ k : (G.toFunctor.obj P).obj ⟶ V, k ≫ v = totalValue (G.toFunctor.map c) (G.map_total c hc)) →
      ∃! w : (G.toFunctor.obj T).obj ⟶ V, w ≫ v = totalValue (G.toFunctor.map m) (G.map_total m hm) := by
  rintro ⟨k, h⟩
  exact interpreted_theory_unique_factor G c hc m hm r t ht hmr hrm v k h
end Interpretation

open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic FFL.Entailment
open NamedArithmeticSignature ArithmeticUniformIndependent

theorem one_family_morphism :
    ∃ q : ArithmeticIndexedAxioms.parameter ⟶ ArithmeticIndexedAxioms.sentence,
      ∀ e : ℕ, Entailment.Consistent (ArithmeticNamedProofConnectives.system (gamma e)) →
        ∃ φ : Formula, φ.freeVariables = [] ∧
          ((PredicateInterpretation.canonicalDomainFunctor 𝗣𝗔 ℕ).map q
              (NamedArithmeticLiteralTotal.omegaPoint 𝗣𝗔 ℕ e)).val.val = formulaCode φ ∧
          ¬ SyntacticNamedHilbert.Derives functionSymbols relationSymbols bound (gamma e) (.neg φ) ∧
          ¬ SyntacticNamedHilbert.Derives functionSymbols relationSymbols bound (gamma e) φ := by
  obtain ⟨q, hq⟩ := uniform_independent_sentences
  refine ⟨q, fun e h => ?_⟩
  obtain ⟨φ, hc, hw, hp, hn⟩ := hq e h
  exact ⟨φ, hc, hw.symm, hn, hp⟩

open Miller in
theorem one_unanimity_machine :
    ∃ d : ℕ, ∀ (x : Point) (p : Bits), p ∈ representations x → ∀ e n : ℕ,
      (OracleProgram.numberedEval d p (Nat.pair e n)).Dom ↔
        ∃ k, ∀ q ∈ representations x, k ∈ OracleProgram.numberedEval e q n :=
  ⟨Unanimity.unanimityIndex, fun x p hp e n => Unanimity.unanimityIndex_domain x p hp e n⟩

open OracleComputation OracleComputation.Restricted in
theorem one_specializer_works_for_every_oracle :
    ∃ s : ℕ → ℕ → ℕ, Computable₂ s ∧ ∀ (A : Set ℕ) (e z x : ℕ),
      (Miller.OracleProgram.numberedEval (s e z) (bits A) x).Dom ↔
        (Miller.OracleProgram.numberedEval e (bits A) (Nat.pair z x)).Dom :=
  ⟨sectionIndex, sectionIndex_computable, machine_section⟩

#print axioms trivial_object_counterexample
#print axioms complete_consistent_decidable_presentation
#print axioms regular_image_factor
#print axioms one_family_morphism
#print axioms one_unanimity_machine
#print axioms one_specializer_works_for_every_oracle
end ReaderOne
