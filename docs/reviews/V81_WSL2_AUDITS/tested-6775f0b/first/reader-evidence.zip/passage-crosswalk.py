from pathlib import Path
from collections import Counter
import json,re
out=Path(__file__).resolve().parent;c=out.parent/'cei-v81-structure'
data=json.loads((out/'passages.json').read_text());num=json.loads((out/'transcription.json').read_text())
status=(c/'FORMALIZATION_STATUS_V81.md').read_text().splitlines()
d=c/'docs/reviews/V80_ASSERTIONS'
inputs={Path(x['file']).name:x['file'] for x in data}
ranges=[]
def append(path,start,end,doc,line,reason):
    ranges.append(dict(file=path,start=start,end=end,dossier=doc,line=line,role=reason))
specs={'01-introduction-and-comparison':{'## Abstract':'abstract.tex','## §1':'01-introduction.tex','## §2':'02-categorical-preliminaries.tex','## §3':'03-sections-and-inseparability.tex'},'04-theories-and-slices':{'## §4, theories':'03a-internal-theories.tex','## §4, generation':'03b-internal-adjunctions.tex','## §5':'04-theory-extensions.tex','## Appendix A':'a-syntax-and-theories.tex'},'08-arithmetic':{},'09-miller-and-cosheaves':{},'06-syntax-and-models':{},'appendices-c-e':{'### C.':'c-section-lifting.tex','### E.':'e-reading-lean-proofs.tex'}}
prefix={'P':'05a-internal-syntax.tex','S':'05-syntactic-recursion-category.tex','D':'d-faithful-family.tex','M':'06-interpretation-in-models.tex'}
for stem,keys in specs.items():
    path=d/(stem+'.md'); name=doc=None
    for i,s in enumerate(path.read_text().splitlines(),1):
        if s.startswith('#'):
            name=next((v for k,v in keys.items() if s.startswith(k)),None)
            m=re.search(r'([\w-]+\.tex)',s)
            if m:name=m[1]
        if not s.startswith('| '):continue
        key=s.split('|')[1].strip()
        if stem=='06-syntax-and-models':
            if not key[:1] in prefix:continue
            name=prefix[key[0]]
        if not name:continue
        for a,b in re.findall(r'(\d+)[–-](\d+)',key):
            start,end=int(a),int(b)
            if name.startswith('c-section-'):
                if start>=115:start+=5
                if end>=115:end+=5
                if end==114:end=119
            append(inputs[name],start,end,str(path.relative_to(c)),i,'transferred v80 range')
um=d/'unnumbered-coverage.md'
for i,s in enumerate(um.read_text().splitlines(),1):
    m=re.search(r'manuscript/latex/([^:]+\.tex):(\d+)(?:–(\d+))?',s)
    if m:append(m[1],int(m[2]),int(m[3] or m[2]),str(um.relative_to(c)),i,'exact single passage')
source_rows={
 '01-introduction.tex':[(124,142,42),(161,171,0),(173,176,66),(176,181,78),(177,185,80),(181,188,29),(189,197,30),(198,207,0),(208,212,81),(209,213,82),(213,217,29)],
 '02-categorical-preliminaries.tex':[(90,108,31),(185,210,31)],
 '03-sections-and-inseparability.tex':[(1,18,32)],
 '03a-internal-theories.tex':[(41,100,33),(237,254,63),(237,254,64)],
 '03b-internal-adjunctions.tex':[(359,397,65),(438,539,33)],
 '04-theory-extensions.tex':[(176,227,34)],
 '05-syntactic-recursion-category.tex':[(148,174,35)],
 '05a-internal-syntax.tex':[(279,324,36)],
 '08a-uniform-theories.tex':[(1,125,37)],
 '08b-uniform-independent-sentences.tex':[(4,9,67),(11,103,41)],
 '08-essential-incompleteness-of-arithmetic.tex':[(313,440,39),(288,410,40)],
 '04-miller-sequences.tex':[(3,46,42),(212,330,43),(477,581,44),(583,722,45)],
 '09-three-point-space.tex':[(1,43,46),(45,181,47),(181,277,48),(475,542,49)],
 'a-syntax-and-theories.tex':[(1,117,50),(1,117,51),(373,414,83),(416,451,84),(455,540,52),(542,563,53),(564,594,85),(564,594,86)],
 'b-three-point-cosheaves.tex':[(343,491,47),(573,618,54)],
 'c-section-lifting.tex':[(13,14,55),(97,160,55),(157,222,55)],
 'd-faithful-family.tex':[(121,145,56),(150,201,57)],
 'e-reading-lean-proofs.tex':[(192,239,44)]}
for f,groups in source_rows.items():
    for start,end,i in groups:
        if i:append(inputs[f],start,end,'FORMALIZATION_STATUS_V81.md',i,'current typed comparison')
        else:append(inputs[f],start,end,'docs/reviews/V81_WSL2_ASSERTIONS/historical-comparisons.md',1,'historical entries and outstanding proofs')
# These lines finish sentences that straddle intervals in the older line tables.
# Record their actual checked proofs, including the closing lines of a proof.
for name,start,end,mod,line in [
    ('08-essential-incompleteness-of-arithmetic.tex',161,162,'V46NamedArithmeticProofSearchPrinted',107),
    ('08-essential-incompleteness-of-arithmetic.tex',441,442,'V46ArithmeticSignedTotal',151),
    ('08-essential-incompleteness-of-arithmetic.tex',478,478,'V46ArithmeticAssociatedStructure',175),
    ('08-essential-incompleteness-of-arithmetic.tex',478,478,'V46ArithmeticAssociatedStructure',196),
    ('08-essential-incompleteness-of-arithmetic.tex',516,517,'V46ArithmeticAssociatedCategories',98),
    ('08c-numerical-realization.tex',174,174,'V46NumericalTuplesStructure',90)]:
    append(inputs[name],start,end,'Lean/CategoricalEssentialIncompleteness/'+mod+'.lean',line,'inference completing a printed sentence')
pitems=[]
for p in data:
    tex=p['tex'];f=p['file']; arr=[]
    for r in ranges:
        if r['file']==f and p['first']<=r['end'] and p['last']>=r['start']:arr.append(r)
    numbers=[n['number'] for n in num if n['file']==f and p['first']<=n['last'] and p['last']>=n['first']]
    record={k:p[k] for k in ('slot','file','first','last','section')};record.update(dossier_links=[{'path':r['dossier'],'line':r['line'],'role':r['role']} for r in arr],overlapping_numbered_statements=numbers)
    if f=='bibliography.tex':record['category']='reference';record['dossier_links']=[{'path':'docs/reviews/V80_ASSERTIONS/citation-index.md','line':1,'role':'bibliographic context'}]
    elif f in ['main.tex','preamble.tex']:record['category']='editorial TeX'
    elif arr or numbers:record['category']='read and compared'
    else:
        record['category']='section title or routing'; lines=[l for l in tex.splitlines() if not re.match(r'^\s*(%|\\(?:sub|appendix|section|label|input|end|begin))',l)]
        if lines: print('inspect',p['slot'],f,p['first'],p['last'],str(lines)[:200])
    pitems.append(record)
(out/'passage-crosswalk.json').write_text(json.dumps({'rows':pitems,'correspondence_ranges':ranges},ensure_ascii=False,indent=2)+'\n')
print('paragraphs',Counter(p['category'] for p in pitems),'comparison subranges',len(ranges))
