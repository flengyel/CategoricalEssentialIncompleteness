from pathlib import Path
from collections import Counter
import gzip,hashlib,json,re
o=Path(__file__).resolve().parent;c=o.parent/'cei-v81-structure';p=o/'publication';p.mkdir(exist_ok=True)
allowed={'propext','Classical.choice','Quot.sound'}
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def load(k):return json.loads((o/k).read_text())
def writez(path,data):
    path.write_bytes(gzip.compress((json.dumps(data,ensure_ascii=False,separators=(',',':'))+'\n').encode(),mtime=0))
def readtypes(stem,names):
    raw=(o/(stem+'.log')).read_text()
    reg=re.compile(r"^'([^\n]+)' (?:depends on axioms:\s*\[([^\]]*)\]|does not depend on any axioms)\s*$",re.M)
    types={};pos=0
    for match in reg.finditer(raw):
        n=match[1]; ax=sorted(a.strip() for a in (match[2] or '').split(',') if a.strip())
        t=raw[pos:match.start()].strip()
        assert n not in types and set(ax)<=allowed,(n,ax)
        assert t and n in t.split('\n',1)[0],(n,t[:130])
        types[n]=dict(type=t,axioms=ax);pos=match.end()
    assert set(types)==set(names) and not raw[pos:].strip(),(len(types),len(names))
    return types
nl=load('numbered.json');sup=load('supplemental.json')
numtypes=readtypes('Numbered',nl['declarations']);suptypes=readtypes('Supplemental',sup['names_in_first_probe'])
reread={}
for l in (o/'reconstruction.md').read_text().splitlines():
    m=re.match(r'^([A-D\d]+\.\d+) (.+)$',l)
    if m:reread[m[1]]=m[2]
verbatim={r['number']:r['statement'] for r in load('transcription.json')}
for r in nl['rows']:
    n=r['number'];r['reconstructed_inference']=reread[n];r['printed_statement']=verbatim[n];r['pdf']=load('print-numbered-pages.json')[n]
    # The stored earlier table has a stronger chronological label than the
    # outcome of this review. Its text is supplied as source context only.
    r['result_of_type_comparison']='construction at the printed type' if r['kind']=='definition' else 'checked implications at the printed types and hypotheses'
    r['name_count']=len(r['declaration_names'])
for n,v in nl['declarations'].items():
    v.update(numtypes[n]);v['source_sha256']=sha(c/v['source'])
for n,v in sup['names_in_first_probe'].items():
    v.update(suptypes[n]);v['source_sha256']=sha(c/v['source'])
for r in sup['modules'].values():r.pop('available')
sup['checked_declarations']=sup.pop('names_in_first_probe')
sup['scope']='All named public declarations found in the 85 modules linked by the 44 current corroborating passage rows. Anonymous examples remain locatable by source and line.'
writez(p/'numbered.json.gz',nl);writez(p/'supplemental.json.gz',sup)
cov=load('passage-crosswalk.json');raw=load('passages.json')
for x,y in zip(cov['rows'],raw):
    assert x['slot']==y['slot'];x['tex']=y['tex']
writez(p/'passages.json.gz',cov)
print('numbered rows',len(nl['rows']),'refs',sum(r['name_count'] for r in nl['rows']),'unique',len(numtypes),'modules',len({v['source'] for v in nl['declarations'].values()}),'collection',sum(len(r['collection_links']) for r in nl['rows']),'partial overlap',len(numtypes.keys()&suptypes.keys()))
print('supplemental',len(sup['rows']),len(sup['modules']),len(suptypes),'transitive axiom profile',dict(Counter('/'.join(v['axioms']) or 'empty' for v in numtypes.values())))
print('supplemental union coverage',sorted(set(a for v in suptypes.values() for a in v['axioms'])))
# The first and the longest explicit statement provide a short reader's index
# alongside the full types, available for every cited project declaration.
with (o/'review-types.txt').open('w') as f:
    for r in nl['rows']:
        names=r['declaration_names']; selections=[names[0],names[-1]]
        for nm in dict.fromkeys(selections):
            t=numtypes[nm]['type']
            for prefix in ['CategoricalEssentialIncompleteness.','LocalConnectedness.','CategoryTheory.','CategoryStruct.','FailureOfComposition.','V46.','FFL.FirstOrder.']:
                t=t.replace(prefix,'')
            f.write(r['number']+' '+t[:220].replace('\n',' ')+' … '+t[-380:].replace('\n',' ')+'\n')
