import json,re
from pathlib import Path
d=Path(__file__).resolve().parent;j=json.loads((d/'transcription.json').read_text())
s=(d/'printed.txt').read_text();last=-1;result={}
for r in j:
    head=r['env'].title()+' '+r['number']
    title=bool(re.search(r'\\begin\{(?:theorem|lemma|corollary|proposition|definition)\}\[',r['statement']))
    matches=list(re.finditer(r'^[\t \f]*'+re.escape(head)+(r'\s+\(' if title else '[.]'),s,re.M))
    m=next((m for m in matches if m.start()>last),None)
    if m is None:raise SystemExit('cannot locate '+head)
    last=m.start();page=1+s[:m.end()].count('\f');result[r['number']]={'page':page,'heading':s[m.start():s.find('\n',m.end())].lstrip()}
print('numbered PDF headers in printed order:',len(result),result['3.1'],result['D.2'])
(d/'print-numbered-pages.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
