Reader one, manuscript v81, source 6775f0b3a5fb668f9390b21440f3f6c57bc65930

The sealed reconstruction and digests were produced before any Lean consultation.
The raw numbered, supplemental, and typed applications were evaluated subsequently.
The first two Lean sources print every declaration's explicit type and axioms.
Typed.lean and Structure.lean build ten new applications and print their axioms.
ch-replay.json records a separate one-thread compilation of the twelve new
Cockett–Hofstra source modules and includes output artifact digests. A historical
scratch receipt for three modules named an earlier file hash. The new replay
used the files in the Git checkout and did not depend on those scratch objects.

To repeat the probes, use a detached checkout of the indicated commit with its
pinned toolchain, dependencies and existing production objects already built.
Extract the complete ZIP to one directory. From that directory run

  python3 replay-reader.py /path/to/checkout . /path/to/reader-work

The last argument should be a fresh writable working directory. Four output
digests check that the same named types and permitted axioms were seen.
The reader's replay is a targeted verification. To check an official stored
wrapper receipt separately, use the adjacent confirm-official.py, passing first
the .json.gz receipt and then a Git checkout containing the tested commit.

The retry log records discarded driver failures. The first numbered probe
exhausted its provisional 2450 MiB memory allowance. The next used an unknown
pretty-print option. The successful 4096 MiB run used format.width. The first
supplemental scanner read two words from a module's long comment as declaration
names. The successful scanner removes comments first. The returned indexes
and the report use only the successful runs.
