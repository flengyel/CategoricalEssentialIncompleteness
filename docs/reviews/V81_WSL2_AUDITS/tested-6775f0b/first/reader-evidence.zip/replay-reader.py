#!/usr/bin/env python3
"""Repeat the four independent reader's probes with the checkout's built dependencies."""
import argparse
import hashlib
import json
import os
import subprocess
from pathlib import Path

def main(root, src, work):
    lean = root.resolve() / 'Lean'
    source = src.resolve()
    work = work.resolve()
    work.mkdir(parents=True, exist_ok=True)
    project = 'CategoricalEssentialIncompleteness'
    target = '6775f0b3a5fb668f9390b21440f3f6c57bc65930'
    actual = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=lean, text=True).strip()
    if actual != target:
        raise ValueError('expected tested commit ' + target)
    bin_path = subprocess.check_output(['elan', 'which', 'lean'], cwd=lean, text=True).strip()
    library = lean / '.lake/build/lib/lean'
    overlay = work / 'lib'
    pkg = overlay / project
    pkg.mkdir(parents=True, exist_ok=True)
    records = json.loads((source / 'ch-replay.json').read_text())
    fresh = {r['module'].split('.')[-1] for r in records}
    for old in (library / project).iterdir():
        path = pkg / old.name
        if old.name.split('.')[0] not in fresh and not path.exists() and not path.is_symlink():
            path.symlink_to(old)
    deps = sorted((lean / '.lake/packages').glob('*/.lake/build/lib/lean'))
    env = dict(os.environ, LEAN_NUM_THREADS='1', LEAN_PATH=os.pathsep.join(map(str,[overlay, library, *deps])))
    def run(label, args):
        with (work / (label + '.log')).open('wb') as of:
            r = subprocess.run([bin_path,'-j1','--memory=4096','-DwarningAsError=true',*args],
                               cwd=work,env=env,stdout=of,stderr=subprocess.STDOUT)
        print(label, r.returncode, flush=True)
        if r.returncode:
            raise SystemExit(r.returncode)
    for r in records:
        path = root.resolve() / r['source']
        if hashlib.sha256(path.read_bytes()).hexdigest() != r['sha256']:
            raise ValueError('source mismatch ' + r['source'])
        stem = path.stem
        run(stem, ['-R',str(lean),'-o',str(pkg / (stem + '.olean')),str(path)])
    for stem in ['Numbered', 'Supplemental', 'Typed', 'Structure']:
        run(stem, ['-DmaxHeartbeats=800000',str(source / (stem + '.lean'))])
        actual = hashlib.sha256((work / (stem + '.log')).read_bytes()).hexdigest()
        expected = json.loads((source / (stem + '.run.json')).read_text())['output_sha256']
        if actual != expected:
            raise ValueError(stem + ' output digest differs')

if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    for name in ['checkout','extracted_evidence','working_directory']:
        p.add_argument(name,type=Path)
    a = p.parse_args()
    main(a.checkout,a.extracted_evidence,a.working_directory)
