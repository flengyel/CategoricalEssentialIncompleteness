from pathlib import Path
import re,json
out=Path(__file__).resolve().parent;c=out.parent/'cei-v81-structure'
status=(c/'FORMALIZATION_STATUS_V81.md').read_text().splitlines()
rows=[]; modules={}; names={}
for i,l in enumerate(status[:86],1):
    if i<29 or not l.startswith('| ') or '](Lean/' not in l:continue
    links=re.findall(r'\[([^\]]+)\]\((Lean/[^)#]+?\.lean)(?:#L(\d+))?\)',l)
    if not links:continue
    record={'line':i,'claim':l.split('|')[1].strip(),'links':[]}
    for label,path,loc in links:
        name=path.removeprefix('Lean/').removesuffix('.lean').replace('/','.')
        src=(c/path).read_text().splitlines()
        if path not in modules:
            stack=[]; decl=[]
            clean=re.sub(r'/-.*?-/',lambda m: "\n"*m[0].count("\n"),"\n".join(src),flags=re.S).splitlines()
            for j,s in enumerate(clean,1):
                mat=re.match(r'^namespace\s+([\w.]+)',s)
                sect=re.match(r'^(?:(?:@\[expose\]|public|noncomputable)\s+)*section(?:\s+(\w+))?\s*$',s)
                if mat:stack.append((mat[1],True))
                elif sect:stack.append((sect[1] or '',False))
                elif re.match(r'^end(?:\s+[\w.]+)?\s*$',s) and stack:stack.pop()
                mat=re.match(r'^(?:(?:@\[[^]]+\]|noncomputable|protected|public|private|nonrec)\s+)*(theorem|lemma|def|abbrev|inductive|structure|class|opaque)\s+([\w.\'₀₁₂₃₄₅₆₇₈₉]+)',s)
                if mat and 'private ' not in s[:s.index(mat[1])]:
                    ident='.'.join([nm for nm,k in stack if k]+[mat[2]])
                    decl.append({'name':ident,'line':j})
            modules[path]={'module':name,'declarations':decl,'available':(c/'Lean/.lake/build/lib/lean'/Path(*name.split('.'))).with_suffix('.olean').is_file() or (out/'build'/Path(*name.split('.'))).with_suffix('.olean').is_file()}
        refs=modules[path]['declarations']
        anchor=int(loc) if loc else None
        linked=[]
        if anchor:
            if not any('example ' in s or s.startswith('open ') for s in src[anchor-1:anchor+1]):
                linked=[n['name'] for n in refs if anchor-1<=n['line']<=anchor+6]
        record['links'].append({'source':path,'line':anchor,'label':label,'decls_at_anchor':linked})
    rows.append(record)
for path,p in modules.items():
    for decl in p['declarations']:
        if not p['available']:continue
        name=decl['name']
        if name in names and names[name]['source']!=path:print('duplicate',name)
        names[name]={'source':path,'line':decl['line']}
(out/'supplemental.json').write_text(json.dumps({'rows':rows,'modules':modules,'names_in_first_probe':names},indent=2,ensure_ascii=False)+'\n')
s=['import '+v['module'] for v in modules.values() if v['available']]
s += ['set_option format.width 150','set_option pp.fullNames true']
for nm in names:s+=[f'#check @{nm}',f'#print axioms {nm}']
(out/'Supplemental.lean').write_text('\n'.join(s)+'\n')
print(len(rows),len(modules),len(names),'no namespace',list(n for n in names if '.' not in n)[:20])
