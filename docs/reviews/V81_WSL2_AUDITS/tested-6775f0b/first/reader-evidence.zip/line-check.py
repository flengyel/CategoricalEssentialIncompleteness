from pathlib import Path
from collections import defaultdict, Counter
import re,json
o=Path(__file__).resolve().parent;c=o.parent/'cei-v81-structure/manuscript/latex'
j=json.loads((o/'passage-crosswalk.json').read_text())
by=defaultdict(set)
for r in j['correspondence_ranges']:by[r['file']].update(range(r['start'],r['end']+1))
counts=Counter();missing=[];outside=[]
for f,checked in sorted(by.items()):
    for i,s in enumerate((c/f).read_text().splitlines(),1):
        if i in checked:counts['mathematical or expository range']+=1;continue
        t=s.strip()
        if not t:counts['blank']+=1;continue
        if re.match(r'^\\(?:begin|end)\{[\w*]+\}\s*$',t) or re.fullmatch(r'\\(?:\[|\])',t):counts['environment boundary']+=1;continue
        if re.match(r'^\\(?:input|Needspace|appendix|section|subsection|subsubsection|label)(?:\b|\{)',t):counts['heading or layout']+=1;outside.append((f,i,t));continue
        if t.startswith('%'):counts['TeX comment']+=1;continue
        missing.append((f,i,t))
print(dict(counts),'unclassified',missing)
(o/'line-check.json').write_text(json.dumps({'counts':dict(counts),'unclassified':missing,'headers_and_layout_outside_ranges':outside},indent=2,ensure_ascii=False)+'\n')
if missing:raise SystemExit(1)
